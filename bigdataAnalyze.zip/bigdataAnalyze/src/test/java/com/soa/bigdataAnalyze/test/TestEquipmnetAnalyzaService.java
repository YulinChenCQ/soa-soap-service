
/**
 * <一句话功能描述>
 * <p>测试设备运维大数据service接口
 * @author 陈宇林
 * @version [版本号, 2018年11月22日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.test;


import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.service.EquipmentAnalyzeService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:spring-context.xml")
public class TestEquipmnetAnalyzaService {
	
	@Autowired
	private EquipmentAnalyzeService service;
	@Test
	public void testGetRecordInfoByDevice() {
		QueryCondition condition = new QueryCondition("2018-01-01", "2018-01-10", null, "49d84d72784d4eec803bac36981bf637");
		condition.setIfVerify("1");
		
		JSONObject res = service.getRecordInfoByDevice(condition);
		System.out.println(res);
	}
	
	
	@Test
	public void testGetRecordInfoByClass() {
		QueryCondition condition = new QueryCondition("2018-01-01", "2018-01-10", null, "49d84d72784d4eec803bac36981bf637");
		//condition.setIfVerify("1");
		service.getRecordInfoByClass(condition);
	}
	
	@Test
	public void testGetRecordInfoBySubClasss() {
		QueryCondition condition = new QueryCondition("2018-01-01", "2018-01-10", null, "49d84d72784d4eec803bac36981bf637");
		condition.setIfVerify("2");
		
		JSONObject res = service.getRecordInfoBySubclass(condition);
		System.out.println(res);
	}
	
	@Test
	public void testGetRecordInfoOfWelsByClass() {
		List<String> welIds = new ArrayList<String>();
		welIds.add("49d84d72784d4eec803bac36981bf637");
		welIds.add("49d84d72784d4eec803bac36981bf637");
		QueryCondition condition = new QueryCondition("2018-01-01", "2018-01-10", null, null);
		condition.setWelIds(welIds);
		condition.setIfVerify("1");
		JSONObject res = service.getRecordInfoOfWelsByClass(condition);
		System.out.println(res);
	}
	
	@Test
	public void testGetRecordInfoOfWelsBySubclass() {
		List<String> welIds = new ArrayList<String>();
		welIds.add("49d84d72784d4eec803bac36981bf637");
		QueryCondition condition = new QueryCondition("2018-01-01", "2018-01-10", null, null);
		condition.setWelIds(welIds);
		condition.setIfVerify("2");
		JSONObject res = service.getRecordInfoOfWelsBySubclass(condition);
		System.out.println(res);
	}
	
	@Test
	public void testGetEquipSituantion() {
		QueryCondition condition = new QueryCondition(null, null, null, null);
		JSONObject res = service.getEquipSituation(condition);
		System.out.println(res);
	}
	
	@Test
	public void testGetEquipSituantionOfWels() {
		QueryCondition condition = new QueryCondition(null, null, null, null);
		JSONObject res = service.getEquipSituationOfWels(condition);
		System.out.println(res);
	}
	
	@Test
	public void testGetWelIInfoAndEquClass() {
		JSONObject res = service.getWelIInfoAndEquClass();
		System.out.println(res);
	}
	
	@Test
	public void testGetCountOfEquClass() {
		QueryCondition condition  = new QueryCondition();
		JSONObject res = service.getCountOfEquClass(condition);
		System.out.println(res);
	}
	
	@Test
	public void testgetCountOfWel() {
		QueryCondition condition  = new QueryCondition();
		JSONObject res = service.getCountOfWel(condition);
		System.out.println(res);
	}
	
	@Test
	public void testGetEqumentInfo() {
		QueryCondition condition  = new QueryCondition();
		JSONObject res = service.getEqumentInfo(condition);
		System.out.println(res);
	}
	
	@Test
	public void testGetEquSituationOfWel() {
		QueryCondition condition  = new QueryCondition();
		JSONObject res = service.getEquSituationOfWel(condition);
		System.out.println(res);
	}
	
	@Test
	public void testGetEquSituationOfSubclass() {
		QueryCondition condition  = new QueryCondition();
		JSONObject res = service.getEquSituationOfSubclass(condition);
		System.out.println(res);
	}
	
	@Test
	public void testGetCountOfSubclass() {
		QueryCondition condition  = new QueryCondition();
		JSONObject res = service.getCountOfSubclass(condition);
		System.out.println(res);
	}
	

}
