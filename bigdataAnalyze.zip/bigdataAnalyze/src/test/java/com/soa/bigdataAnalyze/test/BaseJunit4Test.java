
/**
 * <һ�仰��������>
 * <p>
 * @author ������
 * @version [�汾��, 2018��9��17��]
 * @see [�����/����]
 * @since [��Ʒ/ģ��汾]
 */
package com.soa.bigdataAnalyze.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.service.ProblemAnalyzeService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:spring-context.xml"})
public class BaseJunit4Test {
	
	@Autowired
	private ProblemAnalyzeService problemAnalyzeService;
	
	@Test
	public void testGetPeopleEfficiencyOfProblem() {
		QueryCondition condition = new QueryCondition("2018-01-01","2019-01-10",null,null);
		System.out.println(problemAnalyzeService.getPeopleEfficiencyOfProblem(condition).toString());
	}

}
