
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年10月25日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.service.SyntheticalTaskService;

/**
 * @author 70769
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:spring-context.xml"})
public class TestGetTaskFinnishRateRankAr {
	
	@Autowired
	private SyntheticalTaskService syntheticalTaskService;
	@Test
	public void test() {
		
		QueryCondition condition = new QueryCondition();
		condition.setStatisticsType("week");
		syntheticalTaskService.getTaskFinnishRateRankAr(condition);
	}

}
