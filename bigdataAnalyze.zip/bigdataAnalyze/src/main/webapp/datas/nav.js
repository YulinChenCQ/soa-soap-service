var navs = [ {
	"title" : "单井站大数据分析",
	"icon" : "fa-cubes",
	"spread" : true,
	"children" : [ {
		"title" : "巡回检查任务大数据分析（单井）",
		"icon" : "&#xe62e;",
		"href" : "html/Inspection_tasks.html"
	}, {
		"title" : "维护保养任务大数据分析（单井）",
		"icon" : "&#xe62e;",
		"href" : "html/maintenance_task.html"
	}, {
		"title" : "属地监督任务大数据分析（单井）",
		"icon" : "&#xe62e;",
		"href" : "html/supervision_task.html"
	}, {
		"title" : "中心井站动态分析任务大数据分析（单井）",
		"icon" : "&#xe62e;",
		"href" : "html/core_task.html"
	}, {
		"title" : "普通井站动态分析任务大数据分析（单井）",
		"icon" : "&#xe62e;",
		"href" : "html/dynamic_analysis.html"
	}, {
		"title" : "临时任务大数据分析（单井）",
		"icon" : "&#xe62e;",
		"href" : "html/temporary_task.html"
	}, {
		"title" : "综合任务大数据分析（单井）",
		"icon" : "&#xe62e;",
		"href" : "html/comprehensive_big_data.html"
	} ]
}, {
	"title" : "多井站大数据分析",
	"icon" : "fa-cogs",
	"spread" : false,
	"children" : [ {
		"title" : "巡回检查任务大数据分析 （多井）",
		"icon" : "&#xe62e;",
		"href" : "html/man_Inspection_tasks.html"
	}, {
		"title" : "维护保养任务大数据分析（多井）",
		"icon" : "&#xe62e;",
		"href" : "html/man_maintenance_tasks.html"
	}, {
		"title" : "属地监督任务大数据（多井）",
		"icon" : "&#xe62e;",
		"href" : "html/man_supervision_tasks.html"
	}, {
		"title" : "中心井站动态分析任务大数据分析（多井）",
		"icon" : "&#xe62e;",
		"href" : "html/man_core_tasks.html"
	}, {
		"title" : "普通井站动态分析任务大数据分析（多井）",
		"icon" : "&#xe62e;",
		"href" : "html/man_dynamic_analysis.html"
	}, {
		"title" : "临时任务大数据分析（多井）",
		"icon" : "&#xe62e;",
		"href" : "html/man_temporary_task.html"
	}, {
		"title" : "综合任务大数据分析（多井）",
		"icon" : "&#xe62e;",
		"href" : "html/man_comprehensive_big_data.html"
	} ]
}, {
	"title" : "问题大数据分析",
	"icon" : "fa-dashboard",
	"spread" : false,
	"children" : [ {
		"title" : "问题大数据分析",
		"icon" : "&#xe62e;",
		"href" : "html/man_problem_big_data.html"
	}]
}, {
	"title" : "设备运维大数据分析",
	"icon" : "fa-stop-circle",
	"spread" : false,
	"children" : [ {
		"title" : "设备运维大数据分析",
		"icon" : "&#xe62e;",
		"href" : "html/equipment_big_data.html"
	}]
}, {
	"title" : "气井生产大数据分析",
	"icon" : "fa-stop-circle",
	"spread" : false,
	"children" : [ {
		"title" : "生产日报表",
		"icon" : "&#xe62e;",
		"href" : "http://11.89.88.45:9300/p2pd/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27%e7%a3%a8%e5%bc%80%e9%83%a8%e5%a4%a7%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e9%a1%b9%e7%9b%ae%27%5d%2fpackage%5b%40name%3d%27%e7%94%9f%e4%ba%a7%e6%97%a5%e6%8a%a5%e7%9b%b8%e5%85%b3%27%5d%2freport%5b%40name%3d%27%e7%94%9f%e4%ba%a7%e6%97%a5%e6%8a%a5%e8%a1%a8%27%5d&ui.name=%e7%94%9f%e4%ba%a7%e6%97%a5%e6%8a%a5%e8%a1%a8&run.outputFormat=&run.prompt=true"
	},{
		"title" : "总表1(8点瞬时成品数据)",
		"icon" : "&#xe62e;",
		"href" : "http://11.89.88.45:9300/p2pd/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27%e7%a3%a8%e5%bc%80%e9%83%a8%e5%a4%a7%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e9%a1%b9%e7%9b%ae%27%5d%2fpackage%5b%40name%3d%27%e6%80%bb%e8%a1%a8%e7%9b%b8%e5%85%b3%27%5d%2freport%5b%40name%3d%27%e6%80%bb%e8%a1%a81(8%e7%82%b9%e7%9e%ac%e6%97%b6%e6%88%90%e5%93%81%e6%95%b0%e6%8d%ae)%27%5d&ui.name=%e6%80%bb%e8%a1%a81(8%e7%82%b9%e7%9e%ac%e6%97%b6%e6%88%90%e5%93%81%e6%95%b0%e6%8d%ae)&run.outputFormat=&run.prompt=true"
	},{
		"title" : "总表2(日生产数据总表)",
		"icon" : "&#xe62e;",
		"href" : "http://11.89.88.45:9300/p2pd/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27%e7%a3%a8%e5%bc%80%e9%83%a8%e5%a4%a7%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e9%a1%b9%e7%9b%ae%27%5d%2fpackage%5b%40name%3d%27%e6%80%bb%e8%a1%a8%e7%9b%b8%e5%85%b3%27%5d%2freport%5b%40name%3d%27%e6%80%bb%e8%a1%a82(%e6%97%a5%e7%94%9f%e4%ba%a7%e6%95%b0%e6%8d%ae%e6%80%bb%e8%a1%a8)%27%5d&ui.name=%e6%80%bb%e8%a1%a82(%e6%97%a5%e7%94%9f%e4%ba%a7%e6%95%b0%e6%8d%ae%e6%80%bb%e8%a1%a8)&run.outputFormat=&run.prompt=true"
	},{
		"title" : "相关单位数据分析报表",
		"icon" : "&#xe62e;",
		"href" : "http://11.89.88.45:9300/p2pd/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27%e7%a3%a8%e5%bc%80%e9%83%a8%e5%a4%a7%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e9%a1%b9%e7%9b%ae%27%5d%2fpackage%5b%40name%3d%27%e7%9b%b8%e5%85%b3%e5%8d%95%e4%bd%8d%e6%95%b0%e6%8d%ae%e7%9b%b8%e5%85%b3%27%5d%2freport%5b%40name%3d%27%e7%9b%b8%e5%85%b3%e5%8d%95%e4%bd%8d%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e6%8a%a5%e8%a1%a8%27%5d&ui.name=%e7%9b%b8%e5%85%b3%e5%8d%95%e4%bd%8d%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e6%8a%a5%e8%a1%a8&run.outputFormat=&run.prompt=true"
	},{
		"title" : "节点管线数据分析报表",
		"icon" : "&#xe62e;",
		"href" : "http://11.89.88.45:9300/p2pd/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27%e7%a3%a8%e5%bc%80%e9%83%a8%e5%a4%a7%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e9%a1%b9%e7%9b%ae%27%5d%2fpackage%5b%40name%3d%27%e8%8a%82%e7%82%b9%e7%ae%a1%e7%ba%bf%e7%9b%b8%e5%85%b3%27%5d%2freport%5b%40name%3d%27%e8%8a%82%e7%82%b9%e7%ae%a1%e7%ba%bf%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e6%8a%a5%e8%a1%a8%27%5d&ui.name=%e8%8a%82%e7%82%b9%e7%ae%a1%e7%ba%bf%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e6%8a%a5%e8%a1%a8&run.outputFormat=&run.prompt=true"
	},{
		"title" : "异常数据分析",
		"icon" : "&#xe62e;",
		"href" : "http://11.89.88.45:9300/p2pd/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27%e7%a3%a8%e5%bc%80%e9%83%a8%e5%a4%a7%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e9%a1%b9%e7%9b%ae%27%5d%2fpackage%5b%40name%3d%27%e5%bc%82%e5%b8%b8%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e7%9b%b8%e5%85%b3%27%5d%2freport%5b%40name%3d%27%e5%bc%82%e5%b8%b8%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%27%5d&ui.name=%e5%bc%82%e5%b8%b8%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90&run.outputFormat=&run.prompt=true"
	},{
		"title" : "转注水分析",
		"icon" : "&#xe62e;",
		"href" : "http://11.89.88.45:9300/p2pd/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27%e7%a3%a8%e5%bc%80%e9%83%a8%e5%a4%a7%e6%95%b0%e6%8d%ae%e5%88%86%e6%9e%90%e9%a1%b9%e7%9b%ae%27%5d%2fpackage%5b%40name%3d%27%e8%bd%ac%e6%b3%a8%e6%b0%b4%e7%9b%b8%e5%85%b3%27%5d%2freport%5b%40name%3d%27%e8%bd%ac%e6%b3%a8%e6%b0%b4%e8%a1%a8%27%5d&ui.name=%e8%bd%ac%e6%b3%a8%e6%b0%b4%e8%a1%a8&run.outputFormat=&run.prompt=true"
	}]
} , {
	"title" : "磨开部生产大数据填报",
	"icon" : "fa-stop-circle",
	"spread" : false,
	"children" : [ {
		"title" : "相关单位数据填报",
		"icon" : "&#xe62e;",
		"href" : "http://11.89.88.47:10039/report/relatedUnit.html"
	},{
		"title" : "生产日报表数据填报",
		"icon" : "&#xe62e;",
		"href" : "http://11.89.88.47:10039/report/productionDailyData.html"
	}]
} ];