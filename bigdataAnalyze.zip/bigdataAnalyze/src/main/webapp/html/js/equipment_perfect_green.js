layui.use(['table','form','laypage', 'layedit', 'laydate','jquery','layer'], function(){
	// 插件加载
	var form = layui.form,table = layui.table,laypage = layui.laypage,layer = layui.layer,layedit = layui.layedit,laydate = layui.laydate,$ = layui.jquery;
	//初始化加载
	initialization();
	 var backgroundColor;
	// 日期控件
	  laydate.render({elem: '#date',value: data_date});
	  laydate.render({ elem: '#date1',value: data_date1});
		  //初始化图形的高
	  function initialization() {
		  backgroundColor='#03050B';
		//初始化设置高
		  $("#normal_abnormality").height(height);
		  //数据获取
		  data_display(data_date,data_date1);
	  }
	// 确定点击事件
	  form.on('submit(demo_true)', function(data){
		  var data_state=data.field.date_state;// 开始时间
		  var data_end=data.field.data_end;// 结束时间
		  //数据访问
		  data_display(data_state,data_end);
		  return false;
	  });
	  
	 //数据获取 
	  function data_display(beginDate,endDate) {
//			var index =layer.msg('数据加载中，请稍后。。。',{time:100*1000}, {
//				  icon: 16
//				  ,shade: 0.01
//				});
			
//			 $.post("/bigdataAnalyze/task/getSingleWelTaskInfo",
//					  {beginDate:beginDate,endDate:endDate,welId:welId,taskType :taskType }  ,
//					  function(data) {
//						  layer.close(index);
//						  var task=JSON.parse(data);
		  //数据表格1
		  var data_a='';
		  var elem='#test';
		  table_green(data_a,elem);
		  //图形
		  var legend_data=['设备总数','异常数','完好率'];
		  var xAxis_data=['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'];
		  var series_data=[{
	              name:'蒸发量',
	              type:'bar',
	              data:[2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3]
	          },
	          {
	              name:'降水量',
	              type:'bar',
	              data:[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0, 2.3]
	          },
	          {
	              name:'平均温度',
	              type:'line',
	              yAxisIndex: 1,
	              data:[2.0, 2.2, 3.3, 4.5, 6.3, 10.2, 20.3, 23.4, 23.0, 16.5, 12.0, 6.2]
	          }];
		  echice_green(legend_data,xAxis_data,series_data);
		  //数据表格二
		  var elem='#test1';
		  table_green(data_a,elem);			  
						  
//				});
		}  
	  
	  function table_green(data_a,elem) {
		  var cols_data=[];
		  var cols_data2=[];
		  for(var i=0;i<4;i++){
			  cols_data.push({align:'center',title:'设备'+i,colspan:3});
			  cols_data2.push({field:'username', width:80, title: '用户名'+i}
			      ,{field:'sex', width:80, title: '性别1'+i, sort: true}
			      ,{field:'city', width:80, title: '城市2'+i});
		  }
		  table.render({
			    elem: elem
			    ,data:null
			    ,cellMinWidth: 80 //全局定义常规单元格的最小宽度，layui 2.2.1 新增
			    ,cols: [cols_data,cols_data2]
			  });
	}
	  
	  
	  //图形
	  function echice_green(legend_data,xAxis_data,series_data) {
		  var dom = document.getElementById("normal_abnormality");
		  var myChart = echarts.init(dom);
		  var app = {};
		  option = null;
		  option = {
		      tooltip: {
		          trigger: 'axis',
		          axisPointer: {
		              type: 'cross',
		              crossStyle: {
		                  color: '#999'
		              }
		          }
		      },
		      toolbox: {
		          feature: {
		              dataView: {show: true, readOnly: false},
		              magicType: {show: true, type: ['line', 'bar']},
		              restore: {show: true},
		              saveAsImage: {show: true}
		          }
		      },
		      legend: {
		          data:legend_data
		      },
		      xAxis: [
		          {
		              type: 'category',
		              data: xAxis_data,
		              axisPointer: {
		                  type: 'shadow'
		              }
		          }
		      ],
		      yAxis: [
		          {
		              type: 'value',
		              name: '设备数',
		              min: 0,
		              max: 250,
		              interval: 10,
		              axisLabel: {
		                  formatter: '{value}'
		              }
		          },
		          {
		              type: 'value',
		              name: '完好率',
		              min: 0,
		              max: 25,
		              interval: 1,
		              axisLabel: {
		                  formatter: '{value} %'
		              }
		          }
		      ],
		      series: series_data
		  };
		  ;
		  if (option && typeof option === "object") {
		      myChart.setOption(option, true);
		  }
	}
	  
	  });