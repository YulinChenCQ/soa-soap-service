/**
 * echies_1()
 * echies_2()
 * echies_3()
 * echies_columnar(id)
 */

/*******************************************************************************
 * 物联网大数据报表图echies_1 参数 dataBJ ,dataGZ, dataSH, schema, data, data1,
 * backgroundColor : 背景颜色 参考页面
 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
 * 
 * @returns 图形展示 liuhai
 */

function echies_1(series, schema, data_legend, data_parallelAxis,
		backgroundColor) {
	var dom = document.getElementById("echies_1");
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	var lineStyle = {
		normal : {
			width : 1,
			opacity : 0.5
		}
	};
	option = {
		backgroundColor : backgroundColor,
		parallelAxis : [ {
			dim : 0,
			name : schema[0].text,
			max:31
		}, {
			dim : 1,
			name : schema[1].text
		}, {
			dim : 2,
			name : schema[2].text
		}, {
			dim : 3,
			name : schema[3].text
		}, {
			dim : 4,
			name : schema[4].text
		}, {
			dim : 5,
			name : schema[5].text
		}, {
			dim : 6,
			name : schema[6].text
		}, {
			dim : 7,
			name : schema[7].text/*,
			type : 'category',
			data : data_parallelAxis*/
		} ],
		visualMap : {
			show : false,
			min : 0,
			max : 100,
			dimension : 7,
			inRange : {
				color : [ '#d94e5d', '#eac736', '#50a3ba' ].reverse()
			}
		},
		parallel : {
			left : '5%',
			right : '8%',
			width : "auto",
			height : "75%",
			parallelAxisDefault : {
				type : 'value',
				nameLocation : 'end',
				nameGap : 30,
				nameRotate : 15,
				nameTextStyle : {
					color : '#fff',
					fontSize : 12
				},
				axisLine : {
					lineStyle : {
						color : '#aaa'
					}
				},
				axisTick : {
					lineStyle : {
						color : '#777'
					}
				},
				splitLine : {
					show : false
				},
				axisLabel : {
					rotate : 10,
					textStyle : {
						color : '#fff'
					}
				}
			}
		},
		series : series
	};
	;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/*******************************************************************************
 * 物联网大数据报表图echies_2 参数 参考页面
 * http://echarts.baidu.com/examples/editor.html?c=map-parallel-prices
 * 
 * @returns 图形展示 liuhai
 */
function echies_2(schema, rawData, backgroundColor) {
	var dom = document.getElementById("echies_2");
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	function makeMapData(rawData) {
		var mapData = [];
		for (var i = 0; i < rawData.length; i++) {
			var geoCoord = geoCoordMap[rawData[i][0]];
			if (geoCoord) {
				mapData.push({
					name : rawData[i][0],
					value : geoCoord.concat(rawData[i].slice(1))
				});
			}
		}
		return mapData;
	}
	;

	function makeParallelAxis(schema) {
		var parallelAxis = [];
		for (var i = 0; i < schema.length; i++) {
			parallelAxis.push({
				dim : i,
				name : schema[i]
			});
		}
		return parallelAxis;
	}

	option = {
		tooltip:{
			show:true
		
		},
		parallelAxis : makeParallelAxis(schema),
		grid : [ {
			show : true,
			left : 0,
			right : 0,
			top : '0',
			bottom : 0,
			borderColor : 'transparent',
			backgroundColor : backgroundColor,
			z : 99
		} ],
		parallel : {
			top : '10',
			left : 25,
			right : 20,
			bottom : 100,
			axisExpandable : true,
			axisExpandCenter : 15,
			axisExpandCount : 10,
			axisExpandWidth : 60,
			axisExpandTriggerOn : 'mousemove',
			z : 100,
			parallelAxisDefault : {
				type : 'value',
				nameLocation : 'start',
				nameRotate : 25,
				// nameLocation: 'end',
				nameTextStyle : {
					fontSize : 12
				},
				nameTruncate : {
					maxWidth : 170
				},
				nameGap : 20,
				splitNumber : 3,
				tooltip : {
					show : true
				},
				axisLine : {
					// show: false,
					lineStyle : {
						width : 1,
						color : 'rgba(255,255,255,0.3)'
					}
				},
				axisTick : {
					show : false
				},
				splitLine : {
					show : false
				},
				z : 100
			}
		},
		series : [ {
			name : 'parallel',
			type : 'parallel',
			smooth : true,
			lineStyle : {
				normal : {
					color : function(params) {
						// build a color map as your need.
						var colorList = [ '#C1232B', '#B5C334', '#FCCE10',
								'#E87C25', '#27727B', '#FE8463', '#9BCA63',
								'#FAD860', '#F3A43B', '#60C0DD', '#D7504B',
								'#C6E579', '#F4E001', '#F0805A', '#26C0C0' ];
						return colorList[params.dataIndex]
					},
					width : 0.5,
					opacity : 0.6
				}
			},
			z : 100,
			blendMode : 'lighter',
			data : rawData
		} ]
	};
	;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}

}

/*******************************************************************************
 * 物联网大数据报表图echies_3 参数 参考页面
 * http://echarts.baidu.com/examples/editor.html?c=dynamic-data
 * @returns 图形展示 liuhai
 */
function echies_3(data_xAxis, data_series) {
	var dom = document.getElementById("echies_3");
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		xAxis : {
			type : 'category',
			data : data_xAxis,
			axisLabel : {
				interval : 0,//横轴信息全部显示
				rotate : -30//-30度角倾斜显示
			},
			axisLine : {
				lineStyle : {
					color : '#ccc',
					width : 1//这里是为了突出显示加上的
				}
			}
		},
		yAxis : {
			type : 'value',
			axisLine : {
				lineStyle : {
					color : '#ccc',
					width : 1//这里是为了突出显示加上的
				}
			}
		},
		series : [ {
			data : data_series,
			type : 'bar'
		} ]
	};

	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/*******************************************************************************
 * 柱状图echies_columnar 
 * @returns 图形展示 liuhai
 */
//图1------------------------------
function echies_columnar(data_legendData,data_selected,data_seriesData) {
	var dom = document.getElementById('implementation');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		backgroundColor: '#1C86EE',
		tooltip : {
			trigger : 'item',
			formatter : "{b} : {c} ({d}%)"
		},
		legend : {
			type : 'scroll',
			orient : 'vertical',
			right : 10,
			top : 20,
			bottom : 20,
			data : data_legendData,
			selected : data_selected
		},
		series : [ {
			type : 'pie',
			radius : '55%',
			center : [ '40%', '50%' ],
			data : data_seriesData,
			itemStyle : {
				emphasis : {
					shadowBlur : 10,
					shadowOffsetX : 0,
					shadowColor : 'rgba(0, 0, 0, 0.5)'
				}
			}
		} ]
	};;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}
//图1------------end-----
/*******************************************************************************
 * 饼图echies_pir 
 * @returns 图形展示 liuhai
 */
function echies_pir(id,legend_data,series_data) {
	var dom = document.getElementById(id);
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
			backgroundColor: '#1C86EE',
		tooltip : {
			trigger : 'item',
			formatter : "{a} <br/>{b} : {c} ({d}%)"
		},
		legend : {
			x : 'center',
			y : 'bottom',
			data : legend_data
		},
		toolbox : {
			show : true,
			feature : {
				mark : {
					show : true
				},
				dataView : {
					show : true,
					readOnly : false
				},
				magicType : {
					show : true,
					type : [ 'pie', 'funnel' ]
				},
				restore : {
					show : true
				},
				saveAsImage : {
					show : true
				}
			}
		},
		calculable : true,
		series : [{
			name : '任务数量',
			type : 'pie',
			radius : [ 30, 110 ],
			roseType : 'area',
			data : series_data
		} ]
	};
	;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/*******************************************************************************
 * 饼图echies_process 
 * @returns 图形展示 liuhai
 */

function echies_process(radiusAxis_data) {
	var dom = document.getElementById("situation");
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
			backgroundColor: '#1C86EE',
			tooltip: {
		        trigger: 'item',
		        formatter: "{a} <br/>{b}: {c}"
		    },
	    angleAxis: {
	    },
	    radiusAxis: {
	        type: 'category',
	        data: radiusAxis_data,
	        z: 1
	    },
	    polar: {
	    },
	    series: [{
	        type: 'bar',
	        data: [11, 2, 13, 4,1],
	        coordinateSystem: 'polar',
	        name: '已完成',
	        stack: 'a'
	    }, {
	        type: 'bar',
	        data: [2, 4, 6, 8,4],
	        coordinateSystem: 'polar',
	        name: '未完成',
	        stack: 'a'
	    }, {
	        type: 'bar',
	        data: [1, 2, 3, 4,3],
	        coordinateSystem: 'polar',
	        name: '超期完成',
	        stack: 'a'
	    }, {
	        type: 'bar',
	        data: [1, 2, 3, 4,2],
	        coordinateSystem: 'polar',
	        name: '即将超期',
	        stack: 'a'
	    }, {
	        type: 'bar',
	        data: [1, 2, 3, 4,2],
	        coordinateSystem: 'polar',
	        name: '超期未完成',
	        stack: 'a'
	    }],
	    legend: {
	        show: true,
	        data: ['已完成', '未完成', '超期完成', '即将超期', '超期未完成']
	    }
	};
	;
	if (option && typeof option === "object") {
	    myChart.setOption(option, true);
	}

}

/*******************************************************************************
 * 饼图echies_scroll
 * backgroundColor : 背景颜色 参考页面
 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
 * 
 * @returns 图形展示 liuhai
 */

function echies_scroll(legend_data,radar_data,series_data) {
	var dom = document.getElementById('completion_rate');
	var myChart = echarts.init(dom);
	var app = {};
	option = {
			backgroundColor: '#1C86EE',
		tooltip : {
			trigger : 'item',
			backgroundColor : 'blue'
		},
		legend : {
			type : 'scroll',
			bottom : 10,
			data : legend_data
		},
		/*visualMap : {
			top : 'middle',
			right : 10,
			color : [ 'red', 'yellow' ],
			calculable : true
		},*/
		radar :radar_data ,
		series : {
			type : 'radar',
			symbol : 'none',
			lineStyle : {
				width : 1
			},
			emphasis : {
				areaStyle : {
					color : 'rgba(0,250,0,0.3)'
				}
			},
			data : series_data
		}
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

function a() {
	var series = [];
	for (var i = 1; i <= 28; i++) {
		series.push({
			type : 'radar',
			symbol : 'none',
			lineStyle : {
				width : 1
			},
			emphasis : {
				areaStyle : {
					color : 'rgba(0,250,0,0.3)'
				}
			},
			data : [ {
				value : [ (40 - i) * 10, (38 - i) * 4 + 60, i * 5 + 10,
						i * 9, i * i / 2 ],
				name : i + 2000 + ''
			} ]
		});
	}
	return series;
}

/*******************************************************************************
 * 饼图echies_gauge
 * backgroundColor : 背景颜色 参考页面
 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
 * 
 * @returns 图形展示 liuhai
 */

function echies_gauge(id,legend_data,series_data,name_data) {

	var dom = document.getElementById(id);
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
			backgroundColor: '#1C86EE',
		tooltip : {
			trigger : 'axis',
			axisPointer : {
				type : 'cross',
				label : {
					backgroundColor : '#283b56'
				}
			}
		},
		legend : {
			data : legend_data
		},
		/*toolbox : {
			show : true,
			feature : {
				dataView : {
					readOnly : false
				},
				restore : {},
				saveAsImage : {}
			}
		},*/
		dataZoom : {
			show : false,
			start : 0,
			end : 100
		},
		xAxis : [ {
			type : 'category',
			boundaryGap : true,
			data : name_data
		} ],
		/*yAxis : [ {
			type : '任务完成率',
			scale : true,
			name : '任务数量',
			max : 100,
			min : 0,
			boundaryGap : [ 0.2, 0.2 ]
		} ],*/
		series : [ {
			name : '任务完成率',
			type : 'bar',
			xAxisIndex : 1,
			yAxisIndex : 1,
			data : series_data
		}]
	};

	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}
/*******************************************************************************
 * 饼图echies_statistics
 * 多个井站每种任务的数量统计对比
 * @returns 图形展示 liuhai
 */
function echies_statistics(legend_data,xAxis_data,series_data) {
	var dom = document.getElementById('statistics');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
			backgroundColor: '#1C86EE',
			tooltip : {
				trigger : 'axis',
				axisPointer : { // 坐标轴指示器，坐标轴触发有效
					type : 'shadow' // 默认为直线，可选为：'line' | 'shadow'
				}
			},
			legend : {
				data : legend_data
			},
			xAxis : {
				type : 'category',
				data : xAxis_data,
				axisLabel : {
					interval : 0,//横轴信息全部显示
					rotate : -30//-30度角倾斜显示
				},
				axisLine : {
					lineStyle : {
						color : '#ccc',
						width : 1//这里是为了突出显示加上的
					}
				}
			},
			yAxis : {
				type : 'value',
				axisLine : {
					lineStyle : {
						color : '#ccc',
						width : 1//这里是为了突出显示加上的
					}
				}
			},
			series : series_data
		};

		if (option && typeof option === "object") {
			myChart.setOption(option, true);
		}
	}
/*******************************************************************************
 * 饼图echies_rate
 * backgroundColor : 背景颜色 参考页面
 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
 * 
 * @returns 图形展示 liuhai
 */

function echies_rates(legend_data,indicator) {
	var dom = document.getElementById('completion_rates');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		backgroundColor: '#1C86EE',
		legend : {
			data : legend_data
		},
		radar : [
				{
					indicator :indicator,
					center : [ '25%', '50%' ],
					radius : 120,
					startAngle : 90,
					splitNumber : 4,
					shape : 'circle',
					name : {
						formatter : '【{value}】',
						textStyle : {
							color : '#72ACD1'
						}
					},
					splitArea : {
						areaStyle : {
							color : [ 'rgba(114, 172, 209, 0.2)',
									'rgba(114, 172, 209, 0.4)',
									'rgba(114, 172, 209, 0.6)',
									'rgba(114, 172, 209, 0.8)',
									'rgba(114, 172, 209, 1)' ],
							shadowColor : 'rgba(0, 0, 0, 0.3)',
							shadowBlur : 10
						}
					},
					axisLine : {
						lineStyle : {
							color : 'rgba(255, 255, 255, 0.5)'
						}
					},
					splitLine : {
						lineStyle : {
							color : 'rgba(255, 255, 255, 0.5)'
						}
					}
				}, {
					indicator : [ {
						text : '巡回检查',
						max : 150
					}, {
						text : '维护保养',
						max : 150
					}, {
						text : '动态分析',
						max : 150
					}, {
						text : '临时任务',
						max : 120
					}, {
						text : '属地监督',
						max : 108
					}],
					center : [ '75%', '50%' ],
					radius : 120
				} ],
		series : [
				{
					name : '雷达图',
					type : 'radar',
					itemStyle : {
						emphasis : {
							// color: 各异,
							lineStyle : {
								width : 4
							}
						}
					},
					data : [ {
						value : [ 100, 8, 0.40, -80, 2000 ],
						name : '巡回检查',
						symbol : 'rect',
						symbolSize : 5,
						lineStyle : {
							normal : {
								type : 'dashed'
							}
						}
					}, {
						value : [ 60, 5, 0.30, -100, 1500 ],
						name : '维护保养',
						areaStyle : {
							normal : {
								color : 'rgba(255, 255, 255, 0.5)'
							}
						}
					}, {
						value : [ 60, 5, 0.30, -100, 1500 ],
						name : '动态分析',
						areaStyle : {
							normal : {
								color : 'rgba(255, 255, 255, 0.5)'
							}
						}
					}  ]
				},
				{
					name : '成绩单',
					type : 'radar',
					radarIndex : 1,
					data : [
							{
								value : [ 120, 118, 130, 100, 99, 70 ],
								name : '临时任务',
								label : {
									normal : {
										show : true,
										formatter : function(params) {
											return params.value;
										}
									}
								}
							},
							{
								value : [ 90, 113, 140, 30, 70, 60 ],
								name : '属地监督',
								areaStyle : {
									normal : {
										opacity : 0.9,
										color : new echarts.graphic.RadialGradient(
												0.5, 0.5, 1, [ {
													color : '#B8D3E4',
													offset : 0
												}, {
													color : '#72ACD1',
													offset : 1
												} ])
									}
								}
							} ]
				} ]
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/*******************************************************************************
 * 饼图echies_rate
 * backgroundColor : 背景颜色 参考页面
 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
 * 
 * @returns 图形展示 liuhai
 */
function echies_Score() {
	var dom = document.getElementById('Score');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	// Schema:
	// date,AQIindex,PM2.5,PM10,CO,NO2,SO2
	var dataBJ = [ [ 55, 9, 56, 0.46, 18, 6, 1 ],
			[ 25, 11, 21, 0.65, 34, 9, 2 ], [ 56, 7, 63, 0.3, 14, 5, 3 ],
			[ 33, 7, 29, 0.33, 16, 6, 4 ], [ 42, 24, 44, 0.76, 40, 16, 5 ],
			[ 82, 58, 90, 1.77, 68, 33, 6 ], [ 74, 49, 77, 1.46, 48, 27, 7 ],
			[ 78, 55, 80, 1.29, 59, 29, 8 ],
			[ 267, 216, 280, 4.8, 108, 64, 9 ],
			[ 185, 127, 216, 2.52, 61, 27, 10 ],
			[ 39, 19, 38, 0.57, 31, 15, 11 ], [ 41, 11, 40, 0.43, 21, 7, 12 ],
			[ 64, 38, 74, 1.04, 46, 22, 13 ],
			[ 108, 79, 120, 1.7, 75, 41, 14 ],
			[ 108, 63, 116, 1.48, 44, 26, 15 ], [ 33, 6, 29, 0.34, 13, 5, 16 ],
			[ 94, 66, 110, 1.54, 62, 31, 17 ],
			[ 186, 142, 192, 3.88, 93, 79, 18 ],
			[ 57, 31, 54, 0.96, 32, 14, 19 ], [ 22, 8, 17, 0.48, 23, 10, 20 ],
			[ 39, 15, 36, 0.61, 29, 13, 21 ],
			[ 94, 69, 114, 2.08, 73, 39, 22 ],
			[ 99, 73, 110, 2.43, 76, 48, 23 ], [ 31, 12, 30, 0.5, 32, 16, 24 ],
			[ 42, 27, 43, 1, 53, 22, 25 ], [ 154, 117, 157, 3.05, 92, 58, 26 ],
			[ 234, 185, 230, 4.09, 123, 69, 27 ],
			[ 160, 120, 186, 2.77, 91, 50, 28 ],
			[ 134, 96, 165, 2.76, 83, 41, 29 ],
			[ 52, 24, 60, 1.03, 50, 21, 30 ], [ 46, 5, 49, 0.28, 10, 6, 31 ] ];

	var dataGZ = [ [ 26, 37, 27, 1.163, 27, 13, 1 ],
			[ 85, 62, 71, 1.195, 60, 8, 2 ], [ 78, 38, 74, 1.363, 37, 7, 3 ],
			[ 21, 21, 36, 0.634, 40, 9, 4 ], [ 41, 42, 46, 0.915, 81, 13, 5 ],
			[ 56, 52, 69, 1.067, 92, 16, 6 ], [ 64, 30, 28, 0.924, 51, 2, 7 ],
			[ 55, 48, 74, 1.236, 75, 26, 8 ],
			[ 76, 85, 113, 1.237, 114, 27, 9 ],
			[ 91, 81, 104, 1.041, 56, 40, 10 ],
			[ 84, 39, 60, 0.964, 25, 11, 11 ],
			[ 64, 51, 101, 0.862, 58, 23, 12 ],
			[ 70, 69, 120, 1.198, 65, 36, 13 ],
			[ 77, 105, 178, 2.549, 64, 16, 14 ],
			[ 109, 68, 87, 0.996, 74, 29, 15 ],
			[ 73, 68, 97, 0.905, 51, 34, 16 ],
			[ 54, 27, 47, 0.592, 53, 12, 17 ],
			[ 51, 61, 97, 0.811, 65, 19, 18 ],
			[ 91, 71, 121, 1.374, 43, 18, 19 ],
			[ 73, 102, 182, 2.787, 44, 19, 20 ],
			[ 73, 50, 76, 0.717, 31, 20, 21 ],
			[ 84, 94, 140, 2.238, 68, 18, 22 ],
			[ 93, 77, 104, 1.165, 53, 7, 23 ],
			[ 99, 130, 227, 3.97, 55, 15, 24 ],
			[ 146, 84, 139, 1.094, 40, 17, 25 ],
			[ 113, 108, 137, 1.481, 48, 15, 26 ],
			[ 81, 48, 62, 1.619, 26, 3, 27 ], [ 56, 48, 68, 1.336, 37, 9, 28 ],
			[ 82, 92, 174, 3.29, 0, 13, 29 ],
			[ 106, 116, 188, 3.628, 101, 16, 30 ],
			[ 118, 50, 0, 1.383, 76, 11, 31 ] ];

	var dataSH = [ [ 91, 45, 125, 0.82, 34, 23, 1 ],
			[ 65, 27, 78, 0.86, 45, 29, 2 ], [ 83, 60, 84, 1.09, 73, 27, 3 ],
			[ 109, 81, 121, 1.28, 68, 51, 4 ],
			[ 106, 77, 114, 1.07, 55, 51, 5 ],
			[ 109, 81, 121, 1.28, 68, 51, 6 ],
			[ 106, 77, 114, 1.07, 55, 51, 7 ], [ 89, 65, 78, 0.86, 51, 26, 8 ],
			[ 53, 33, 47, 0.64, 50, 17, 9 ], [ 80, 55, 80, 1.01, 75, 24, 10 ],
			[ 117, 81, 124, 1.03, 45, 24, 11 ],
			[ 99, 71, 142, 1.1, 62, 42, 12 ],
			[ 95, 69, 130, 1.28, 74, 50, 13 ],
			[ 116, 87, 131, 1.47, 84, 40, 14 ],
			[ 108, 80, 121, 1.3, 85, 37, 15 ],
			[ 134, 83, 167, 1.16, 57, 43, 16 ],
			[ 79, 43, 107, 1.05, 59, 37, 17 ],
			[ 71, 46, 89, 0.86, 64, 25, 18 ],
			[ 97, 71, 113, 1.17, 88, 31, 19 ],
			[ 84, 57, 91, 0.85, 55, 31, 20 ], [ 87, 63, 101, 0.9, 56, 41, 21 ],
			[ 104, 77, 119, 1.09, 73, 48, 22 ], [ 87, 62, 100, 1, 72, 28, 23 ],
			[ 168, 128, 172, 1.49, 97, 56, 24 ],
			[ 65, 45, 51, 0.74, 39, 17, 25 ], [ 39, 24, 38, 0.61, 47, 17, 26 ],
			[ 39, 24, 39, 0.59, 50, 19, 27 ], [ 93, 68, 96, 1.05, 79, 29, 28 ],
			[ 188, 143, 197, 1.66, 99, 51, 29 ],
			[ 174, 131, 174, 1.55, 108, 50, 30 ],
			[ 187, 143, 201, 1.39, 89, 53, 31 ] ];

	var lineStyle = {
		normal : {
			width : 1,
			opacity : 0.5
		}
	};
	option = {
		backgroundColor : '#1C86EE',
		title : {
			text : 'AQI - 雷达图',
			left : 'center',
			textStyle : {
				color : '#eee'
			}
		},
		legend : {
			bottom : 5,
			data : [ '北京', '上海', '广州' ],
			itemGap : 20,
			textStyle : {
				color : '#fff',
				fontSize : 14
			},
			selectedMode : 'single'
		},
		 visualMap: {
		     show: true,
		     min: 0,
		     max: 20,
		     dimension: 6,
		     inRange: {
		         colorLightness: [0.5, 0.8]
		     }
		 },
		radar : {
			indicator : [ {
				name : '巡回检查',
				max : 300
			}, {
				name : '维护保养',
				max : 250
			}, {
				name : '动态分析',
				max : 300
			}, {
				name : '临时任务',
				max : 5
			}, {
				name : '属地监督',
				max : 200
			}, {
				name : 'SO2',
				max : 100
			} ],
			shape : 'circle',
			splitNumber : 5,
			name : {
				textStyle : {
					color : 'rgb(238, 197, 102)'
				}
			},
			splitLine : {
				lineStyle : {
					color : [ 'rgba(238, 197, 102, 0.1)',
							'rgba(238, 197, 102, 0.2)',
							'rgba(238, 197, 102, 0.4)',
							'rgba(238, 197, 102, 0.6)',
							'rgba(238, 197, 102, 0.8)',
							'rgba(238, 197, 102, 1)' ].reverse()
				}
			},
			splitArea : {
				show : false
			},
			axisLine : {
				lineStyle : {
					color : 'rgba(238, 197, 102, 0.5)'
				}
			}
		},
		series : [ {
			name : '北京',
			type : 'radar',
			lineStyle : lineStyle,
			data : dataBJ,
			symbol : 'none',
			itemStyle : {
				normal : {
					color : '#F9713C'
				}
			},
			areaStyle : {
				normal : {
					opacity : 0.1
				}
			}
		}, {
			name : '上海',
			type : 'radar',
			lineStyle : lineStyle,
			data : dataSH,
			symbol : 'none',
			itemStyle : {
				normal : {
					color : '#B3E4A1'
				}
			},
			areaStyle : {
				normal : {
					opacity : 0.05
				}
			}
		}, {
			name : '广州',
			type : 'radar',
			lineStyle : lineStyle,
			data : dataGZ,
			symbol : 'none',
			itemStyle : {
				normal : {
					color : 'rgb(238, 197, 102)'
				}
			},
			areaStyle : {
				normal : {
					opacity : 0.05
				}
			}
		} ]
	};
	;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/*******************************************************************************
 * 饼图echies_rate
 * backgroundColor : 背景颜色 参考页面
 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
 * 
 * @returns 图形展示 liuhai
 */

function echies_ratees(xAxis_data,series_data) {
	var dom = document.getElementById('average_score');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		backgroundColor: '#1C86EE',
		tooltip : {
			trigger : 'axis',
			axisPointer : { // 坐标轴指示器，坐标轴触发有效
				type : 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		grid : {
			left : '3%',
			right : '4%',
			bottom : '3%',
			containLabel : true
		},
		xAxis : [ {
			type : 'category',
			data : xAxis_data,
			axisTick : {
				alignWithLabel : true
			}
		} ],
		yAxis : [ {
			type : 'value'
		} ],
		series : [ {
			name : '平均得分',
			type : 'bar',
			barWidth : '60%',
			data : series_data
		} ]
	};
	;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}
/*******************************************************************************
 * 饼图echies_rate
 * backgroundColor : 背景颜色 参考页面
 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
 * 
 * @returns 图形展示 liuhai
 */

function echies_radar(legend_data,indicator_data,series_data) {
	var dom = document.getElementById('completion_rate');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		backgroundColor: '#1C86EE',
		tooltip : {},
		legend : {
			data : legend_data
		},
		radar : {
			// shape: 'circle',
			name : {
				textStyle : {
					color : '#fff',
					backgroundColor : '#999',
					borderRadius : 3,
					padding : [ 3, 5 ]
				}
			},
			indicator : indicator_data
		},
		series : [ {
			name : '预',
			type : 'radar',
			data :series_data
		} ]
	};
	;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/*******************************************************************************
 * echies_shadow()
 * 参数：legend_data
 * @returns 图形展示 liuhai
 */
function echies_shadow(legend_data, yAxis_data, series_data) {
	var dom = document.getElementById('tpthbsaait_data');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		title : {
			text : '已销项的问题进行各环节处理效率大数据分析',
			textStyle : {
				color : '#fff'
			}
		},
		tooltip : {
			trigger : 'axis',
			axisPointer : {
				type : 'shadow'
			}
		},
		legend : {
			orient : 'horizontal',
			y : 'bottom',
			textStyle : {
				color : '#fff'
			},
			data : legend_data
		},
		grid : {
			left : '3%',
			right : '4%',
			bottom : '8%',
			containLabel : true
		},
		xAxis : {
			type : 'value',
			axisLabel : {
				show : true,
				textStyle : {
					color : '#fff'
				}
			}
		},
		yAxis : {
			type : 'category',
			axisLabel : {
				formatter : '{value}',
				textStyle : {
					color : '#fff'
				}
			},
			data : yAxis_data
		},
		series : series_data
	};
	;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/*******************************************************************************
 * 图表：相同岗位人员处理相同环节的效率大数据分析
 * @returns 图形展示 liuhai
 */
function echies_nutrients() {
	var dom = document.getElementById('average_score');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	var indices = {
		name : 0,
		group : 1,
		id : 16
	};
	var schema = [ {
		name : 'name',
		index : 0
	}, {
		name : 'group',
		index : 1
	}, {
		name : 'protein',
		index : 2
	}, {
		name : 'calcium',
		index : 3
	}, {
		name : 'sodium',
		index : 4
	}, {
		name : 'fiber',
		index : 5
	}, {
		name : 'vitaminc',
		index : 6
	}, {
		name : 'potassium',
		index : 7
	}, {
		name : 'carbohydrate',
		index : 8
	}, {
		name : 'sugars',
		index : 9
	}, {
		name : 'fat',
		index : 10
	}, {
		name : 'water',
		index : 11
	}, {
		name : 'calories',
		index : 12
	}, {
		name : 'saturated',
		index : 13
	}, {
		name : 'monounsat',
		index : 14
	}, {
		name : 'polyunsat',
		index : 15
	}, {
		name : 'id',
		index : 16
	} ];

	var groupCategories = [];
	var groupColors = [];
	var data = [
			[
					"Beverage, instant breakfast powder, chocolate, not reconstituted",
					"Dairy and Egg Products", 19.9, 0.285, 0.385, 0.4,
					0.07690000000000001, 0.947, 66.2, 65.8, 1.4, 7.4, 357,
					0.56, 0.314, 0.278, 27481 ],
			[
					"Beverage, instant breakfast powder, chocolate, sugar-free, not reconstituted",
					"Dairy and Egg Products", 35.8, 0.5, 0.717, 2, 0.138,
					1.705, 41, 39, 5.1, 7.4, 358, 2.162, 1.189, 1.027, 27482 ],
			[ "Beverage, milkshake mix, dry, not chocolate",
					"Dairy and Egg Products", 23.5, 0.88, 0.78, 1.6, 0.0012,
					2.2, 52.9, 51.3, 2.6, 12.8, 329, 2.059, 0.332, 0.06, 27483 ],
			[ "Butter oil, anhydrous", "Dairy and Egg Products", 0.28, 0.004,
					0.002, null, 0, 0.005, null, null, 99.48, 0.24, 876,
					61.924, 28.732, 3.694, 27484 ],
			[ "Butter, salted", "Dairy and Egg Products", 0.85, 0.024, 0.714,
					null, 0, 0.024, 0.06, 0.06, 81.11, 15.87, 717, 51.368,
					21.021, 3.043, 27485 ],
			[ "Butter, whipped, with salt", "Dairy and Egg Products", 0.85,
					0.024, 0.827, null, 0, 0.026, 0.06, 0.06, 81.11, 15.87,
					717, 50.489, 23.426, 3.012, 27486 ],
			[ "Butter, without salt", "Dairy and Egg Products", 0.85, 0.024,
					0.011, null, 0, 0.024, 0.06, 0.06, 81.11, 17.94, 717,
					51.368, 21.021, 3.043, 27487 ],
			[ "Cheese fondue", "Dairy and Egg Products", 14.23, 0.476, 0.132,
					null, 0, 0.105, 3.77, null, 13.47, 61.61, 229, 8.721,
					3.563, 0.484, 27488 ],
			[ "Cheese food, cold pack, american", "Dairy and Egg Products",
					19.66, 0.497, 0.966, null, 0, 0.363, 8.32, null, 24.46,
					43.12, 331, 15.355, 7.165, 0.719, 27489 ],
			[ "Cheese food, imitation", "Dairy and Egg Products", 22.4, 0.552,
					1.239, null, 0, 0.336, 8.8, 8.21, 1.3, 63.8, 137, 0.81,
					0.38, 0.048, 27490 ],
			[
					"Cheese food, pasteurized process, american, with di sodium phosphate",
					"Dairy and Egg Products", 19.61, 0.574, 1.596, null, 0,
					0.279, 7.29, 7.43, 24.6, 43.15, 328, 15.443, 7.206, 0.723,
					27491 ],
			[
					"Cheese food, pasteurized process, american, without di sodium phosphate",
					"Dairy and Egg Products", 18.4, 0.57, 1.265, null, 0,
					0.291, 7.83, 7.43, 25.18, 43.21, 330, 14.895, 7.214, 1.108,
					27492 ],
			[ "Cheese food, pasteurized process, swiss",
					"Dairy and Egg Products", 21.92, 0.723, 1.552, null, 0,
					0.284, 4.5, null, 24.14, 43.67, 323, 15.487, 6.801, 0.6,
					27493 ],
			[
					"Cheese product, pasteurized process, american, reduced fat, fortified with vitamin D",
					"Dairy and Egg Products", 17.6, 0.529, 1.587, null, 0,
					0.33, 10.6, 8.02, 14.1, 51.8, 240, 8.85, 4.13, 0.41, 27494 ] ];

	normalizeData(data);

	myChart.setOption(option = getOption(data));

	function normalizeData(originData) {
		var groupMap = {};
		originData.forEach(function(row) {
			var groupName = row[indices.group];
			if (!groupMap.hasOwnProperty(groupName)) {
				groupMap[groupName] = 1;
			}
		});

		originData.forEach(function(row) {
			row.forEach(function(item, index) {
				if (index !== indices.name && index !== indices.group
						&& index !== indices.id) {
					// Convert null to zero, as all of them under unit "g".
					row[index] = parseFloat(item) || 0;
				}
			});
		});

		for ( var groupName in groupMap) {
			if (groupMap.hasOwnProperty(groupName)) {
				groupCategories.push(groupName);
			}
		}
		var hStep = Math.round(300 / (groupCategories.length - 1));
		for (var i = 0; i < groupCategories.length; i++) {
			groupColors.push(echarts.color.modifyHSL('#5A94DF', hStep * i));
		}
	}

	function getOption(data) {

		var lineStyle = {
			normal : {
				width : 0.5,
				opacity : 0.05
			}
		};

		return {
			tooltip : {
				padding : 10,
				backgroundColor : '#222',
				borderColor : '#777',
				borderWidth : 1,
				formatter : function(obj) {
					var value = obj[0].value;
					return '<div style="border-bottom: 1px solid rgba(255,255,255,.3); font-size: 18px;padding-bottom: 7px;margin-bottom: 7px">'
							+ schema[1].name
							+ '：'
							+ value[1]
							+ '<br>'
							+ schema[2].name
							+ '：'
							+ value[2]
							+ '<br>'
							+ schema[3].name
							+ '：'
							+ value[3]
							+ '<br>'
							+ schema[4].name
							+ '：'
							+ value[4]
							+ '<br>'
							+ schema[5].name
							+ '：'
							+ value[5]
							+ '<br>'
							+ schema[6].name + '：' + value[6] + '<br>';
				}
			},
			title : [ {
				text : 'Groups',
				top : 0,
				left : 0,
				textStyle : {
					color : '#fff'
				}
			} ],
			visualMap : {
				show : true,
				type : 'piecewise',
				categories : groupCategories,
				dimension : indices.group,
				inRange : {
					color : groupColors
				//['#d94e5d','#eac736','#50a3ba']
				},
				outOfRange : {
					color : [ '#ccc' ]
				//['#d94e5d','#eac736','#50a3ba']
				},
				top : 20,
				textStyle : {
					color : '#fff'
				},
				realtime : false
			},
			parallelAxis : [ {
				dim : 16,
				name : schema[16].name,
				scale : true,
				nameLocation : 'end'
			}, {
				dim : 2,
				name : schema[2].name,
				nameLocation : 'end'
			}, {
				dim : 4,
				name : schema[4].name,
				nameLocation : 'end'
			}, {
				dim : 3,
				name : schema[3].name,
				nameLocation : 'end'
			}, {
				dim : 5,
				name : schema[5].name,
				nameLocation : 'end'
			}, {
				dim : 6,
				name : schema[6].name,
				nameLocation : 'end'
			}, {
				dim : 7,
				name : schema[7].name,
				nameLocation : 'end'
			}, {
				dim : 8,
				name : schema[8].name,
				nameLocation : 'end'
			}, {
				dim : 9,
				name : schema[9].name,
				nameLocation : 'end'
			}, {
				dim : 10,
				name : schema[10].name,
				nameLocation : 'end'
			}, {
				dim : 11,
				name : schema[11].name,
				nameLocation : 'end'
			}, {
				dim : 12,
				name : schema[12].name,
				nameLocation : 'end'
			}, {
				dim : 13,
				name : schema[13].name,
				nameLocation : 'end'
			}, {
				dim : 14,
				name : schema[14].name,
				nameLocation : 'end'
			}, {
				dim : 15,
				name : schema[15].name,
				nameLocation : 'end'
			} ],
			parallel : {
				left : 280,
				top : 20,
				// top: 150,
				// height: 300,
				width : 400,
				layout : 'vertical',
				parallelAxisDefault : {
					type : 'value',
					name : 'nutrients',
					nameLocation : 'end',
					nameGap : 20,
					nameTextStyle : {
						color : '#fff',
						fontSize : 14
					},
					axisLine : {
						lineStyle : {
							color : '#aaa'
						}
					},
					axisTick : {
						lineStyle : {
							color : '#777'
						}
					},
					splitLine : {
						show : false
					},
					axisLabel : {
						textStyle : {
							color : '#fff'
						}
					},
					realtime : false
				}
			},
			animation : false,
			series : [ {
				name : 'nutrients',
				type : 'parallel',
				lineStyle : lineStyle,
				inactiveOpacity : 0,
				activeOpacity : 0.01,
				progressive : 500,
				smooth : true,
				data : data
			} ]
		};
	}
	;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/*******************************************************************************
 * 图表：不同问题每个环节的处理效率大数据分析
 * @returns 图形展示 liuhai
 */
function echies_category() {
	var dom = document.getElementById('category');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	var hours = [ '12a', '1a', '2a', '3a', '4a', '5a', '6a', '7a', '8a', '9a',
			'10a', '11a', '12p', '1p', '2p', '3p', '4p', '5p', '6p', '7p',
			'8p', '9p', '10p', '11p' ];
	var days = [ 'Saturday', 'Friday', 'Thursday', 'Wednesday', 'Tuesday',
			'Monday', 'Sunday' ];

	var data = [ [ 0, 0, 5 ], [ 0, 1, 1 ], [ 0, 2, 0 ], [ 0, 3, 0 ],
			[ 0, 4, 0 ], [ 0, 5, 0 ], [ 0, 6, 0 ], [ 0, 7, 0 ], [ 0, 8, 0 ],
			[ 0, 9, 0 ], [ 0, 10, 0 ], [ 0, 11, 2 ], [ 0, 12, 4 ],
			[ 0, 13, 1 ], [ 0, 14, 1 ], [ 0, 15, 3 ], [ 0, 16, 4 ],
			[ 0, 17, 6 ], [ 0, 18, 4 ], [ 0, 19, 4 ], [ 0, 20, 3 ],
			[ 0, 21, 3 ], [ 0, 22, 2 ], [ 0, 23, 5 ], [ 1, 0, 7 ], [ 1, 1, 0 ],
			[ 1, 2, 0 ], [ 1, 3, 0 ], [ 1, 4, 0 ], [ 1, 5, 0 ], [ 1, 6, 0 ],
			[ 1, 7, 0 ], [ 1, 8, 0 ], [ 1, 9, 0 ], [ 1, 10, 5 ], [ 1, 11, 2 ],
			[ 1, 12, 2 ], [ 1, 13, 6 ], [ 1, 14, 9 ], [ 1, 15, 11 ],
			[ 1, 16, 6 ], [ 1, 17, 7 ], [ 1, 18, 8 ], [ 1, 19, 12 ],
			[ 1, 20, 5 ], [ 1, 21, 5 ], [ 1, 22, 7 ], [ 1, 23, 2 ],
			[ 2, 0, 1 ], [ 2, 1, 1 ], [ 2, 2, 0 ], [ 2, 3, 0 ], [ 2, 4, 0 ],
			[ 2, 5, 0 ], [ 2, 6, 0 ], [ 2, 7, 0 ], [ 2, 8, 0 ], [ 2, 9, 0 ],
			[ 2, 10, 3 ], [ 2, 11, 2 ], [ 2, 12, 1 ], [ 2, 13, 9 ],
			[ 2, 14, 8 ], [ 2, 15, 10 ], [ 2, 16, 6 ], [ 2, 17, 5 ],
			[ 2, 18, 5 ], [ 2, 19, 5 ], [ 2, 20, 7 ], [ 2, 21, 4 ],
			[ 2, 22, 2 ], [ 2, 23, 4 ], [ 3, 0, 7 ], [ 3, 1, 3 ], [ 3, 2, 0 ],
			[ 3, 3, 0 ], [ 3, 4, 0 ], [ 3, 5, 0 ], [ 3, 6, 0 ], [ 3, 7, 0 ],
			[ 3, 8, 1 ], [ 3, 9, 0 ], [ 3, 10, 5 ], [ 3, 11, 4 ], [ 3, 12, 7 ],
			[ 3, 13, 14 ], [ 3, 14, 13 ], [ 3, 15, 12 ], [ 3, 16, 9 ],
			[ 3, 17, 5 ], [ 3, 18, 5 ], [ 3, 19, 10 ], [ 3, 20, 6 ],
			[ 3, 21, 4 ], [ 3, 22, 4 ], [ 3, 23, 1 ], [ 4, 0, 1 ], [ 4, 1, 3 ],
			[ 4, 2, 0 ], [ 4, 3, 0 ], [ 4, 4, 0 ], [ 4, 5, 1 ], [ 4, 6, 0 ],
			[ 4, 7, 0 ], [ 4, 8, 0 ], [ 4, 9, 2 ], [ 4, 10, 4 ], [ 4, 11, 4 ],
			[ 4, 12, 2 ], [ 4, 13, 4 ], [ 4, 14, 4 ], [ 4, 15, 14 ],
			[ 4, 16, 12 ], [ 4, 17, 1 ], [ 4, 18, 8 ], [ 4, 19, 5 ],
			[ 4, 20, 3 ], [ 4, 21, 7 ], [ 4, 22, 3 ], [ 4, 23, 0 ],
			[ 5, 0, 2 ], [ 5, 1, 1 ], [ 5, 2, 0 ], [ 5, 3, 3 ], [ 5, 4, 0 ],
			[ 5, 5, 0 ], [ 5, 6, 0 ], [ 5, 7, 0 ], [ 5, 8, 2 ], [ 5, 9, 0 ],
			[ 5, 10, 4 ], [ 5, 11, 1 ], [ 5, 12, 5 ], [ 5, 13, 10 ],
			[ 5, 14, 5 ], [ 5, 15, 7 ], [ 5, 16, 11 ], [ 5, 17, 6 ],
			[ 5, 18, 0 ], [ 5, 19, 5 ], [ 5, 20, 3 ], [ 5, 21, 4 ],
			[ 5, 22, 2 ], [ 5, 23, 0 ], [ 6, 0, 1 ], [ 6, 1, 0 ], [ 6, 2, 0 ],
			[ 6, 3, 0 ], [ 6, 4, 0 ], [ 6, 5, 0 ], [ 6, 6, 0 ], [ 6, 7, 0 ],
			[ 6, 8, 0 ], [ 6, 9, 0 ], [ 6, 10, 1 ], [ 6, 11, 0 ], [ 6, 12, 2 ],
			[ 6, 13, 1 ], [ 6, 14, 3 ], [ 6, 15, 4 ], [ 6, 16, 0 ],
			[ 6, 17, 0 ], [ 6, 18, 0 ], [ 6, 19, 0 ], [ 6, 20, 1 ],
			[ 6, 21, 2 ], [ 6, 22, 2 ], [ 6, 23, 6 ] ];
	
	option = {
		visualMap : {
			max : 20,
			inRange : {
				color : [ '#313695', '#4575b4', '#74add1', '#abd9e9',
						'#e0f3f8', '#ffffbf', '#fee090', '#fdae61', '#f46d43',
						'#d73027', '#a50026' ]
			}
		},
		xAxis3D : {
			type : 'category',
			axisLabel : {
				show : true,
				textStyle : {
					color : '#fff'
				}
			},
			data : hours
		},
		yAxis3D : {
			type : 'category',
			axisLabel : {
				show : true,
				textStyle : {
					color : '#fff'
				}
			},
			data : days
		},
		zAxis3D : {
			axisLabel : {
				show : true,
				textStyle : {
					color : '#fff'
				}
			},
			type : 'value'
		},
		grid3D : {
			boxWidth : 200,
			boxDepth : 80,
			viewControl : {
				projection : 'orthographic'
			},
			light : {
				main : {
					intensity : 1.2,
					shadow : true
				},
				ambient : {
					intensity : 0.3
				}
			}
		},tooltip : {
			 /*  trigger: 'axis' */
			show : true,   //默认显示
            showContent:true, //是否显示提示框浮层
	         formatter: function (params,ticket,callback) {
	             var res = params[1]+   '<br/>'+"XX人数"+' : ' + params[2];
	             return res;
	         }
		},
		series : [ {
			type : 'bar3D',
			data : data.map(function(item) {
				return {
					value : [ item[1], item[0], item[2] ]
				}
			}),
			shading : 'lambert',

			label : {
				textStyle : {
					fontSize : 16,
					borderWidth : 1
				}
			},
			emphasis : {
				label : {
					textStyle : {
						fontSize : 20,
						color : '#900'
					}
				},
				itemStyle : {
					color : '#900'
				}
			}
		} ]
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}
/*******************************************************************************
 * 图表：不同问题每个环节的处理效率大数据分析
 * @returns 图形展示 liuhai
 */
function echice_vertical(id,legend_data,series_data) {
	var dom = document.getElementById(id);
	var myChart = echarts.init(dom);
	var app = {};
	var	option = {
		backgroundColor: '#1C86EE',
	    tooltip : {
	        trigger: 'item',
	        formatter: "{a} <br/>{b} : {c} ({d}%)"
	    },
	    legend: {
	        bottom: 10,
	        left: 'center',
	        data: legend_data
	    },
	    series : [
	        {
	            type: 'pie',
	            radius : '65%',
	            center: ['50%', '50%'],
	            selectedMode: 'single',
	            data:series_data,
	            itemStyle: {
	                emphasis: {
	                    shadowBlur: 10,
	                    shadowOffsetX: 0,
	                    shadowColor: 'rgba(0, 0, 0, 0.5)'
	                }
	            }
	        }
	    ]
	};
	;
	if (option && typeof option === "object") {
	    myChart.setOption(option, true);
	}
}

/*******************************************************************************
 * 图表：不同问题每个环节的处理效率大数据分析
 * @returns 图形展示 liuhai
 */

function echice_equipment(id) {
	var dom = document.getElementById(id);
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		backgroundColor: '#1C86EE',
	    tooltip: {
	        trigger: 'item',
	        backgroundColor : 'rgba(0,0,250,0.2)'
	    },
	    legend: {
	        type: 'scroll',
	        bottom: 10,
	        data: (function (){
	            var list = [];
	            for (var i = 1; i <=28; i++) {
	                list.push(i + 2000 + '');
	            }
	            return list;
	        })()
	    },
	    visualMap: {
	        top: 'middle',
	        right: 10,
	        color: ['red', 'yellow'],
	        calculable: true
	    },
	    radar: {
	       indicator : [
	           { text: '预警次数', max: 400},
	           { text: 'PV变化率', max: 400},
	           { text: 'PV波动幅度', max: 400},
	           { text: '异常次数', max: 400},
	           { text: '异常时间', max: 400}
	        ]
	    },
	    series : (function (){
	        var series = [];
	        for (var i = 1; i <= 28; i++) {
	            series.push({
	                name:'设备情况分析',
	                type: 'radar',
	                symbol: 'none',
	                lineStyle: {
	                    width: 1
	                },
	                emphasis: {
	                    areaStyle: {
	                        color: 'rgba(0,250,0,0.3)'
	                    }
	                },
	                data:[
	                  {
	                    value:[
	                        (40 - i) * 10,
	                        (38 - i) * 4 + 60,
	                        i * 5 + 10,
	                        i * 9,
	                        i * i /2
	                    ],
	                    name: i + 2000 + ''
	                  }
	                ]
	            });
	        }
	        return series;
	    })()
	};;
	if (option && typeof option === "object") {
	    myChart.setOption(option, true);
	}
	
}
