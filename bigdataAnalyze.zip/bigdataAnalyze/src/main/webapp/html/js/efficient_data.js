layui.use(['table','form','laypage', 'layedit', 'laydate','jquery','layer'], function(){
	// 插件加载
	var form = layui.form,table = layui.table,laypage = layui.laypage,layer = layui.layer,layedit = layui.layedit,laydate = layui.laydate,$ = layui.jquery;
	//初始化加载
	initialization();
	 var backgroundColor;
	// 日期控件
	  laydate.render({elem: '#date',value: data_date});
	  laydate.render({ elem: '#date1',value: data_date1});
		  //初始化图形的高
	  function initialization() {
		  backgroundColor='#03050B';
		//初始化设置高
		  $("#tpthbsaait_data").height(height);
		  $("#average_score").height(height);
		  $("#category").height(h-20+'px');
		  //数据获取
		  data_display(data_date,data_date1);
	  }
	// 确定点击事件
	  form.on('submit(demo_true)', function(data){
		  var data_state=data.field.date_state;// 开始时间
		  var data_end=data.field.data_end;// 结束时间
		  //数据访问
		  data_display(data_state,data_end);
		  return false;
	  });
	  
	 //数据获取 
	  function data_display(beginDate,endDate) {
//			var index =layer.msg('数据加载中，请稍后。。。',{time:100*1000}, {
//				  icon: 16
//				  ,shade: 0.01
//				});
			
//			 $.post("/bigdataAnalyze/task/getSingleWelTaskInfo",
//					  {beginDate:beginDate,endDate:endDate,welId:welId,taskType :taskType }  ,
//					  function(data) {
//						  layer.close(index);
//						  var task=JSON.parse(data);
						  
						  //图表:已销项的问题进行各环节处理效率大数据分析
						  var legend_data=['2011年', '2012年'];
						  var yAxis_data=['巴西','印尼','美国','印度','中国','世界人口(万)'];
						  var series_data=[{ name: '2011年',
						            type: 'bar',
						            data: [18203, 23489, 29034, 104970, 131744, 630230]},{name: '2012年',
						            type: 'bar',
						            data: [19325, 23438, 31000, 121594, 134141, 681807]
						        }];
						  echies_shadow(legend_data,yAxis_data,series_data);
						  //图表：相同岗位人员处理相同环节的效率大数据分析
						  
						  
						  echies_nutrients();
						  //图表：不同问题每个环节的处理效率大数据分析
						  
						  
						  echies_category();
						  
//				});
		}  
	  });