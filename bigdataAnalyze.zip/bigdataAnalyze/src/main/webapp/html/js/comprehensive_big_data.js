layui.use(['table', 'form', 'laypage', 'layedit', 'laydate', 'jquery', 'layer',
				'element'], function() {
			// 插件加载
			var element = layui.element, form = layui.form, table = layui.table, laypage = layui.laypage, layer = layui.layer, layedit = layui.layedit, laydate = layui.laydate, $ = layui.jquery;
			// 初始化加载
			initialization();
			var backgroundColor;
			// 日期控件
			laydate.render({
						elem : '#date',
						value : data_date
					});
			laydate.render({
						elem : '#date1',
						value : data_date1
					});
			/**
			 * 函数
			 */

			function initialization() {
				backgroundColor = '#03050B';
				// 井站下啦选择加载
				pull_down();
				// 初始化设置高
				$("#implementation").height(height);
				$("#distribution").height(height);
				$("#situation").height(height);
				$("#completion_rate").height(height);
				$("#average_score").height(height);

			}
			// 下啦选择加载
			function pull_down() {
				$.post("/bigdataAnalyze/basic/getAllWelStationInfos", null,
						function(data) {
							var html_data = '';
							html_data += '<option value="">直接选择或搜索选择井站</option>';
							$.each(JSON.parse(data), function(i, item) {
										if (i == 0) {
											html_data += '<option value="'
													+ item.welId
													+ '" selected>'
													+ item.welName
													+ '</option>';
											// 第一次加载数据
											data_display(data_date, data_date1,
													item.welId, item.welName,
													'1', 'week');
										}
										html_data += '<option value="'
												+ item.welId + '">'
												+ item.welName + '</option>';
									});
							$("#modules").append(html_data);
							form.render();
						});
			}
			// 数据获取
			function data_display(beginDate, endDate, welId, welname, taskType,
					statisticsType) {
				var index = layer.msg('数据加载中，请稍后。。。', {
							time : 100 * 1000
						}, {
							icon : 16,
							shade : 0.01
						});

				/**
				 * 任务类型分布情况数据获取
				 */
				var ajax1 = $
						.post(
								"/bigdataAnalyze/syntheticalTask/getTaskCountOfAllType",
								{
									beginDate : beginDate,
									endDate : endDate,
									welId : welId
								}, function(data) {
									var syntheticalTask = JSON.parse(data);
									// 任务类型分布情况
									var id = 'distribution';
									var legend_data = ['巡回检查', '维护保养', '动态分析',
											'临时任务', '属地监督'];
									var series_data = syntheticalTask;
									echies_pir(id, legend_data, series_data);
								});

				/**
				 * 任务的执行情况统计
				 */
				var ajax2 = $.post(
						"/bigdataAnalyze/syntheticalTask/getTaskCountOfState",
						{
							beginDate : beginDate,
							endDate : endDate,
							welId : welId
						}, function(data) {
							var syntheticalTask = JSON.parse(data);
							// 所有任务的执行情况统计
							var data_legendData = ['已完成', '未完成', '超期完成',
									'即将超期', '超期未完成'];
							var data_selected = {
								已完成 : true,
								未完成 : true,
								超期完成 : true,
								即将超期 : true,
								超期未完成 : true
							};
							var data_seriesData = syntheticalTask;

							echies_columnar(data_legendData, data_selected,
									data_seriesData);
						});

				/**
				 * 获取每个任务的完成情况数据
				 */
				var ajax3 = $
						.post(
								"/bigdataAnalyze/syntheticalTask/getTaskCountOfTaskStateByTaskType",
								{
									beginDate : beginDate,
									endDate : endDate,
									welId : welId
								}, function(data) {
									var syntheticalTask = JSON.parse(data);
									localStorage.setItem("taskData", data);
									/*
									 * console.log(syntheticalTask);
									 * console.log(syntheticalTask.inspection);
									 */
									getTaskCountOfTaskStateByTaskType(taskType);
								});

				/**
				 * 获取每种任务的完成率排名数据
				 */
				var ajax4 = $
						.post(
								"/bigdataAnalyze/syntheticalTask/getTaskFinnishRateRank",
								{
									/*
									 * beginDate : beginDate, endDate : endDate,
									 */
									welId : welId,
									statisticsType : statisticsType
									// 统计方式
								}, function(data) {
									var syntheticalTask = JSON.parse(data);

									var legend_data = syntheticalTask.nameData;
									var radar_data = {
										indicator : [{
													text : '巡回检查',
													max : 100
												}, {
													text : '维护保养',
													max : 100
												}, {
													text : '动态分析',
													max : 100
												}, {
													text : '临时任务',
													max : 100
												}, {
													text : '属地监督',
													max : 100
												}]
									};
									echies_scroll(legend_data, radar_data,
											syntheticalTask.valueData);
								});

				/**
				 * 每种任务的平均得分大数据分析数据获取
				 */
				var ajax5 = $.post(
						"/bigdataAnalyze/syntheticalTask/getScoreOfTaskType", {
							beginDate : beginDate,
							endDate : endDate,
							welId : welId
						}, function(data) {

							var syntheticalTask = JSON.parse(data);
							var series_data = syntheticalTask.valueData;
							echies_ratees(syntheticalTask.nameData, series_data)
						});

				/**
				 * 所有请求结束后执行
				 */
				$.when(ajax1, ajax2, ajax3, ajax4, ajax5).done(function() {
							layer.close(index);
						});
			}

			// 确定按钮监听
			form.on('submit(demo_true)', function(data) {
						var name = $("#modules option:selected").text();
						var modules = data.field.modules;// 井站id
						var data_state = data.field.date_state;// 开始时间
						var data_end = data.field.data_end;// 结束时间
						var task_type = data.field.task_type;// 任务类型
						var statisticsType = data.field.statisticsType// 统计类型
						//console.log(data);
						// 数据访问
						data_display(data_state, data_end, modules, name,
								task_type, statisticsType);
						return false;
					});

			// 任务类型选择事件监听
			form.on('select(task_type)', function(data) {
						var task_type = data.value;
						getTaskCountOfTaskStateByTaskType(task_type);

						return false;
					});

			form.on('select(statisticsType)', function(data) {
						var statisticsType = data.value;
						
						var welId = $("#modules").val();
						//console.log("welId:"+welId);
						
						setRateRankCharts(statisticsType,null,welId);
						return false;
					});

		});

/**
 * 获取指定任务类型的任务状态数据
 */
function getTaskCountOfTaskStateByTaskType(task_type) {
	$ = layui.jquery;

	var taskData = JSON.parse(localStorage.getItem("taskData"));
	if (!taskData) {
		// console.log(">>>>>>>>>>发送请求");
		var ajax3 = $
				.post(
						"/bigdataAnalyze/syntheticalTask/getTaskCountOfTaskStateByTaskType",
						{
							beginDate : beginDate,
							endDate : endDate,
							welId : welId
						}, function(data) {
							var syntheticalTask = JSON.parse(data);
							localStorage.setItem(data);
							taskData = syntheticalTask;
						});

	} else {
		// console.log(">>>>>>>>>>缓存获取");
	}
	//console.log(taskData);
	var seriesData = null;
	switch (task_type) {
		case '1' :
			//console.log("task_type:" + task_type);
			seriesData = taskData.inspection;
			break;
		case '2' :
			//console.log("task_type:" + task_type);
			seriesData = taskData.tending;
			break;
		case '3' :
			seriesData = taskData.dynamicAnalysis;
			break;
		case '4' :
			seriesData = taskData.territorialSupervision;
			break;
		case '5' :
			seriesData = taskData.temporary;
			break;

	}
	//console.log("seriesData:" + seriesData);
	echies_process(seriesData);

}

/**
 * 根据统计类型设置任务的完成率排名统计图
 * 
 * @param {}
 *            statisticsType
 * @param {}
 *            data
 */
function setRateRankCharts(statisticsType, syntheticalTask,welId) {
	$ = layui.jquery;

	if (syntheticalTask) {
		var legend_data = syntheticalTask.nameData;
		var radar_data = {
			indicator : [{
						text : '巡回检查',
						max : 100
					}, {
						text : '维护保养',
						max : 100
					}, {
						text : '动态分析',
						max : 100
					}, {
						text : '临时任务',
						max : 100
					}, {
						text : '属地监督',
						max : 100
					}]
		};
		echies_scroll(legend_data, radar_data, syntheticalTask.valueData);
		return;
	}

	var ajax4 = $.post(
			"/bigdataAnalyze/syntheticalTask/getTaskFinnishRateRank", {
				/*
				 * beginDate : beginDate, endDate : endDate,
				 */
				welId : welId,
				statisticsType : statisticsType
				// 统计方式
		}	, function(data) {
				var syntheticalTask = JSON.parse(data);
				var legend_data = syntheticalTask.nameData;
				var radar_data = {
					indicator : [{
								text : '巡回检查',
								max : 100
							}, {
								text : '维护保养',
								max : 100
							}, {
								text : '动态分析',
								max : 100
							}, {
								text : '临时任务',
								max : 100
							}, {
								text : '属地监督',
								max : 100
							}]
				};
				echies_scroll(legend_data, radar_data,
						syntheticalTask.valueData);
			});

}
