layui.use(
		['table', 'form', 'laypage', 'layedit', 'laydate', 'jquery', 'layer'],
		function() {
			// 插件加载
			var form = layui.form, table = layui.table, laypage = layui.laypage, layer = layui.layer, layedit = layui.layedit, laydate = layui.laydate, $ = layui.jquery;
			// 初始化加载
			initialization();
			var backgroundColor;
			// 日期控件
			laydate.render({
						elem : '#date',
						value : data_date
					});
			laydate.render({
						elem : '#date1',
						value : data_date1
					});

			// 初始化图形的高
			function initialization() {
				// 初始化设置高
				$("#statistics").height(height);
				$("#completion_rates").height(height);
				$("#Score").height(height);
				$("#completion_rate").height(height);
				$("#average_score").height(height);

				data_display(data_date, data_date1);
			}
			// 数据加载
			function data_display(beginDate, endDate) {
				var index = layer.msg('数据加载中，请稍后。。。', {
							time : 100 * 1000
						}, {
							icon : 16,
							shade : 0.01
						});

				/**
				 * 多个井站每种任务的数量统计对比
				 */
				var ajax1 = $.post("/bigdataAnalyze/syntheticalTaskOfWels/getCountOfWelByType",
								{
									beginDate : beginDate,
									endDate : endDate
								}, function(data) {
									var task = JSON.parse(data);
									var legend_data = ['巡回检查', '维护保养', '动态分析',
											'属地监督', '临时任务'];

									var xAxis_data = task.welName;// 井站名称
									var series_data = [{
												name : '巡回检查',
												type : 'bar',
												stack : '任务数量',
												label : {
													normal : {
														show : true,
														position : 'insideRight'
													}
												},
												data : task.inspection
											}, {
												name : '维护保养',
												type : 'bar',
												stack : '任务数量',
												label : {
													normal : {
														show : true,
														position : 'insideRight'
													}
												},
												data : task.tending
											}, {
												name : '动态分析',
												type : 'bar',
												stack : '任务数量',
												label : {
													normal : {
														show : true,
														position : 'insideRight'
													}
												},
												data : task.dynamicAnalysis
											}, {
												name : '属地监督',
												type : 'bar',
												stack : '任务数量',
												label : {
													normal : {
														show : true,
														position : 'insideRight'
													}
												},
												data : task.territorialSupervision
											}, {
												name : '临时任务',
												type : 'bar',
												stack : '任务数量',
												label : {
													normal : {
														show : true,
														position : 'insideRight'
													}
												},
												data : task.temporary
											}];

									echies_statistics(legend_data, xAxis_data,
											series_data);
								});
				/**
				 * 多个井站间的任务完成率大数据分析
				 */
				var ajax2 = $.post("/bigdataAnalyze/syntheticalTaskOfWels/getFinishRateOfWelsByType",
								{
									beginDate : beginDate,
									endDate : endDate
								}, function(data) {
									var task = JSON.parse(data);
									var legend_data = task.legendData;
									echies_rates(legend_data, task.seriesData);

								});
				/**
				 * 五种任务的得分大数据对比分析
				 */
				var ajax3 = $.post("/bigdataAnalyze/syntheticalTaskOfWels/getTaskScoreOfWels",
								{
									beginDate : beginDate,
									endDate : endDate
								}, function(data) {
									var task = JSON.parse(data);

									console.log(task.legendData);
									console.log(task.data);
									echies_Score(task.legendData, task.data);
								});
				/**
				 * 多井站月度综合任务大数据分析
				 */
				var ajax4 = $.post(
								"/bigdataAnalyze/syntheticalTaskOfWels/getTaskScoreByMonth",
								{
									beginDate : beginDate,
									endDate : endDate
								}, function(data) {
									var task = JSON.parse(data);
									/*task.data.push({
										name:'标准值',
										data:[60,60,60,60,60,60,60,60,60,60,60,60],
										type:'radar'
									});*/
									echies_radar(task.legendData, task.data);
								});

				/**
				 * 不同井站综合任务总得分大数据对比分析
				 */
				var ajax5 = $.post(
						"/bigdataAnalyze/syntheticalTaskOfWels/getTaskScore", {
							beginDate : beginDate,
							endDate : endDate
						}, function(data) {
							var task = JSON.parse(data);
							
							echies_nutrients(task.xData,task.yData);
						});

				$.when(ajax1, ajax2, ajax3, ajax4, ajax5).done(function() {
							layer.close(index);
						});

				/**
				 * 确定按钮绑定提交事件
				 */
				form.on('submit(demo_true)', function(data) {
							var startDate = data.field.date_state;
							var endDate = data.field.data_end;
							data_display(startDate, endDate);
							return false;
						});

			}
		});
