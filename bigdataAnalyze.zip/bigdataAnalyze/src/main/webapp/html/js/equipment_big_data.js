layui.config({
	base: './js/'
}).extend({
	formSelects: 'formSelects'
}).use(
		['table', 'form', 'laypage', 'layedit', 'laydate', 'jquery', 'layer'],
		function() {
			// 插件加载
			var form = layui.form, formSelects = layui.formSelects, table = layui.table, laypage = layui.laypage, layer = layui.layer, layedit = layui.layedit, laydate = layui.laydate, $ = layui.jquery;
			// 初始化加载
			initialization();
			var backgroundColor;
			// 日期控件
			laydate.render({
						elem : '#date',
						value : data_date
					});
			laydate.render({
						elem : '#date1',
						value : data_date1
					});
			// 初始化图形的高
			function initialization() {

				backgroundColor = '#03050B';
				// 初始化设置高
				$("#equ_total_situation_an").height(height);
				$("#equ_class_num").height(height);
				$("#equ_wel_num").height(height);
				$("#equ_num_condition").height(height);
				$("#equ_subclass_num").height(height);

				$("#single_equ_statistics_verify").height(height);
				$("#single_equ_statistics_noverify").height(height);
				$("#class_equ_statistics").height(height);

				$("#subclass_equ_statistics_verify").height(height);
				$("#subclass_equ_statistics_noverify").height(height);
				$("#class_equ_statistics_wels").height(height);
				$("#subclass_equ_statistics_verify_wels").height(height);
				$("#subclass_equ_statistics_noverify_wels").height(height);
				$("#wels_condition1").height(height);

				// 初始化井站下拉
				pull_down();

			}

			/**
			 * 井站下拉初始化
			 */
			function pull_down() {
				$
						.post(
								"/bigdataAnalyze/equipmentAnalyze/getWelIInfoAndEquClass",
								null, function(data) {
									var html_data = '';
									html_data += '<option value="">直接选择或搜索选择井站</option>';
									$.each(JSON.parse(data).wel_info, function(
													i, item) {
												if (i == 0) {
													html_data += '<option value="'
															+ item.wel_id
															+ '" selected="selected">'
															+ item.wel_name
															+ '</option>';
													// 数据获取
													data_display(data_date,
															data_date1,
															item.wel_id, null);
													return true;
												}
												html_data += '<option  value="' 
														+ item.wel_id + '">'
														+ item.wel_name
														+ '</option>';
											});
									$("#modules").append(html_data);
									formSelects.render();
								});
			}

			/**
			 * 按逐个设备分析（需要校验设备）
			 */
			function ajax1(beginDate, endDate, ifVerify, welId) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getRecordInfoByDevice',
								{
									beginDate : beginDate,
									endDate : endDate,
									ifVerify : '1',
									welId : 'de3c680563824bf29250c5915072cfe5'
								}, function(data) {
									var dataJson = JSON.parse(data);
									radar(dataJson.data, null,
											dataJson.indicator,
											'single_equ_statistics_verify');
								});
				return ajax;
			}

			/**
			 * 按逐个设备分析（不需要校验设备）
			 */
			function ajax2(beginDate, endDate, ifVerify, welId) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getRecordInfoByDevice',
								{
									beginDate : beginDate,
									endDate : endDate,
									ifVerify : '2',
									welId : 'de3c680563824bf29250c5915072cfe5'
								}, function(data) {
									var dataJson = JSON.parse(data);
									radar(dataJson.data, null,
											dataJson.indicator,
											'single_equ_statistics_noverify');
								});
				return ajax;
			}

			/**
			 * 按设备大类分析
			 */
			function ajax3(beginDate, endDate, welId) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getRecordInfoByClass',
								{
									beginDate : beginDate,
									endDate : endDate,
									welId : welId
								}, function(data) {
									var dataJson = JSON.parse(data);
									radar(dataJson.data, dataJson.legendData,
											dataJson.indicator,
											'class_equ_statistics');
								});

				return ajax;
			}

			/**
			 * 按设备小类分析（需要校验设备）
			 */
			function ajax4(beginDate, endDate, ifVerify, welId) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getRecordInfoBySubclass',
								{
									beginDate : beginDate,
									endDate : endDate,
									ifVerify : ifVerify,
									welId : welId
								}, function(data) {
									var dataJson = JSON.parse(data);
									radar(dataJson.data, dataJson.legendData,
											dataJson.indicator,
											'subclass_equ_statistics_verify');
								});
				return ajax;
			}

			/**
			 * 按设备小类分析（不需要校验设备）
			 */
			function ajax5(beginDate, endDate, ifVerify, welId) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getRecordInfoBySubclass',
								{
									beginDate : beginDate,
									endDate : endDate,
									ifVerify : ifVerify,
									welId : welId
								}, function(data) {
									var dataJson = JSON.parse(data);
									radar(dataJson.data, dataJson.legendData,
											dataJson.indicator,
											'subclass_equ_statistics_noverify');
								});
				return ajax;
			}

			/**
			 * 多井站设备分析（按设备大类分析）
			 */

			function ajax6(beginDate, endDate, welIds) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getRecordInfoOfWelsByClass',
								{
									beginDate : beginDate,
									endDate : endDate,
									welIds : welIds
								}, function(data) {
									var dataJson = JSON.parse(data);
									radar_wels(dataJson.seriesData,
											dataJson.legendData,
											'class_equ_statistics_wels', null);
								});
				return ajax;
			}

			/**
			 * 多井站站需校验设备分析（按设备小类分析）
			 */
			function ajax7(beginDate, endDate, ifVerify, welIds) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getRecordInfoOfWelsBySubclass',
								{
									beginDate : beginDate,
									endDate : endDate,
									ifVerify : ifVerify,
									welIds : welIds
								}, function(data) {
									var dataJson = JSON.parse(data);
									radar_wels(
											dataJson.seriesData,
											dataJson.legendData,
											'subclass_equ_statistics_verify_wels',
											ifVerify);
								});
				return ajax;
			}

			/**
			 * 多井站站不需校验设备分析（按设备小类分析）
			 */

			function ajax8(beginDate, endDate, ifVerify, welIds) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getRecordInfoOfWelsBySubclass',
								{
									beginDate : beginDate,
									endDate : endDate,
									ifVerify : ifVerify,
									welIds : welIds
								}, function(data) {
									var dataJson = JSON.parse(data);
									radar_wels(
											dataJson.seriesData,
											dataJson.legendData,
											'subclass_equ_statistics_noverify_wels',
											ifVerify);
								});
				return ajax;
			}

			/**
			 * 设备完好率及分析图
			 */
			function ajax9(beginDate, endDate) {
				var ajax = $.post(
						'/bigdataAnalyze/equipmentAnalyze/getEquipSituation', {
							"beginDate" : beginDate,
							"endDate" : endDate
						}, function(data) {
							var dataJson = JSON.parse(data);
							loadTable(dataJson);
							/**
							 * 加载设备完好率统计图
							 */
							bar(dataJson.tHead, dataJson.numData,
									dataJson.exceptionNumData,
									dataJson.rateData);
						});
				return ajax;
			}

			function ajax10(beginDate, endDate) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getEquipSituationOfWels',
								{
									beginDate : beginDate,
									endDate : endDate
								}, function(data) {
									var dataJson = JSON.parse(data);
									loadTable2(dataJson);
								});
				return ajax;
			}

			function ajax11(welIds, equClasses) {
				var ajax = $.post(
						'/bigdataAnalyze/equipmentAnalyze/getCountOfEquClass',
						{
							welIds : welIds,
							equClasses : equClasses
						}, function(data) {
							var dataJson = JSON.parse(data);
							pie_rose(dataJson.legendData, dataJson.data,
									'equ_class_num');
						});
				return ajax;
			}

			function ajax12(welIds, equClasses) {
				var ajax = $.post(
						'/bigdataAnalyze/equipmentAnalyze/getCountOfWel', {
							welIds : welIds,
							equClasses : equClasses
						}, function(data) {
							var dataJson = JSON.parse(data);
							pie_rose(dataJson.legendData, dataJson.data,
									'equ_wel_num');
						});
				return ajax;
			}

			function ajax13(welIds, equClasses) {
				var ajax = $.post(
						'/bigdataAnalyze/equipmentAnalyze/getEqumentInfo', {
							welIds : welIds,
							equClasses : equClasses
						}, function(data) {
							var dataJson = JSON.parse(data);
							/**
							 * 加载数据表格
							 */
							load_table3(dataJson);

						});
				return ajax;
			}

			function ajax14(beginDate, endDate) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getEquSituationOfWel',
								{
									beginDate : beginDate,
									endDate : endDate
								}, function(data) {
									var dataJson = JSON.parse(data);
									load_table4(dataJson);
								});
				return ajax;
			}

			function ajax15(beginDate, endDate) {
				var ajax = $
						.post(
								'/bigdataAnalyze/equipmentAnalyze/getEquSituationOfSubclass',
								{
									beginDate : beginDate,
									endDate : endDate
								}, function(data) {
									var dataJson = JSON.parse(data);
									load_table5(dataJson);
								});
				return ajax;
			}

			function ajax16(welIds, equClasses) {
				var ajax = $.post(
						'/bigdataAnalyze/equipmentAnalyze/getCountOfSubclass',
						{
							welIds : welIds,
							equClasses : equClasses
						}, function(data) {
							var dataJson = JSON.parse(data);
							pie_rose(dataJson.legendData, dataJson.data,
									'equ_subclass_num');
						});
				return ajax;
			}

			function loadTable(dataJson) {
				var tHeadData = dataJson.tHead;

				var tHead = [];
				var tHead1 = [];// 一级表头
				var tHead2 = [];// 二级表头

				var i = 1;
				tHeadData.forEach(function(value, index, tHeadData) {
							tHead1.push({
										title : value,
										width : 80,
										colspan : 3
									});
							tHead2.push({
										field : 'NUM' + i,
										title : '数量',
										width : 80
									});
							tHead2.push({
										field : 'EXCEPTION_NUM' + i,
										title : '异常',
										width : 80
									});
							tHead2.push({
										field : 'SERVICEABILITY_RATE' + i,
										title : '完好率',
										width : 80
									});
							i = i + 1;
						});
				tHead.push(tHead1);
				tHead.push(tHead2);
				/**
				 * 加载数据表格
				 */

				table.render({
							elem : '#equ_total_situation',// 指定原始表格元素选择器（推荐id选择器）
							cols : tHead,
							even : true,
							done : function(res, curr, count) {
								$('tr').css({
											'background-color' : '#1C86EE',
											'color' : 'white'
										});
								$('a').css({
											'color' : 'white'
										});
								$('span').css({
											'color' : 'white'
										});
							},
							data : dataJson.tData
						});
			}

			function loadTable2(dataJson) {
				var tHeadData = dataJson.tHead;

				var tHead = [];
				var tHead1 = [];// 一级表头
				var tHead2 = [];// 二级表头

				tHead1.push({
							field : 'SERIAL_NUM',
							title : '序号',
							width : 80,
							rowspan : 2
						});
				tHead1.push({
							field : 'WEL_NAME',
							title : '井站',
							width : 150,
							rowspan : 2
						});

				var i = 1;
				tHeadData.forEach(function(value, index, tHeadData) {
							tHead1.push({
										title : value,
										width : 80,
										colspan : 3
									});
							tHead2.push({
										field : 'NUM' + i,
										title : '数量',
										width : 80
									});
							tHead2.push({
										field : 'EXCEPTION_NUM' + i,
										title : '异常',
										width : 80
									});
							tHead2.push({
										field : 'SERVICEABILITY_RATE' + i,
										title : '完好率',
										width : 80
									});
							i = i + 1;
						});
				tHead1.push({
							title : '汇总',
							width : 80,
							colspan : 3
						});
				tHead2.push({
							field : 'total_num',
							title : '数量',
							width : 80
						});
				tHead2.push({
							field : 'tatal_exception_num',
							title : '异常',
							width : 80
						});
				tHead2.push({
							field : 'total_rate',
							title : '完好率',
							width : 80
						});

				tHead.push(tHead1);
				tHead.push(tHead2);
				/**
				 * 加载数据表格
				 */

				table.render({
					elem : '#equ_wel_situation',// 指定原始表格元素选择器（推荐id选择器）
					cols : tHead,
					height : height,
					page : true,
					even : true,// 开启隔行背景
					count : dataJson.tData,
					curr : 0,
					limit : 10,
					limits : [10, 15, 20, 25, 30],
					layout : ['prev', 'page', 'next', 'skip', 'count', 'limit'],
					even : true,
					done : function(res, curr, count) {
						$('tr').css({
									'background-color' : '#1C86EE',
									'color' : 'white'
								});
						$('a').css({
									'color' : 'white'
								});
						$('span').css({
									'color' : 'white'
								});
					},
					data : dataJson.tData
				});
			}

			function load_table3(dataJson) {
				table.render({
					elem : '#equ_detail',// 指定原始表格元素选择器（推荐id选择器）
					height : height,
					page : true,
					even : true,// 开启隔行背景
					count : dataJson.tData,
					curr : 0,
					limit : 10,
					limits : [10, 15, 20, 25, 30],
					layout : ['prev', 'page', 'next', 'skip', 'count', 'limit'],
					even : true,
					//toolbar:'default',
					cols : [[{
								field : 'EQU_NAME',
								title : '设备名称',
								width : 150,
								fixed : true
							}, {
								field : 'WEL_NAME',
								title : '井站名称',
								width : 150
							}, {
								field : 'EQU_MEMO_THREE',
								title : '设备大类',
								width : 150
							}, {
								field : 'EQU_TYPE_NAME',
								title : '设备小类',
								width : 150
							}, {
								field : 'EQU_RFID',
								title : 'RFID',
								width : 150
							}, {
								field : 'EQU_MODEL',
								title : '设备型号',
								width : 150
							}, {
								field : 'EQU_PRODUC_DATE',
								title : '出厂日期',
								width : 150
							}, {
								field : 'EQU_COMMISSION_DATE',
								title : '投运日期',
								width : 150
							}, {
								field : 'EQU_INSTALL_POSITION',
								title : '安装位置',
								width : 150
							}, {
								field : 'EQU_MANUFACTURER',
								title : '生产厂家',
								width : 150
							}, {
								field : 'EQU_POSITION_NUM',
								title : '设备位号',
								width : 150
							}, {
								field : 'EQU_SN',
								title : '产品序列号',
								width : 150
							}]],
					done : function(res, curr, count) {
						$('tr').css({
									'background-color' : '#1C86EE',
									'color' : 'white'
								});
						$('a').css({
									'color' : 'white'
								});
						$('span').css({
									'color' : 'white'
								});
					},

					data : dataJson.data
				});
			}

			function load_table4(dataJson) {
				table.render({
					elem : '#wel_equ_situantion',// 指定原始表格元素选择器（推荐id选择器）
					height : height,
					page : true,
					even : true,// 开启隔行背景
					count : dataJson.tData,
					curr : 0,
					limit : 10,
					limits : [10, 15, 20, 25, 30],
					layout : ['prev', 'page', 'next', 'skip', 'count', 'limit'],
					even : true,
					cols : [[{
								field : 'WEL_NAME',
								title : '井站名称',
								width : 150,
								fixed : true
							}, {
								field : 'NUM',
								title : '数量',
								width : 100
							}, {
								field : 'EXCEPTION_NUM',
								title : '异常',
								width : 100
							}, {
								field : 'SERVICEABILITY_RATE',
								title : '完好率',
								width : 100
							}]],
					done : function(res, curr, count) {
						$('tr').css({
									'background-color' : '#1C86EE',
									'color' : 'white'
								});
						$('a').css({
									'color' : 'white'
								});
						$('span').css({
									'color' : 'white'
								});
					},

					data : dataJson.data
				});
			}

			function load_table5(dataJson) {
				table.render({
					elem : '#subclass_equ_situantion',// 指定原始表格元素选择器（推荐id选择器）
					height : height,
					page : true,
					even : true,// 开启隔行背景
					count : dataJson.tData,
					curr : 0,
					limit : 10,
					limits : [10, 15, 20, 25, 30],
					layout : ['prev', 'page', 'next', 'skip', 'count', 'limit'],
					even : true,
					cols : [[{
								field : 'SUBCLASS',
								title : '设备小类',
								width : 150,
								fixed : true
							}, {
								field : 'NUM',
								title : '数量',
								width : 100
							}, {
								field : 'EXCEPTION_NUM',
								title : '异常',
								width : 100
							}, {
								field : 'SERVICEABILITY_RATE',
								title : '完好率',
								width : 100
							}]],
					done : function(res, curr, count) {
						$('tr').css({
									'background-color' : '#1C86EE',
									'color' : 'white'
								});
						$('a').css({
									'color' : 'white'
								});
						$('span').css({
									'color' : 'white'
								});
					},

					data : dataJson.data
				});
			}

			// 确定点击事件
			form.on('submit(demo_true)', function(data) {
						console.log(">>>>>>>>>>>>>>");
						var data_state = data.field.date_state;// 开始时间
						var data_end = data.field.data_end;// 结束时间
						var wels = formSelects.value('select', 'valStr');
						if(wels==null || wels ==""){
							wels = '64532c29f7594a8fb7c9041a099925c5';
						}
						
						console.log(wels);
						// 数据访问
						data_display(data_state, data_end, wels);
						return false;
					});

			// 数据获取
			function data_display(beginDate, endDate, welIds) {
				var index = layer.msg('数据加载中，请稍后。。。', {
							time : 100 * 1000
						}, {
							icon : 16,
							shade : 0.01
						});
				var welId = welIds.split(",")[0];
				console.log(welId);

				/**
				 * 按逐个设备分析（需要校验设备）
				 */
				var ajax_1 = ajax1(beginDate, endDate, '1', welId);

				/**
				 * 按逐个设备分析（不需要校验设备）
				 */
				var ajax_2 = ajax2(beginDate, endDate, '2', welId);

				/**
				 * 按设备大类分析
				 */
				var ajax_3 = ajax3(beginDate, endDate, welId);

				/**
				 * 按设备小类分析（需要校验设备）
				 */
				var ajax_4 = ajax4(beginDate, endDate, '1', welId);

				/**
				 * 按设备小类分析（不需要校验设备）
				 */
				var ajax_5 = ajax5(beginDate, endDate, '2', welId);

				/**
				 * 多井站站需校验设备分析（按设备大类分析） 注：最后一个参数为多个井站id
				 */
				var ajax_6 = ajax6(beginDate, endDate, welIds);

				/**
				 * 多井站站需校验设备分析（按设备小类分析）
				 */
				var ajax_7 = ajax7(beginDate, endDate, '1', welIds);

				/**
				 * 多井站站不需校验设备分析（按设备小类分析）
				 */
				var ajax_8 = ajax8(beginDate, endDate, '2', welIds);

				/**
				 * 设备完好率及分析图
				 */
				var ajax_9 = ajax9(beginDate, endDate);

				var ajax_10 = ajax10(beginDate, endDate);

				/**
				 * ajax11(welIds, equClasses)
				 */
				var ajax_11 = ajax11(welIds, null);

				/**
				 * ajax12(welIds, equClasses)
				 */
				var ajax_12 = ajax12(welIds, null);

				/**
				 * ajax13(welIds, equClasses)
				 */
				var ajax_13 = ajax13(welIds, null);

				var ajax_14 = ajax14(beginDate, endDate);

				var ajax_15 = ajax15(beginDate, endDate);
				/**
				 * ajax16(welIds, equClasses)
				 */
				var ajax_16 = ajax16(welIds, null);

				/**
				 * 所有请求结束后执行
				 */
				$.when(ajax_1, ajax_2, ajax_3, ajax_4, ajax_5, ajax_6, ajax_7,
						ajax_8, ajax_9, ajax_10, ajax_11, ajax_12, ajax_13,
						ajax_14, ajax_15, ajax_16).done(function() {
							layer.close(index);
						});
			}
		});