layui.use(['table','form','laypage', 'layedit', 'laydate','jquery','layer'], function(){
	// 插件加载
	var form = layui.form,table = layui.table,laypage = layui.laypage,layer = layui.layer,layedit = layui.layedit,laydate = layui.laydate,$ = layui.jquery;
	//初始化加载
	initialization();
	 var backgroundColor;
	// 日期控件
	  function initialization() {
		  backgroundColor='#03050B';
		  //初始化设置高
		  $("#implementation").height(height);
		  $("#distribution").height(height);
		  
		
		  data_display(null,null,null,null,null );
		
	  }
	  //数据获取
		function data_display(beginDate,endDate,welId,welname,taskType ) {
//			var index =layer.msg('数据加载中，请稍后。。。',{time:100*1000}, {
//				  icon: 16
//				  ,shade: 0.01
//				});
//			 $.post("/bigdataAnalyze/task/getSingleWelTaskInfo",
//					  {beginDate:beginDate,endDate:endDate,welId:welId,taskType :taskType }  ,
//					  function(data) {
//						  layer.close(index);
//						  var task=JSON.parse(data);
						  
			  //所有任务的执行情况统计
			var data_legendData=['已完成','未完成','超期完成','即将超期','超期未完成'];
			var data_selected={已完成: true,未完成: true,超期完成: true,即将超期: true,超期未完成: true};
			var data_seriesData=[{name: "已完成", value: 29128}
			,{name: "未完成", value: 29128}
			,{name: "超期完成", value: 29128}
			,{name: "即将超期", value: 29128}
			,{name: "超期未完成", value: 29128}];
			
			  echies_columnar(data_legendData,data_selected,data_seriesData);
			  //任务类型分布情况
			  var id='distribution';
			  var legend_data=[ '巡回检查', '维护保养', '动态分析', '临时任务', '属地监督'];
			  var series_data=[ 
				{value : 10,name : '巡回检查'}
			  , {value : 5,name : '维护保养'}
			  , {value : 15,name : '动态分析'}
			  , {value : 25,name : '临时任务'}
			  , {value : 20,name : '属地监督'}];
			  
			  echies_pir(id,legend_data,series_data);
			//数据表格1
			  var data_a='';
			  var elem='#test';
			  table_green(data_a,elem);
			//数据表格2
			  var data_a='';
			  var elem='#test1';
			  table_green(data_a,elem);
//				});
		}  
		 
		  // 确定
		  form.on('submit(demo_true)', function(data){
			  var name=$("#modules option:selected").text();
			  var modules=data.field.modules;// 井站IP
			  var data_state=data.field.date_state;// 开始时间
			  var data_end=data.field.data_end;// 结束时间
			  //数据访问
			  data_display(data_state,data_end,modules,name,taskType);
			  return false;
		  });
	  
		  
		  function table_green(data_a,elem) {
			  var cols_data=[];
			  var cols_data2=[];
			  for(var i=0;i<4;i++){
				  cols_data.push({align:'center',title:'设备'+i,colspan:3});
				  cols_data2.push({field:'username', width:80, title: '用户名'+i}
				      ,{field:'sex', width:80, title: '性别1'+i, sort: true}
				      ,{field:'city', width:80, title: '城市2'+i});
			  }
			  table.render({
				    elem: elem
				    ,data:null
				    ,cellMinWidth: 80 //全局定义常规单元格的最小宽度，layui 2.2.1 新增
				    ,cols: [cols_data,cols_data2]
				  });
		}
	  });