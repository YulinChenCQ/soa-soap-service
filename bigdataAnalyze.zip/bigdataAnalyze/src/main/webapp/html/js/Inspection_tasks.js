layui.use(
		['table', 'form', 'laypage', 'layedit', 'laydate', 'jquery', 'layer'],
		function() {
			// 插件加载
			var form = layui.form, table = layui.table, laypage = layui.laypage, layer = layui.layer, layedit = layui.layedit, laydate = layui.laydate, $ = layui.jquery;
			// 初始化加载
			initialization();
			var taskType;
			// 日期控件
			laydate.render({
						elem : '#date',
						value : data_date
					});
			laydate.render({
						elem : '#date1',
						value : data_date1
					});
			// 初始化设置高
			var heights = window.innerHeight / 2 - 10 + 'px';
			$("#echies_1").height(heights);
			$("#echies_2").height(heights);
			
			
			// 图标背景颜色
			var backgroundColor;
			function initialization() {
				taskType = '1';
				backgroundColor = '#0E4276';
				// 井站下啦选择加载
				pull_down();
			}

			function data_display(beginDate, endDate, welId, welname, taskType) {
				var index = layer.msg('数据加载中，请稍后。。。', {
							time : 100 * 1000
						}, {
							icon : 16,
							shade : 0.01
						});
				$.post("/bigdataAnalyze/task/getSingleWelTaskInfo", {
							beginDate : beginDate,
							endDate : endDate,
							welId : welId,
							taskType : taskType
						}, function(data) {
							layer.close(index);
							var task = JSON.parse(data);
							var schema = [];
							var parallelAxis = [];
							// 图表展示echies_1
							$.each(task.taskChart.taskNameData, function(i,
											item) {
										schema.push({
													'name' : item,
													'index' : i,
													'text' : item
												});
									});
							var data = [welname];
							var lineStyle;
							var series = [{
										name : data[0],
										type : 'parallel',
										lineStyle : lineStyle,
										data : task.taskChart.taskValueData
									}];
							echies_1(series, schema, data, data_parallelAxis,
									backgroundColor);
							// 图表展示echies_2
							echies_2(task.stepChart.stepNameData,
									task.stepChart.stepValueData,
									backgroundColor);
							// 表格數據
							var data_table = task.taskRecords.data;
							table_render(data_table);
						});
			}

			

			function pull_down() {
				$.post("/bigdataAnalyze/basic/getWelStationInfos", null,
						function(data) {
							var html_data = '';
							html_data += '<option value="">直接选择或搜索选择井站</option>';
							$.each(JSON.parse(data), function(i, item) {
								if (i == 0) {
									html_data += '<option value="' + item.welId
											+ '" selected>' + item.welName
											+ '</option>';
									// 數據加載
									data_display(data_date, data_date1,
											item.welId, item.welName, taskType);
									return true;
								}
								html_data += '<option value="' + item.welId
										+ '">' + item.welName + '</option>';
							});
							$("#modules").append(html_data);
							form.render();
						});
			}

			
			/**
			 * 监听排序
			 */
			table.on('sort(test)', function(obj) {
						console.log(obj);
					});
					
			// 确定
			form.on('submit(demo_true)', function(data) {
						var name = $("#modules option:selected").text();
						var modules = data.field.modules;// 井站IP
						var data_state = data.field.date_state;// 开始时间
						var data_end = data.field.data_end;// 结束时间
						// 数据访问
						data_display(data_state, data_end, modules, name,
								taskType);
						return false;
					});

			// 表格数据加载
			function table_render(data_table) {
				table.render({
					elem : '#test',
					height : heights,
					data : data_table,
					page : true,
					even : true // 开启隔行背景
					,
					autoSort:false,
					count : data_table.lehgth,
					curr : 0,
					limit : 10,
					limits : [10, 15, 20, 25, 30],
					layout : ['prev', 'page', 'next', 'skip', 'count', 'limit'],
					cellMinWidth : 40 // 全局定义常规单元格的最小宽度，layui 2.2.1 新增
					,
					cols : [[ // 表头
					{
								field : 'welStation',
								title : '井站名称',
								width : 150,
								fixed : 'left'
							}, {
								field : 'recordDay',
								title : '记录日期',
								width : 90
							}, {
								field : 'averageTime',
								title : '平均时间',
								width : 90
							}, {
								field : 'pictureCount',
								title : '照片数量',
								width : 90
							}, {
								field : 'dataCount',
								title : '数据个数',
								width : 90
							}, {
								field : 'rfidCount',
								title : '扫描标签数量',
								width : 120
							}, {
								field : 'descCount',
								title : '备注数量',
								width : 90
							}, {
								field : 'problemCount',
								title : '上报问题数量',
								width : 120
							}, {
								field : 'result',
								title : '得分',
								sort : true,
								width : 80
							}]],
					done : function(res, curr, count) {
						$('tr').css({
									'background-color' : '#0E4276',
									'color' : 'white'
								});
						$('a').css({
									'color' : 'white'
								});
						$('span').css({
									'color' : 'white'
								});
					}
				});
			}

			// 维度编辑——弹出层
			window.onConfigure = function() {
				var html = '';
				html += ' <form class="layui-form layui-form-pane" action="">';
				// 获取权重、标准值
				$.post("/bigdataAnalyze/basic/getGradeStandInfo", {
							taskType : taskType
						}, function(data) {
							var task = JSON.parse(data);
							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">平均时间:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.averageTimeWeightValue
									+ '" id="averageTime_W" name="averageTime_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid">标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text"  value="'
									+ task.averageTimeStandValue
									+ '"  id="averageTime_S" name="averageTime_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';
							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">图片数量:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.pictureCountWeightValue
									+ '" id="picture_W" name="picture_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.pictureCountStandValue
									+ '" id="picture_S" name="picture_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';
							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">录入个数:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.dataCountWeightValue
									+ '" id="data_W" name="data_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.dataCountStandValue
									+ '" id="data_S" name="data_S"  autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';

							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">标签数量:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.rfidCountWeightValue
									+ '" id="rfid_W" name="rfid_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid">标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.rfidCountStandValue
									+ '" id="rfid_S" name="rfid_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';

							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">备注字数量:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.descCountWeightValue
									+ '" id="desc_W" name="desc_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.descCountStandValue
									+ '" id="desc_S" name="desc_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';

							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">问题数量:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.problemCountWeightValue
									+ '" id="problem_W" name="problem_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid">标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.problemCountStandValue
									+ '" id="problem_S" name="problem_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';
							html += '<div class="layui-form-item">';
							html += '<div class="layui-input-block" style="text-align:right;">';
							html += ' <button class="layui-btn" lay-submit="" onclick="demo1figure();return false;" lay-filter="demo1">立即提交</button>';
							html += ' </div>';
							html += '</div>';
							html += ' </form>';
							layer.open({
										title : '参数设置',
										type : 1,
										area : ['450px', '450px'], // 宽高
										content : html
									});
							return false;
						});
			}

			// 维度提交按鈕
			window.demo1figure = function() {
				// 询问框
				layer.confirm('确定提交？', {
					btn : ['确定', '取消']
						// 按钮
					}, function() {
					layer.closeAll();
					var index = layer.msg('数据加载中，请稍后。。。', {
								time : 100 * 1000
							}, {
								icon : 16,
								shade : 0.01
							});
					var grade = {
						"dataCountStandValue" : $('#data_S').val(),
						"dataCountWeightValue" : $('#data_W').val(),
						"averageTimeWeightValue" : $('#averageTime_W').val(),
						"averageTimeStandValue" : $('#averageTime_S').val(),
						"rfidCountWeightValue" : $('#rfid_W').val(),
						"rfidCountStandValue" : $('#rfid_S').val(),
						"keyStepStandValue" : "",
						"keyStepWeightValue" : "",
						"problemCountWeightValue" : $('#problem_W').val(),
						"problemCountStandValue" : $('#problem_S').val(),
						"stepCountStandValue" : "",
						"stepCountWeightValue" : "",
						"pictureCountWeightValue" : $('#picture_W').val(),
						"pictureCountStandValue" : $('#picture_S').val(),
						"descCountWeightValue" : $('#desc_W').val(),
						"descCountStandValue" : $('#desc_S').val()
					};

					var weight_value = check_out_sum(grade);
					if (weight_value != 1) {
						layer.open({
									title : '错误提示',
									content : '您填写的权重信息和不为1，请重新填写配置'
								});
						return;

					}

					var data_das = {
						'taskType' : taskType,
						'beginDate' : $('#date').val(),
						'endDate' : $('#date1').val(),
						'welId' : $('#modules').val(),
						'gradeStandInfo' : JSON.stringify(grade)
					};
					$.post("/bigdataAnalyze/basic/updateGradeStandInfo",
							data_das, function(data) {
								var task = JSON.parse(data);
								var schema = [];
								var parallelAxis = [];
								// 图表展示echies_1
								$.each(task.taskChart.taskNameData, function(i,
												item) {
											schema.push({
														'name' : item,
														'index' : i,
														'text' : item
													});
										});
								var data = [$('#modules').val()];
								var lineStyle;
								var series = [{
											name : data[0],
											type : 'parallel',
											lineStyle : lineStyle,
											data : task.taskChart.taskValueData
										}];
								echies_1(series, schema, data,
										data_parallelAxis, backgroundColor);
								// 表格數據
								var data_table = task.taskRecords.data;
								table_render(data_table);
								layer.closeAll();
								return false;
							});
				}, function() {
					return false;
				});
				return false;
			}
		});