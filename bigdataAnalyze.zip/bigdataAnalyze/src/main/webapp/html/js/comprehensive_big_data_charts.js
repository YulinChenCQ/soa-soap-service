/**
 * 任务完成情况统计
 * 
 * @param {}
 *            data_legendData
 * @param {}
 *            data_selected
 * @param {}
 *            data_seriesData
 */
function echies_columnar(data_legendData, data_selected, data_seriesData) {
	var dom = document.getElementById('implementation');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;

	option = {
		backgroundColor : '#1C86EE',
		tooltip : {
			trigger : 'item',
			formatter : "{b} : {c} ({d}%)"
		},
		legend : {
			type : 'scroll',
			orient : 'vertical',
			right : 10,
			top : 20,
			bottom : 20,
			data : data_legendData,
			selected : data_selected
		},
		series : [{
					type : 'pie',
					radius : '55%',
					center : ['40%', '50%'],
					data : data_seriesData,
					itemStyle : {
						emphasis : {
							shadowBlur : 10,
							shadowOffsetX : 0,
							shadowColor : 'rgba(0, 0, 0, 0.5)'
						}
					}
				}]
	};;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 任务类型分布情况
 * 
 * @param {}
 *            id
 * @param {}
 *            legend_data
 * @param {}
 *            series_data
 */
function echies_pir(id, legend_data, series_data) {
	var dom = document.getElementById(id);
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		backgroundColor : '#1C86EE',
		tooltip : {
			trigger : 'item',
			formatter : "{a} <br/>{b} : {c} ({d}%)"
		},
		legend : {
			x : 'center',
			y : 'bottom',
			data : legend_data
		},
		toolbox : {
			show : true,
			feature : {
				mark : {
					show : true
				},
				dataView : {
					show : true,
					readOnly : false
				},
				magicType : {
					show : true,
					type : ['pie', 'funnel']
				},
				restore : {
					show : true
				},
				saveAsImage : {
					show : true
				}
			}
		},
		calculable : true,
		series : [{
					name : '任务数量',
					type : 'pie',
					radius : [30, 110],
					roseType : 'area',
					data : series_data
				}]
	};;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 每个任务的完成情况统计图
 * 
 * @param {}
 * 
 */
function echies_process(seriesData) {
	var dom = document.getElementById("situation");
	// console.log(dom);
	var myChart = echarts.init(dom);
	var app = {};
	option = null;

	option = {
		backgroundColor : '#1C86EE',
		tooltip : {
			// trigger: 'item',
			formatter : "{a} <br/>{b}: {c} ({d}%)"
		},
		legend : {
			orient : 'vertical',
			x : 'left',
			data : ['已完成', '未完成', '超期完成', '即将超期', '超期未完成']
		},
		series : [{
					name : '任务数量',
					type : 'pie',
					radius : ['50%', '70%'],
					avoidLabelOverlap : false,
					label : {
						normal : {
							show : false,
							position : 'center'
						},
						emphasis : {
							show : true,
							textStyle : {
								fontSize : '30',
								fontWeight : 'bold'
							}
						}
					},
					labelLine : {
						normal : {
							show : false
						}
					},
					data : seriesData
				}]
	};

	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}

}

/**
 * 任务的完成率排名
 * 
 * @param {}
 *            legend_data
 * @param {}
 *            radar_data
 * @param {}
 *            series_data
 */
function echies_scroll(legend_data, radar_data, series_data) {
	var dom = document.getElementById('completion_rate');
	var myChart = echarts.init(dom);
	var app = {};
	option = {
		backgroundColor : '#1C86EE',
		tooltip : {
			// trigger : 'item',
			backgroundColor : 'blue'
		},
		legend : {
			type : 'scroll',
			bottom : 10,
			data : legend_data
		},
		/*
		 * visualMap : { top : 'middle', right : 10, color : [ 'red', 'yellow' ],
		 * calculable : true },
		 */
		radar : radar_data,
		series : {
			type : 'radar',
			symbol : 'none',
			lineStyle : {
				width : 1
			},
			emphasis : {
				areaStyle : {
					color : 'rgba(0,250,0,0.3)'
				}
			},
			data : series_data
		}
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 任务平均得分
 * 
 * @param {}
 *            xAxis_data
 * @param {}
 *            series_data
 */
function echies_ratees(xAxis_data, series_data) {
	var dom = document.getElementById('average_score');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		backgroundColor : '#1C86EE',
		tooltip : {
			trigger : 'axis',
			axisPointer : { // 坐标轴指示器，坐标轴触发有效
				type : 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		grid : {
			left : '3%',
			right : '4%',
			bottom : '3%',
			containLabel : true
		},
		xAxis : [{
					type : 'category',
					data : xAxis_data,
					axisTick : {
						alignWithLabel : true
					}
				}],
		yAxis : [{
					type : 'value'
				}],
		series : [{
			name : '平均得分',
			type : 'bar',
			barWidth : '60%',
			itemStyle : {
				normal : {
					color : function(params) {
						var colorList = ['#ff4844', '#9ac3e5', '#66ac52',
								'#ffc032', '#549bd3', '#f47e39'];
						return colorList[params.dataIndex];
					}
				}
			},
			data : series_data
		}]
	};;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}