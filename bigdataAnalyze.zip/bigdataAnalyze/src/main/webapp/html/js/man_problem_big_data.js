var first_wel = '';

layui.use(
		['table', 'form', 'laypage', 'layedit', 'laydate', 'jquery', 'layer'],
		function() {

			// 插件加载
			var form = layui.form, formSelects = layui.formSelects, table = layui.table, laypage = layui.laypage, layer = layui.layer, layedit = layui.layedit, laydate = layui.laydate, $ = layui.jquery;
			// 初始化加载
			initialization();
			var backgroundColor;
			// 日期控件
			laydate.render({
						elem : '#date',
						value : data_date
					});
			laydate.render({
						elem : '#date1',
						value : data_date1
					});
			// 初始化图形的高
			var heights = window.innerHeight / 2 - 10 + 'px';

			function initialization() {
				// 井站下啦选择加载
				pull_down();
				// 初始化设置高
				$("#implementation").height(height);
				$("#distribution").height(height);
				$("#average_score").height(height);
				$("#problem_resource").height(height);
				$("#problem_grade").height(height);
				$("#problem_quality").height(height);
				$("#deal_rate").height(height);
				$("#every_node_deal_rate").height(height * 1.2);
				$("#same_node_deal_rate").height(height * 1.2);

				/**
				 * 加载echart统计图
				 */
				console.log(data_date);
				console.log(data_date1);
				data_display(data_date, data_date1, first_wel);

			}
			// 下啦选择加载
			function pull_down() {
				$.post("/bigdataAnalyze/basic/getAllWelStationInfos", null,
						function(data) {
							var html_data = '';
							html_data += '<option value="">直接选择或搜索选择井站</option>';
							$.each(JSON.parse(data), function(i, item) {
										if (i == 0) {
											html_data += '<option value="'
													+ item.welId
													+ '" selected>'
													+ item.welName
													+ '</option>';

											return true;
										}
										html_data += '<option value="'
												+ item.welId + '">'
												+ item.welName + '</option>';
										first_wel += ',' + item.welId;
									});

							$("#modules").append(html_data);
							form.render();
						});
			}

			// 数据加载
			function data_display(beginDate, endDate, wels) {
				var index = layer.msg('数据加载中，请稍后。。。', {
							time : 100 * 1000
						}, {
							icon : 16,
							shade : 0.01
						});

				/**
				 * 获取问题类型对应的问题数量
				 */
				var ajax1 = $.post(
						'/bigdataAnalyze/problemAnalyze/getCountByType', {
							beginDate : beginDate,
							endDate : endDate,
							welIds : wels
						}, function(data) {
							var problemData = JSON.parse(data);
							echice_vertical('implementation',
									problemData.legendData,
									problemData.valueData);
						});
				/**
				 * 问题的处理状态统计分析
				 */
				var ajax2 = $.post(
						'/bigdataAnalyze/problemAnalyze/getCountByState', {
							beginDate : beginDate,
							endDate : endDate,
							welIds : wels
						}, function(data) {
							var problemData = JSON.parse(data);
							echice_vertical('distribution',
									problemData.legendData,
									problemData.valueData);
						});

				/**
				 * 问题级别统计分析数据获取
				 */
				var ajax3 = $.post(
						'/bigdataAnalyze/problemAnalyze/getCountByGrade', {
							beginDate : beginDate,
							endDate : endDate,
							welIds : wels
						}, function(data) {
							var problemData = JSON.parse(data);
							echice_vertical('problem_grade',
									problemData.legendData,
									problemData.valueData);
						});
				/**
				 * 问题来源统计分析数据获取
				 */
				var ajax4 = $.post(
						'/bigdataAnalyze/problemAnalyze/getCountBySource', {
							beginDate : beginDate,
							endDate : endDate,
							welIds : wels
						}, function(data) {
							var problemData = JSON.parse(data);
							echice_vertical('problem_resource',
									problemData.legendData,
									problemData.valueData);
						});

				/**
				 * 问题上报质量分析数据获取
				 */
				var ajax5 = $.post(
						'/bigdataAnalyze/problemAnalyze/getProblemQuality', {
							beginDate : beginDate,
							endDate : endDate,
							welIds : wels
						}, function(data) {
							var problemData = JSON.parse(data);
							parallel(problemData.legendData,
									problemData.seriesData);
							table_render(problemData.tableDatas);
						});

				/**
				 * 已销项的问题进行各环节处理效率大数据分析
				 */

				var ajax6 = $
						.post(
								'/bigdataAnalyze/problemAnalyze/getTimeCostOfProblemNode',
								{
									beginDate : beginDate,
									endDate : endDate,
									welIds : wels
								}, function(data) {
									var problemData = JSON.parse(data);

									dealRate(problemData.nameData,
											problemData.valueData);
								});

				/**
				 * 不同问题每个环节的处理效率大数据分析
				 */
				var ajax7 = $
						.post(
								'/bigdataAnalyze/problemAnalyze/getTimeCostOfEveryProblemNode',
								{
									beginDate : beginDate,
									endDate : endDate,
									welIds : wels
								}, function(data) {
									var problemData = JSON.parse(data);
									var series_data = [];
									console.log(problemData);

									problemData.data.forEach(function(row) {
												var data_row = [];
												data_row.push(row);
												normalizeData(data_row);
												series_data.push({
															name : 'nutrients',
															type : 'parallel',
															lineStyle : {
																normal : {
																	width : 2,
																	opacity : 0.05
																}
															},
															inactiveOpacity : 0,
															activeOpacity : 0.01,
															progressive : 500,
															smooth : true,
															data : data_row
														});

												console.log(data_row);
											});
									parallel2(series_data);
								});

				/**
				 * 相同岗位人员处理相同环节的效率大数据分析
				 */
				var ajax8 = $
						.post(
								'/bigdataAnalyze/problemAnalyze/getPeopleEfficiencyOfProblem',
								{
									beginDate : beginDate,
									endDate : endDate,
									welIds : wels
								}, function(data) {
									var problemData = JSON.parse(data);
									echies_category(problemData.seriesData,
											problemData.yAxis3DData,
											problemData.xAxis3DData);

								});
				$.when(ajax1, ajax2, ajax3, ajax4, ajax5, ajax6, ajax7, ajax8)
						.done(function() {
									layer.close(index);
								});

			}

			// 确定
			form.on('submit(demo_true)', function(data) {
						var name = $("#modules option:selected").text();
						var modules = data.field.modules;// 井站IP
						var data_state = data.field.date_state;// 开始时间
						var data_end = data.field.data_end;// 结束时间
						var wels = formSelects.value('select', 'valStr');
						// 数据访问
						data_display(data_state, data_end, wels);
						return false;
					});

			// 表格数据加载
			function table_render(data_table) {
				table.render({
					elem : '#problem_data',
					height : height,
					data : data_table,
					page : true,
					even : true // 开启隔行背景
					,
					count : data_table.lehgth,
					curr : 0,
					limit : 10,
					limits : [10, 15, 20, 25, 30],
					layout : ['prev', 'page', 'next', 'skip', 'count', 'limit'],
					cellMinWidth : 40 // 全局定义常规单元格的最小宽度，layui 2.2.1 新增
					,
					cols : [[ // 表头
					{
								field : 'welStation',
								title : '井站名称',
								fixed : 'left'
							}, {
								field : 'countRate',
								title : '上报问题数量占比'
							}, {
								field : 'countOfDelByselfRate',
								title : '自行处理问题的数量占比'
							}, {
								field : 'countOfReDeviceRate',
								title : '关联设备的问题数量占比'
							}, {
								field : 'countOfPictureRate',
								title : '拍摄照片的问题数量占比'
							}, {
								field : 'countOfVoiceRate',
								title : '录入语音的问题数量占比'
							}, {
								field : 'numOfDesc',
								title : '上报问题时平均录入文字的字符数'
							}, {
								field : 'problemGrade',
								title : '问题上报的质量得分分数'
							}]],
					done : function(res, curr, count) {
						$('tr').css({
									'background-color' : '#1C86EE',
									'color' : 'white'
								});
						$('a').css({
									'color' : 'white'
								});
						$('span').css({
									'color' : 'white'
								});
					}
				});
			}

			window.onConfigure = function() {
				var html = '';
				html += ' <form class="layui-form layui-form-pane" action="">';
				// 获取权重、标准值
				$.post("/bigdataAnalyze/basic/getGradeStandInfo", {
							taskType : '10'
						}, function(data) {
							var task = JSON.parse(data);
							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">上报问题数量占比:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.countRateWeightValue
									+ '" id="countRateWeightValue" name="averageTime_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid">标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text"  value="'
									+ task.countOfVoiceRateWeightValue
									+ '"  id="countOfVoiceRateWeightValue" name="averageTime_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';
							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">自行处理数量占比:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.countOfDelByselfRateWeightValue
									+ '" id="countOfDelByselfRateWeightValue" name="picture_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.countOfDelByselfRateStandValue
									+ '" id="countOfDelByselfRateStandValue" name="picture_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';
							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">关联设备问题数量占比:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.countOfReDeviceRateWeightValue
									+ '" id="countOfReDeviceRateWeightValue" name="data_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.countOfReDeviceRateStandValue
									+ '" id="countOfReDeviceRateStandValue" name="data_S"  autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';

							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">拍摄照片数量占比:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.countOfPictureRateWeightValue
									+ '" id="countOfPictureRateWeightValue" name="rfid_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid">标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.countOfPictureRateStandValue
									+ '" id="countOfPictureRateStandValue" name="rfid_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';

							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">录入语音数量占比:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.countOfVoiceRateWeightValue
									+ '" id="countOfVoiceRateWeightValue" name="desc_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.countOfVoiceRateStandValue
									+ '" id="countOfVoiceRateStandValue" name="desc_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';

							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">平均录入字符数:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.numOfDescWeightValue
									+ '" id="numOfDescWeightValue" name="problem_W"  autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid">标准值</div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.numOfDescStandValue
									+ '" id="numOfDescStandValue" name="problem_S" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';
							html += '<div class="layui-form-item">';
							html += '<div class="layui-input-block" style="text-align:right;">';
							html += ' <button class="layui-btn" lay-submit="" onclick="demo1figure();return false;" lay-filter="demo1">立即提交</button>';
							html += ' </div>';
							html += '</div>';
							html += ' </form>';
							layer.open({
										title : '参数设置',
										type : 1,
										area : ['450px', '450px'], // 宽高
										content : html
									});
							return false;
						});
			}

			window.demo1figure = function() {
				// 询问框
				layer.confirm('确定提交？', {
					btn : ['确定', '取消']
						// 按钮
					}, function() {
					layer.closeAll();
					var index = layer.msg('数据加载中，请稍后。。。', {
								time : 100 * 1000
							}, {
								icon : 16,
								shade : 0.01
							});
					var grade = {
						"countOfVoiceRateStandValue" : $('#countOfVoiceRateStandValue')
								.val(),
						"countOfReDeviceRateStandValue" : $('#countOfReDeviceRateStandValue')
								.val(),
						"numOfDescWeightValue" : $('#numOfDescWeightValue')
								.val(),
						"countRateStandValue" : $('#countRateStandValue').val(),
						"countRateWeightValue" : $('#countRateWeightValue')
								.val(),
						"countOfVoiceRateWeightValue" : $('#countOfVoiceRateWeightValue')
								.val(),
						"countOfReDeviceRateWeightValue" : $('#countOfReDeviceRateWeightValue')
								.val(),
						"numOfDescStandValue" : $('#numOfDescStandValue').val(),
						"countOfPictureRateStandValue" : $('#countOfPictureRateStandValue')
								.val(),
						"countOfPictureRateWeightValue" : $('#countOfPictureRateWeightValue')
								.val(),
						"countOfDelByselfRateStandValue" : $('#countOfDelByselfRateStandValue')
								.val(),
						"countOfDelByselfRateWeightValue" : $('#countOfDelByselfRateWeightValue')
								.val()
					};
					var data_das = {
						'taskType' : "10",
						'beginDate' : $('#date').val(),
						'endDate' : $('#date1').val(),
						'welIds' : $('#modules').val(),
						'gradeStandInfo' : JSON.stringify(grade)
					};
					var ajax5 = $.post(
							'/bigdataAnalyze/problemAnalyze/getProblemQuality',
							data_das, function(data) {
								var problemData = JSON.parse(data);
								parallel(problemData.legendData,
										problemData.seriesData);
								table_render(problemData.tableDatas);
							});
					$.when(ajax5).done(function() {
								layer.close(index);
							});
				}, function() {
					return false;
				});
				return false;
			}
			/*******************************************************************
			 * 物联网大数据报表图echies_1 参数 dataBJ ,dataGZ, dataSH, schema, data, data1,
			 * backgroundColor : 背景颜色 参考页面
			 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
			 * 
			 * @returns 图形展示 liuhai
			 */

		});

var groupCategories = [];
var groupColors = [];

var indices = {
	name : 0,
	group : 1,
	id : 16
};

function normalizeData(originData) {
	var groupMap = {};
	originData.forEach(function(row) {
				var groupName = row[indices.group];
				if (!groupMap.hasOwnProperty(groupName)) {
					groupMap[groupName] = 1;
				}
			});

	originData.forEach(function(row) {
				row.forEach(function(item, index) {
							if (index !== indices.name
									&& index !== indices.group
									&& index !== indices.id) {
								// Convert null to zero, as all of them
								// under unit "g".
								row[index] = parseFloat(item) || 0;
							}
						});
			});

	for (var groupName in groupMap) {
		if (groupMap.hasOwnProperty(groupName)) {
			groupCategories.push(groupName);
		}
	}
	var hStep = Math.round(300 / (groupCategories.length - 1));
	for (var i = 0; i < groupCategories.length; i++) {
		groupColors.push(echarts.color.modifyHSL('#5A94DF', hStep * i));
	}
}