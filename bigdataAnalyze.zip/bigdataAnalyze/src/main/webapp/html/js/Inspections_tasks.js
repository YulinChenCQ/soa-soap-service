layui.use(
		['table', 'form', 'laypage', 'layedit', 'laydate', 'jquery', 'layer'],
		function() {
			// 插件加载
			var form = layui.form, table = layui.table, laypage = layui.laypage, layer = layui.layer, layedit = layui.layedit, laydate = layui.laydate, $ = layui.jquery;
			var backgroundColor = '#0E4276';
			initialization();

			// 日期
			laydate.render({
						elem : '#date',
						value : '2018-09-09'
					});
			laydate.render({
						elem : '#date1',
						value : '2018-09-11'
					});

			function initialization() {
				data_display('2018-09-09', '2018-09-11');
			}

			function data_display(beginDate, endDate) {
				$.post("/bigdataAnalyze/task/getMultipleWelTaskInfo", {
							beginDate : beginDate,
							endDate : endDate,
							taskType : '1'
						}, function(data) {
							var task = JSON.parse(data);
							// 图表展示echies_3
							var data_xAxis = task.barChart.welName;
							var data_series = task.barChart.finishTime;
							echies_3(data_xAxis, data_series);

							// 图表展示echies_1
							var schema_e1 = [];
							$.each(task.taskChart.taskNameData, function(i,
											item) {
										schema_e1.push({
													'name' : item,
													'index' : i,
													'text' : item
												});
									});
							var series_e1 = [];
							var data_legend = [];
							var lineStyle = {
								normal : {
									width : 1,
									opacity : 0.5
								}
							};
							$.each(task.taskChart.taskValueData, function(i,
											item) {
										series_e1.push({
													'name' : i,
													'type' : 'parallel',
													'lineStyle' : lineStyle,
													'data' : item
												});
										data_legend.push(i);
									});
							echies_1(series_e1, schema_e1, data_legend, ['良',
											'差', '优'], backgroundColor);
							// 表格数据加载
							table_render(task.taskRecords.data);
						});
			}

			// 表格数据加载
			function table_render(data_table) {
				table.render({
					elem : '#test',
					height : 300,
					data : data_table,
					page : true,
					even : true // 开启隔行背景
					,
					count : data_table.lehgth,
					curr : 0,
					limit : 10,
					limits : [10, 15, 20, 25, 30],
					layout : ['prev', 'page', 'next', 'skip', 'count', 'limit'],
					cellMinWidth : 40 // 全局定义常规单元格的最小宽度，layui 2.2.1 新增
					,
					cols : [[ // 表头
					{
								field : 'welStation',
								title : '井站名称',
								width : 230,
								fixed : 'left'
							}, {
								field : 'recordDay',
								title : '记录日期',
								width : 135
							}, {
								field : 'averageTime',
								title : '平均时间',
								width : 135
							}, {
								field : 'pictureCount',
								title : '照片数量',
								width : 135
							}, {
								field : 'dataCount',
								title : '数据个数',
								width : 135
							}, {
								field : 'rfidCount',
								title : '扫描标签数量',
								width : 135
							}, {
								field : 'descCount',
								title : '备注数量',
								width : 135
							}, {
								field : 'problemCount',
								title : '上报问题数量',
								width : 177
							}, {
								field : 'result',
								title : '得分',
								width : 80
							}]],
					done : function(res, curr, count) {
						$('tr').css({
									'background-color' : '#0E4276',
									'color' : 'white'
								});
						$('a').css({
									'color' : 'white'
								});
						$('span').css({
									'color' : 'white'
								});
					}
				});
			}

			// 维度编辑
			window.onDelete = function() {
				var html = '';
				html += ' <form class="layui-form" action="">';
				html += '<div class="layui-form-item">';
				html += ' <label class="layui-form-label">平均时间</label>';
				html += '<div class="layui-input-inline">';
				html += ' <input type="text" name="name" lay-verify="required" placeholder="请输入标题" autocomplete="off" class="layui-input">';
				html += '</div>';
				html += '<div class="layui-form-mid layui-word-aux" id="counts"></div>';
				html += ' </div>';
				html += '<div class="layui-form-item">';
				html += ' <label class="layui-form-label">拍摄图片</label>';
				html += '<div class="layui-input-block">';
				html += ' <input type="text" name="fileName" value="" lay-verify="required" placeholder="请输入数据接口" autocomplete="off" class="layui-input">';
				html += '</div>';
				html += '<div class="layui-form-mid layui-word-aux">';
				html += ' </div>';
				html += '<div class="layui-form-item">';
				html += ' <label class="layui-form-label">执行任务录入的数据个数</label>';
				html += '<div class="layui-input-block">';
				html += ' <input type="text" name="interFace" value="" lay-verify="required" placeholder="请输入数据接口" autocomplete="off" class="layui-input">';
				html += '</div>';
				html += '<div class="layui-form-item">';
				html += ' <label class="layui-form-label">执行任务扫描标签的数量</label>';
				html += '<div class="layui-input-block">';
				html += ' <input type="text" name="interFace" value="" lay-verify="required" placeholder="请输入数据接口" autocomplete="off" class="layui-input">';
				html += '</div>';
				html += '<div class="layui-form-item">';
				html += ' <label class="layui-form-label">执行任务时文字备注的数量</label>';
				html += '<div class="layui-input-block">';
				html += ' <input type="text" name="interFace" value="" lay-verify="required" placeholder="请输入数据接口" autocomplete="off" class="layui-input">';
				html += '</div>';
				html += '<div class="layui-form-item">';
				html += ' <label class="layui-form-label">任务执行过程中上报问题的数量</label>';
				html += '<div class="layui-input-block">';
				html += ' <input type="text" name="interFace" value="" lay-verify="required" placeholder="请输入数据接口" autocomplete="off" class="layui-input">';
				html += '</div>';
				html += '<div class="layui-form-item">';
				html += '<div class="layui-input-block">';
				html += ' <button class="layui-btn" lay-submit="" lay-filter="demo1">立即提交</button>';
				html += ' <button type="reset" class="layui-btn layui-btn-primary">重置</button>';
				html += ' </div>';
				html += '</div>';
				html += ' </form>';
				layer.open({
							title : '参数设置',
							type : 1,
							area : ['40%', '70%'], // 宽高
							content : html
						});
				/* 渲染表单 */
				form.render();
				// 监听提交事件
				form.on('submit(demo1)', function(data) {
					// 获取表单上文本框的值
					var datas = data.field;
					// 标题
					name = datas.name;
					// 背景图片接口
					fileName = datas.fileName;
					// 数据接口
					interFace = datas.interFace;
					modules = datas.modules;
					// 描述
					describes = datas.describes;

					// eventputh=datas.eventputh;
					if (bool) {
						$('#counts').html('<font color="red">请检查输入的标题!</font>');
					} else {
						// 数据查询
						$.get(interFace, null, function(data) {
									if (data.length > 0) {
										generation(fileName, datas, data);
									} else {
										alert('数据接口无数据返回！');
									}
								});
					}
					return false;
				});
			}

			/*******************************************************************
			 * 物联网大数据报表图echies_1 参数 dataBJ ,dataGZ, dataSH, schema, data, data1,
			 * backgroundColor : 背景颜色 参考页面
			 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
			 * 
			 * @returns 图形展示 liuhai
			 */

			function echies_1(series, schema, data_legend, data_parallelAxis,
					backgroundColor) {
				var dom = document.getElementById("echies_1");
				var myChart = echarts.init(dom);
				var app = {};
				option = null;
				option = {
					backgroundColor : backgroundColor,
					legend : {
						type : 'scroll',
						bottom : 10,
						data : data_legend,
						textStyle : {
							color : '#fff',
							fontSize : 14
						}
					},
					parallelAxis : [{
								dim : 0,
								name : schema[0].text,
								inverse : true,
								max : 31,
								nameLocation : 'start'
							}, {
								dim : 1,
								name : schema[1].text
							}, {
								dim : 2,
								name : schema[2].text
							}, {
								dim : 3,
								name : schema[3].text
							}, {
								dim : 4,
								name : schema[4].text
							}, {
								dim : 5,
								name : schema[5].text
							}, {
								dim : 6,
								name : schema[6].text
							}, {
								dim : 7,
								name : schema[7].text
								/*
								 * , type : 'category', data : data_parallelAxis
								 */
						}],
					visualMap : {
						show : true,
						min : 0,
						max : 100,
						inRange : {
							color : ['#d94e5d', '#eac736', '#50a3ba'].reverse()
							,
						}
					},

					parallel : {
						left : '15%',
						right : '18%',
						bottom : 100,
						parallelAxisDefault : {
							type : 'value',
							nameGap : 20,
							nameTextStyle : {
								color : '#fff',
								fontSize : 12
							},
							axisLine : {
								lineStyle : {
									color : '#aaa'
								}
							},
							axisTick : {
								lineStyle : {
									color : '#777'
								}
							},
							splitLine : {
								show : false
							},
							axisLabel : {
								textStyle : {
									color : '#fff'
								}
							}
						}
					},
					series : series
				};
				if (option && typeof option === "object") {
					myChart.setOption(option, true);
				}
			}

			/*******************************************************************
			 * 物联网大数据报表图echies_3 参数 参考页面
			 * http://echarts.baidu.com/examples/editor.html?c=dynamic-data
			 * 
			 * @returns 图形展示 liuhai
			 */
			function echies_3(data_xAxis, data_series) {
				var dom = document.getElementById("echies_3");
				var myChart = echarts.init(dom);
				var app = {};
				option = null;
				option = {
					xAxis : {
						type : 'category',
						data : data_xAxis,
						axisLabel : {
							interval : 0,// 横轴信息全部显示
							rotate : -30
							// -30度角倾斜显示
						},
						axisLine : {
							lineStyle : {
								color : '#ccc',
								width : 1
								// 这里是为了突出显示加上的
							}
						}
					},
					yAxis : {
						type : 'value',
						axisLine : {
							lineStyle : {
								color : '#ccc',
								width : 1
								// 这里是为了突出显示加上的
							}
						}
					},
					series : [{
								data : data_series,
								type : 'bar'
							}],
					dataZoom : [{
								type : 'slider',
								show : true,
								start : 94,
								end : 100,
								handleSize : 8
							}, {
								type : 'inside',
								start : 94,
								end : 100
							}, {
								type : 'slider',
								show : true,
								yAxisIndex : 0,
								filterMode : 'empty',
								width : 12,
								height : '70%',
								handleSize : 8,
								showDataShadow : false,
								left : '93%'
							}]
				};
				if (option && typeof option === "object") {
					myChart.setOption(option, true);
				}
			}

		});