
/**
 * 饼图
 * 
 * @param {}
 *            id
 * @param {}
 *            legend_data
 * @param {}
 *            series_data
 */
function echice_vertical(id, legend_data, series_data) {
	var dom = document.getElementById(id);
	var myChart = echarts.init(dom);
	var app = {};
	var option = {
		backgroundColor : '#1C86EE',
		tooltip : {
			trigger : 'item'

			// formatter: "问题数量 <br/>{b} : {c} ({d}%)"
		},
		legend : {
			bottom : 10,
			left : 'center',
			data : legend_data
		},
		series : [{
					name : '问题数量',
					type : 'pie',
					radius : '45%',
					center : ['50%', '50%'],
					selectedMode : 'single',
					data : series_data,
					itemStyle : {
						emphasis : {
							shadowBlur : 10,
							shadowOffsetX : 0,
							shadowColor : 'rgba(0, 0, 0, 0.5)'
						}
					}
				}]
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 平行图-问题上报质量分析
 * 
 * @param {}
 *            legend_data
 * @param {}
 *            series_data
 */
function parallel(legend_data, series_data) {

	var dom = document.getElementById('problem_quality');
	var myChart = echarts.init(dom);
	var schema = [{
				name : '上报问题数量占比',
				index : 0,
				text : '上报问题数量占比'
			}, {
				name : '上报问题自行处理的数量占比',
				index : 1,
				text : '上报问题自行处理的数量占比'
			}, {
				name : '上报问题时关联了设备的问题数量占比',
				index : 2,
				text : '上报问题时关联了设备的问题数量占比'
			}, {
				name : '上报问题拍摄照片的数量占比',
				index : 3,
				text : '上报问题拍摄照片的数量占比'
			}, {
				name : '上报问题时录入语音的数量占比',
				index : 4,
				text : '上报问题时录入语音的数量占比'
			}, {
				name : '上报问题时每个问题平均录入文字的字符数',
				index : 5,
				text : '上报问题时每个问题平均录入文字的字符数'
			}, {
				name : '得分',
				index : 6,
				text : '得分'
			}];

	var lineStyle = {
		normal : {
			width : 1,
			opacity : 0.5
		}
	};

	var option = {
		backgroundColor : '#1C86EE',
		legend : {
			bottom : 10,
			left : 'center',
			data : legend_data,
			itemGap : 20,
			/*
			 * textStyle : { color : '#fff', fontSize : 14 },
			 */
			type : 'scroll'// 设置可滚动
		},
		tooltip : {
			padding : 10,
			backgroundColor : '#222',
			borderColor : '#777',
			borderWidth : 1,
			formatter : function(obj) {
				var value = obj[0].value;
				return '<div style="border-bottom: 1px solid rgba(255,255,255,.3); font-size: 18px;padding-bottom: 7px;margin-bottom: 7px">'
						+ obj[0].seriesName
						+ ' '
						+ value[0]
						+ '日期：'
						+ value[7]
						+ '</div>'
						+ schema[1].text
						+ '：'
						+ value[1]
						+ '<br>'
						+ schema[2].text
						+ '：'
						+ value[2]
						+ '<br>'
						+ schema[3].text
						+ '：'
						+ value[3]
						+ '<br>'
						+ schema[4].text
						+ '：'
						+ value[4]
						+ '<br>'
						+ schema[5].text
						+ '：'
						+ value[5]
						+ '<br>'
						+ schema[6].text + '：' + value[6] + '<br>';
			}
		},
		// dataZoom: {
		// show: true,
		// orient: 'vertical',
		// parallelAxisIndex: [0]
		// },
		parallelAxis : [{
			dim : 0,
			name : schema[0].text,
			// inverse : true,
			max : 100
				/*
				 * , nameLocation : 'start'
				 */
			}, {
			dim : 1,
			max : 100,
			name : schema[1].text
		}, {
			dim : 2,
			max : 100,
			name : schema[2].text
		}, {
			dim : 3,
			max : 100,
			name : schema[3].text
		}, {
			dim : 4,
			max : 100,
			name : schema[4].text
		}, {
			dim : 5,
			max : 100,
			name : schema[5].text
		}, {
			dim : 6,
			max : 100,
			name : schema[6].text
		}/*
			 * , { dim : 7, name : schema[7].text type : 'category', data :
			 * ['优', '良', '轻度污染', '中度污染', '重度污染', '严重污染'] }
			 */],
		/*
		 * visualMap : { show : true, min : 0, max : 150, dimension : 2, inRange : {
		 * color : ['#d94e5d', '#eac736', '#50a3ba'].reverse() , // colorAlpha:
		 * [0, 1] } },
		 */
		parallel : {
			/*
			 * left : '5%', right : '18%',
			 */
			bottom : 100,
			parallelAxisDefault : {
				type : 'value',
				name : '问题上报质量大数据分析',
				nameLocation : 'end',
				nameGap : 20,
				nameRotate : 10,
				nameTextStyle : {
					color : '#fff',
					fontSize : 12
				},
				axisLine : {
					lineStyle : {
						color : '#aaa'
					}
				},
				axisTick : {
					lineStyle : {
						color : '#777'
					}
				},
				splitLine : {
					show : false
				},
				axisLabel : {
					textStyle : {
						color : '#fff'
					}
				}
			}
		},
		series : series_data
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

function dealRate(name_data, valueData) {
	var dom = document.getElementById('deal_rate');
	var myChart = echarts.init(dom);
	var option = {
		color : '#9CC5B0',
		title : {
			text : '',
			subtext : ''
		},
		tooltip : {
			trigger : 'axis',
			axisPointer : {
				type : 'shadow'
			}
		},
		legend : {
			data : ['问题处理节点花费时间'],
			show : false
		},

		grid : {
			left : '1%',
			right : '1%',
			bottom : '3%',
			containLabel : true
		},

		xAxis : {
			type : 'value',
			boundaryGap : [0, 0.01]
		},
		yAxis : {
			type : 'category',
			nameRotate : 10,
			data : name_data
		},
		series : [{
					name : '问题处理节点花费时间',
					type : 'bar',
					data : valueData
				}]
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 平行图-不同问题每个环节的处理效率大数据分析
 */

function parallel2(series_data) {
	var dom = document.getElementById('every_node_deal_rate');
	var myChart = echarts.init(dom);

	var option = null;
	var indices = {
		name : 0,
		group : 1,
		id : 16
	};
	var schema = [{
				name : '调度室',
				index : 0
			}, {
				name : 'QHSE办公室',
				index : 1
			}, {
				name : '部门负责人',
				index : 2
			}, {
				name : '专业技术岗（分级任务-调用子流程）',
				index : 3
			}, {
				name : '任务接收人（执行现场整改）',
				index : 4
			}, {
				name : '专业技术岗（验证问题是否已按要求整改）',
				index : 5
			}, {
				name : '问题上报人（闭环销项）',
				index : 6
			}];

	var groupCategories = [];
	var groupColors = [];

/*	normalizeData(data);
*/
	option = getOption(series_data);

	function normalizeData(originData) {
		var groupMap = {};
		originData.forEach(function(row) {
					var groupName = row[indices.group];
					if (!groupMap.hasOwnProperty(groupName)) {
						groupMap[groupName] = 1;
					}
				});

		originData.forEach(function(row) {
					row.forEach(function(item, index) {
								if (index !== indices.name
										&& index !== indices.group
										&& index !== indices.id) {
									// Convert null to zero, as all of them
									// under unit "g".
									row[index] = parseFloat(item) || 0;
								}
							});
				});

		for (var groupName in groupMap) {
			if (groupMap.hasOwnProperty(groupName)) {
				groupCategories.push(groupName);
			}
		}
		var hStep = Math.round(300 / (groupCategories.length - 1));
		for (var i = 0; i < groupCategories.length; i++) {
			groupColors.push(echarts.color.modifyHSL('#5A94DF', hStep * i));
		}
	}

	function getOption(series_data) {

		var lineStyle = {
			normal : {
				width : 0.5,
				opacity : 0.05
			}
		};

		return {
			tooltip : {
				padding : 10,
				backgroundColor : '#222',
				borderColor : '#777',
				borderWidth : 1,
				formatter : function(obj) {
					var value = obj[0].value;
					return '<div style="border-bottom: 1px solid rgba(255,255,255,.3); font-size: 18px;padding-bottom: 7px;margin-bottom: 7px">'
							+ schema[1].name
							+ '：'
							+ value[1]
							+ '<br>'
							+ schema[2].name
							+ '：'
							+ value[2]
							+ '<br>'
							+ schema[3].name
							+ '：'
							+ value[3]
							+ '<br>'
							+ schema[4].name
							+ '：'
							+ value[4]
							+ '<br>'
							+ schema[5].name
							+ '：'
							+ value[5]
							+ '<br>'
							+ schema[6].name + '：' + value[6] + '<br>';
				}
			},
			/*
			 * visualMap : { show : true, type : 'piecewise', categories :
			 * groupCategories, dimension : indices.group, inRange : { color :
			 * groupColors // ['#d94e5d','#eac736','#50a3ba'] }, outOfRange : {
			 * color : ['#ccc'] // ['#d94e5d','#eac736','#50a3ba'] }, top : 20,
			 * textStyle : { color : '#fff' }, realtime : false },
			 */
			parallelAxis : [{
						dim : 0,
						name : schema[0].name,
						scale : true,
						nameTextStyle : {
							fontSize : 10
						},
						nameLocation : 'end'
					}, {
						dim : 1,
						nameTextStyle : {
							fontSize : 10
						},
						name : schema[1].name,
						nameLocation : 'end'
					}, {
						dim : 2,
						name : schema[2].name,
						nameTextStyle : {
							fontSize : 10
						},
						nameLocation : 'end'
					}, {
						dim : 3,
						name : schema[3].name,
						nameTextStyle : {
							fontSize : 10
						},
						nameLocation : 'end'
					}, {
						dim : 4,
						name : schema[4].name,
						nameTextStyle : {
							fontSize : 10
						},
						nameLocation : 'end'
					}, {
						dim : 5,
						name : schema[5].name,
						nameTextStyle : {
							fontSize : 10
						},
						nameLocation : 'end'
					}, {
						dim : 6,
						name : schema[6].name,
						nameTextStyle : {
							fontSize : 10
						},
						nameLocation : 'end'
					}],
			parallel : {
				/*
				 * left : 280,
				 * 
				 * top : 20,
				 */
				// top: 150,
				// height: 300,
				/* width : 400, */
				right : 200,
				layout : 'vertical',
				parallelAxisDefault : {
					type : 'value',
					name : 'nutrients',
					nameLocation : 'end',
					nameGap : 20,
					nameRotate : 10,
					nameTextStyle : {
						color : '#fff',
						fontSize : 14
					},
					axisLine : {
						lineStyle : {
							color : '#aaa'
						}
					},
					axisTick : {
						lineStyle : {
							color : '#777'
						}
					},
					splitLine : {
						show : false
					},
					axisLabel : {
						textStyle : {
							color : '#fff'
						}
					},
					realtime : false
				}
			},
			animation : false,
			series : series_data
		};
	}
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 3D柱状图-相同岗位人员处理相同环节的效率大数据分析
 */
function echies_category(seriesData, yAxis3DData, xAxis3DData) {

	var dom = document.getElementById('same_node_deal_rate');
	var myChart = echarts.init(dom);
	var option = {
		visualMap : {
			// max : 20,
			inRange : {
				color : ['#313695', '#4575b4', '#74add1', '#abd9e9', '#e0f3f8',
						'#ffffbf', '#fee090', '#fdae61', '#f46d43', '#d73027',
						'#a50026']
			}
		},
		xAxis3D : {
			type : 'category',
			axisLabel : {
				show : true,
				textStyle : {
					color : '#fff'
				}
			},
			data : xAxis3DData
		},
		yAxis3D : {
			type : 'category',
			axisLabel : {
				show : true,
				textStyle : {
					color : '#fff'
				}
			},
			data : yAxis3DData
		},
		zAxis3D : {
			axisLabel : {
				show : true,
				textStyle : {
					color : '#fff'
				}
			},
			type : 'value'
		},
		grid3D : {
			boxWidth : 200,
			boxDepth : 80,
			viewControl : {
				projection : 'orthographic'
			},
			light : {
				main : {
					intensity : 1.2,
					shadow : true
				},
				ambient : {
					intensity : 0.3
				}
			}
		},
		tooltip : {
			/* trigger: 'axis' */
			show : true, // 默认显示
			showContent : true, // 是否显示提示框浮层
			formatter : function(params, ticket, callback) {
				console.log(xAxis3DData[params.data[0]]);
				console.log(yAxis3DData[params.data[1]]);
				var res = xAxis3DData[params.data[0]] + '完成</br>'
						+ yAxis3DData[params.data[1]] + '</br>节点的平均时间为：'
						+ '</br>' + params.data[2] + 'h'
				return res;
			}
		},
		series : [{
					type : 'bar3D',
					data : seriesData,
					shading : 'lambert',

					label : {
						textStyle : {
							fontSize : 16,
							borderWidth : 1
						}
					},
					emphasis : {
						label : {
							textStyle : {
								fontSize : 20,
								color : '#900'
							}
						},
						itemStyle : {
							color : '#900'
						}
					}
				}]
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}
