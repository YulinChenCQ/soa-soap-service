/**
 * 设备完好率统计图
 * 
 * @param {}
 *            xData 横坐标数据
 * @param {}
 *            numData
 * @param {}
 *            exceptionNumData
 * @param {}
 *            rateData
 */
function bar(xData, numData, exceptionNumData, rateData) {
	var dom = document.getElementById('equ_total_situation_an');
	var myChart = echarts.init(dom);

	var option = {
		backgroundColor : '#1C86EE',
		color : ['#2f4554', '#61a0a8', '#d48265', '#91c7ae', '#749f83',
				'#ca8622', '#bda29a', '#6e7074', '#546570', '#c4ccd3'],
		tooltip : {
			trigger : 'axis',
			axisPointer : {
				type : 'cross',
				crossStyle : {
					color : '#999'
				}
			}
		},
		toolbox : {
			feature : {
				dataView : {
					show : true,
					readOnly : false
				},
				magicType : {
					show : true,
					type : ['line', 'bar']
				},
				restore : {
					show : true
				},
				saveAsImage : {
					show : true
				}
			}
		},
		legend : {
			data : ['设备总数', '异常设备数', '完好率']
		},
		xAxis : [{
					type : 'category',
					data : xData,
					axisPointer : {
						type : 'shadow'
					}
				}],
		yAxis : [{
					type : 'value',
					name : '设备数',
					/*
					 * min : 0, max : 250, interval : 50,
					 */
					axisLabel : {
						formatter : '{value} '
					}
				}, {
					type : 'value',
					name : '完好率',
					min : 0,
					max : 100,
					interval : 20,
					axisLabel : {
						formatter : '{value} %'
					}
				}],
		series : [{
					name : '设备总数',
					type : 'bar',
					data : numData
				}, {
					name : '异常设备数',
					type : 'bar',
					data : exceptionNumData
				}, {
					name : '完好率',
					type : 'line',
					yAxisIndex : 1,
					data : rateData
				}]
	};
	if (option && typeof option === "object") {

		myChart.setOption(option, true);
	}

}

function pie_rose(legendData, data, id) {
	var dom = document.getElementById(id);
	var myChart = echarts.init(dom);
	var option = {
		backgroundColor : '#1C86EE',
		color : ['#2f4554', '#61a0a8', '#d48265', '#91c7ae', '#749f83',
				'#ca8622', '#bda29a', '#6e7074', '#546570', '#c4ccd3'],
		title : {
			// text : '南丁格尔玫瑰图',
			// subtext : '纯属虚构',
			x : 'center'
		},
		tooltip : {
			trigger : 'item',
			formatter : "{a} <br/>{b} : {c} ({d}%)"
		},
		legend : {
			type : 'scroll',
			x : 'center',
			y : 'bottom',
			data : legendData
		},
		calculable : true,
		series : [{
					name : '设备数量',
					type : 'pie',
					radius : [40, '75%'],
					center : ['50%', '50%'],
					roseType : 'radius',
					label : {
						normal : {
							show : true
						},
						emphasis : {
							show : true
						}
					},
					lableLine : {
						normal : {
							show : true
						},
						emphasis : {
							show : true
						}
					},
					data : data
				}]
	};

	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 雷达图（单井站）
 */
function radar(data, legend_data, indicator, id) {

	var dom = document.getElementById(id);
	var myChart = echarts.init(dom);
	var option = {

		backgroundColor : '#1C86EE',
		title : {
			/*
			 * text : '浏览器占比变化', subtext : '纯属虚构',
			 */
			top : 10,
			left : 10
		},
		tooltip : {
			trigger : 'item',
			backgroundColor : 'rgba(0,0,250,0.2)',
			textStyle : {
				align : 'left'
			}
		},
		legend : {
			type : 'scroll',
			bottom : 10,
			data : legend_data
		},

		/*
		 * visualMap : { top : 'middle', right : 10, color : ['red', 'yellow'],
		 * calculable : true },
		 */
		radar : {
			indicator : indicator
		},
		series : [{
					name : '设备分析',
					type : 'radar',
					symbol : 'none',
					lineStyle : {
						width : 1
					},
					emphasis : {
						areaStyle : {
							color : 'rgba(0,250,0,0.3)'
						}
					},
					data : data
				}]
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}

}

/**
 * 雷达图（多井站）
 */
function radar_wels(series_data, legend_data, id, ifVerify) {

	var indicator = [{
				text : "操作记录"
			}, {
				text : "（异常）隐患记录"
			}, {
				text : "维护保养记录"
			}, {
				text : "检维修记录"
			},{
				text : "校验记录"
			}, {
				text : "故障率",
				max:100
			}];
	if (ifVerify == '2') {
		var indicator = [{
				text : "操作记录"
			}, {
				text : "（异常）隐患记录"
			}, {
				text : "维护保养记录"
			}, {
				text : "检维修记录"
			}, {
				text : "故障率",
				max:100
			}];
	}

	var dom = document.getElementById(id);
	var myChart = echarts.init(dom);
	var option = {

		backgroundColor : '#1C86EE',
		title : {
			/*
			 * text : '浏览器占比变化', subtext : '纯属虚构',
			 */
			top : 10,
			left : 10
		},
		tooltip : {
			trigger : 'item',
			backgroundColor : 'rgba(0,0,250,0.2)',
			textStyle : {
				align : 'left'
			}
		},
		legend : {
			type : 'scroll',
			bottom : 10,
			data : legend_data
		},

		/*
		 * visualMap : { top : 'middle', right : 10, color : ['red', 'yellow'],
		 * calculable : true },
		 */
		radar : {
			indicator : indicator
		},
		series : series_data
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}

}

