layui.use(
		['table', 'form', 'laypage', 'layedit', 'laydate', 'jquery', 'layer'],
		function() {
			// 插件加载
			var form = layui.form, table = layui.table, laypage = layui.laypage, layer = layui.layer, layedit = layui.layedit, laydate = layui.laydate, $ = layui.jquery;
			var backgroundColor = '#0E4276';
			initialization();
			var taskType;
			// 日期控件
			laydate.render({
						elem : '#date',
						value : data_date
					});
			laydate.render({
						elem : '#date1',
						value : data_date1
					});
			// 初始化设置高
			$("#echies_1").height(height);
			$("#echies_3").height(height);
			function initialization() {
				taskType = '6';
				data_display(data_date, data_date1);
			}

			function data_display(beginDate, endDate) {
				var index = layer.msg('数据加载中，请稍后。。。', {
							time : 100 * 1000
						}, {
							icon : 16,
							shade : 0.01
						});
				$.post("/bigdataAnalyze/task/getMultipleWelTaskInfo", {
							beginDate : beginDate,
							endDate : endDate,
							taskType : taskType
						}, function(data) {
							layer.close(index);
							var task = JSON.parse(data);
							// 图表展示echies_3
							var data_xAxis = task.barChart.welName;
							var data_series = task.barChart.finishTime;
							echies_3(data_xAxis, data_series);

							// 图表展示echies_1
							var schema_e1 = [];
							$.each(task.taskChart.taskNameData, function(i,
											item) {
										schema_e1.push({
													'name' : item,
													'index' : i,
													'text' : item
												});
									});
							var series_e1 = [];
							var data_legend = [];
							var lineStyle = {
								normal : {
									width : 1,
									opacity : 0.5
								}
							};
							$.each(task.taskChart.taskValueData, function(i,
											item) {
										series_e1.push({
													'name' : i,
													'type' : 'parallel',
													'lineStyle' : lineStyle,
													'data' : item
												});
										data_legend.push(i);
									});
							echies_1(series_e1, schema_e1, data_legend,
									data_parallelAxis, backgroundColor);
							// 表格数据加载
							table_render(task.taskRecords.data);
						});
			}
			// 确定
			form.on('submit(demo_true)', function(data) {
						var data_state = data.field.date;// 开始时间
						var data_end = data.field.date1;// 结束时间
						// 数据访问
						data_display(data_state, data_end);
						return false;
					});
			// 表格数据加载
			function table_render(data_table) {
				table.render({
					elem : '#test',
					height : height,
					data : data_table,
					page : true,
					even : true // 开启隔行背景
					,
					count : data_table.lehgth,
					curr : 0,
					limit : 10,
					limits : [10, 15, 20, 25, 30],
					layout : ['prev', 'page', 'next', 'skip', 'count', 'limit'],
					cellMinWidth : 40 // 全局定义常规单元格的最小宽度，layui 2.2.1 新增
					,
					cols : [[ // 表头
					{
								field : 'welStation',
								title : '井站名称',
								fixed : 'left'
							}, {
								field : 'recordDay',
								title : '记录日期'
							}, {
								field : 'averageTime',
								title : '平均时间'
							}, {
								field : 'pictureCount',
								title : '照片数量'
							}, {
								field : 'dataCount',
								title : '数据个数'
							}, {
								field : 'descCount',
								title : '备注数量'
							}, {
								field : 'problemCount',
								title : '上报问题数量'
							}, {
								field : 'result',
								sort:true,
								title : '得分'
							}]],
					done : function(res, curr, count) {
						$('tr').css({
									'background-color' : '#0E4276',
									'color' : 'white'
								});
						$('a').css({
									'color' : 'white'
								});
						$('span').css({
									'color' : 'white'
								});
					}
				});
			}

			// 维度编辑——弹出层
			window.onConfigure = function() {
				var html = '';
				html += ' <form class="layui-form layui-form-pane" action="">';
				// 获取权重、标准值
				$.post("/bigdataAnalyze/basic/getGradeStandInfo", {
							taskType : taskType
						}, function(data) {
							var task = JSON.parse(data);
							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">平均时间:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.averageTimeWeightValue
									+ '" id="averageTime_W" placeholder="权重" autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值 </div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text"  value="'
									+ task.averageTimeStandValue
									+ '" id="averageTime_S" placeholder="标准值" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';
							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">图片数量:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.pictureCountWeightValue
									+ '" id="picture_W" placeholder="权重" autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值 </div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.pictureCountStandValue
									+ '" id="picture_S" placeholder="标准值" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';
							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">录入个数:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.dataCountWeightValue
									+ '" id="data_W" placeholder="权重" autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值 </div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.dataCountStandValue
									+ '" id="data_S" placeholder="标准值" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';

							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">备注字数量:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.descCountWeightValue
									+ '" id="desc_W" placeholder="权重" autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值 </div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.descCountStandValue
									+ '" id="desc_S" placeholder="标准值" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';

							html += '<div class="layui-form-item">';
							html += '<div class="layui-inline">';
							html += '<label class="layui-form-label">问题数量:权重</label>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += '<input type="text" value="'
									+ task.problemCountWeightValue
									+ '" id="problem_W" placeholder="权重" autocomplete="off" class="layui-input">';
							html += '</div>';
							html += '<div class="layui-form-mid"> 标准值 </div>';
							html += '<div class="layui-input-inline" style="width: 100px;">';
							html += ' <input type="text" value="'
									+ task.problemCountStandValue
									+ '" id="problem_S" placeholder="标准值" autocomplete="off" class="layui-input">';
							html += ' </div>';
							html += '</div>';
							html += '</div>';
							html += '<div class="layui-form-item">';
							html += '<div class="layui-input-block" style="text-align:right;">';
							html += ' <button class="layui-btn" lay-submit="" onclick="demo1figure();return false;" lay-filter="demo1">立即提交</button>';
							html += ' </div>';
							html += '</div>';
							html += ' </form>';
							layer.open({
										title : '参数设置',
										type : 1,
										area : ['450px', '400px'], // 宽高
										content : html
									});
						});
				return false;
			}

			// 维度提交按鈕
			window.demo1figure = function() {
				// 询问框
				layer.confirm('确定提交？', {
					btn : ['确定', '取消']
						// 按钮
					}, function() {
					layer.closeAll();
					var index = layer.msg('数据加载中，请稍后。。。', {
								time : 100 * 1000
							}, {
								icon : 16,
								shade : 0.01
							});
					var grade = {
						"dataCountStandValue" : $('#data_S').val(),
						"dataCountWeightValue" : $('#data_W').val(),
						"averageTimeWeightValue" : $('#averageTime_W').val(),
						"averageTimeStandValue" : $('#averageTime_S').val(),
						"rfidCountWeightValue" : "",
						"rfidCountStandValue" : "",
						"keyStepStandValue" : "",
						"keyStepWeightValue" : "",
						"problemCountWeightValue" : $('#problem_W').val(),
						"problemCountStandValue" : $('#problem_S').val(),
						"stepCountStandValue" : "",
						"stepCountWeightValue" : "",
						"pictureCountWeightValue" : $('#picture_W').val(),
						"pictureCountStandValue" : $('#picture_S').val(),
						"descCountWeightValue" : $('#desc_W').val(),
						"descCountStandValue" : $('#desc_S').val()
					};

					var weight_value = check_out_sum(grade);
					if (weight_value != 1) {
						layer.open({
									title : '错误提示',
									content : '您填写的权重信息和不为1，请重新填写配置'
								});
						return;

					}
					var data_da = {
						beginDate : $('#date').val(),
						endDate : $('#date1').val(),
						welId : "",
						taskType : taskType,
						gradeStandInfo : JSON.stringify(grade)
					};
					$.post("/bigdataAnalyze/basic/updateGradeStandInfo",
							data_da, function(data) {
								var task = JSON.parse(data);
								// 图表展示echies_1
								var schema_e1 = [];
								$.each(task.taskChart.taskNameData, function(i,
												item) {
											schema_e1.push({
														'name' : item,
														'index' : i,
														'text' : item
													});
										});
								var series_e1 = [];
								var data_legend = [];
								var lineStyle = {
									normal : {
										width : 1,
										opacity : 0.5
									}
								};
								$.each(task.taskChart.taskValueData, function(
												i, item) {
											series_e1.push({
														'name' : i,
														'type' : 'parallel',
														'lineStyle' : lineStyle,
														'data' : item
													});
											data_legend.push(i);
										});
								echies_1(series_e1, schema_e1, data_legend,
										data_parallelAxis, backgroundColor);
								// 表格数据加载
								table_render(task.taskRecords.data);
								layer.closeAll();
								return false;
							});
				}, function() {
					return false;
				});
				return false;
			}

			/*******************************************************************
			 * 物联网大数据报表图echies_1 参数 dataBJ ,dataGZ, dataSH, schema, data, data1,
			 * backgroundColor : 背景颜色 参考页面
			 * http://echarts.baidu.com/examples/editor.html?c=parallel-aqi
			 * 
			 * @returns 图形展示 liuhai
			 */

			function echies_1(series, schema, data_legend, data_parallelAxis,
					backgroundColor) {
				var dom = document.getElementById("echies_1");
				var myChart = echarts.init(dom);
				var app = {};
				option = null;
				option = {
					backgroundColor : backgroundColor,
					legend : {
						type : 'scroll',
						bottom : 10,
						data : data_legend,
						textStyle : {
							color : '#fff',
							fontSize : 14
						}
					},
					parallelAxis : [{
								dim : 0,
								name : schema[0].text,
								inverse : true,
								max : 31,
								nameLocation : 'start'
							}, {
								dim : 1,
								name : schema[1].text
							}, {
								dim : 2,
								name : schema[2].text
							}, {
								dim : 3,
								name : schema[3].text
							}, {
								dim : 4,
								name : schema[4].text
							}, {
								dim : 5,
								name : schema[5].text
							}, {
								dim : 6,
								name : schema[6].text
								/*
								 * , type : 'category', data : data_parallelAxis
								 */
						}],
					/*visualMap : {
						show : false,
						min : 0,
						max : 12,
						dimension : 1,
						inRange : {
							color : ['#d94e5d', '#eac736', '#50a3ba'].reverse()
							,
						}
					},*/
					parallel : {
						left : '5%',
						right : '8%',
						height : '60%',
						parallelAxisDefault : {
							type : 'value',
							nameGap : 20,
							nameRotate : 15,
							nameTextStyle : {
								color : '#fff',
								fontSize : 12
							},
							axisLine : {
								lineStyle : {
									color : '#fff'
								}
							},
							axisTick : {
								lineStyle : {
									color : '#fff'
								}
							},
							splitLine : {
								show : false
							},
							axisLabel : {
								textStyle : {
									color : '#fff'
								}
							}
						}
					},
					series : series
				};
				if (option && typeof option === "object") {
					myChart.setOption(option, true);
				}
			}

			/*******************************************************************
			 * 物联网大数据报表图echies_3 参数 参考页面
			 * http://echarts.baidu.com/examples/editor.html?c=dynamic-data
			 * 
			 * @returns 图形展示 liuhai
			 */
			function echies_3(data_xAxis, data_series) {
				var dom = document.getElementById("echies_3");
				var myChart = echarts.init(dom);
				var app = {};
				option = null;
				option = {
					xAxis : {
						type : 'category',
						data : data_xAxis,
						axisLabel : {
							interval : 0,// 横轴信息全部显示
							rotate : -30
							,// -30度角倾斜显示
						},
						axisLine : {
							lineStyle : {
								color : '#ccc',
								width : 1
								,// 这里是为了突出显示加上的
							}
						}
					},
					yAxis : {
						type : 'value',
						axisLine : {
							lineStyle : {
								color : '#ccc',
								width : 1
								,// 这里是为了突出显示加上的
							}
						}
					},
					tooltip : {
						trigger : 'axis',
						axisPointer : {
							type : 'cross',
							label : {
								backgroundColor : '#283b56'
							}
						}
					},
					series : [{
						data : data_series,
						type : 'bar',
						label : {
							normal : {
								show : true,
								position : 'top'
							}
						},
						itemStyle : {
							normal : {
								// 随机显示
								color : function(d) {
									return "#"
											+ Math.floor(Math.random()
													* (256 * 256 * 256 - 1))
													.toString(16);
								}
							}
							,
						}
						,
					}],
					dataZoom : [{
								type : 'slider',
								show : true,
								start : 0,
								end : 100,
								handleSize : 8
							}, {
								type : 'inside',
								start : 0,
								end : 100
							}, {
								type : 'slider',
								show : true,
								yAxisIndex : 0,
								filterMode : 'empty',
								width : 12,
								height : '70%',
								handleSize : 8,
								showDataShadow : false,
								left : '93%'
							}]
				};
				if (option && typeof option === "object") {
					myChart.setOption(option, true);
				}
			}

		});