
/**
 * 多个井站每种任务的数量统计对比
 * 
 * @param {}
 *            legend_data
 * @param {}
 *            xAxis_data
 * @param {}
 *            series_data
 */
function echies_statistics(legend_data, xAxis_data, series_data) {
	var dom = document.getElementById('statistics');
	var myChart = echarts.init(dom);
	var app = {};
	option = null;
	option = {
		backgroundColor : '#1C86EE',
		tooltip : {
			trigger : 'axis',
			axisPointer : { // 坐标轴指示器，坐标轴触发有效
				type : 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		legend : {
			data : legend_data
		},
		dataZoom : [{
					type : 'inside',
					start : 0,
					end : 10
				}, {
					id : 'dataZoomY',
					type : 'slider',
					xAxisIndex : [0],
					filterMode : 'empty'
				}],
		xAxis : {
			type : 'category',
			data : xAxis_data,
			axisLabel : {
				interval : 0,// 横轴信息全部显示
				rotate : -30
				// -30度角倾斜显示
			},
			axisLine : {
				lineStyle : {
					color : '#ccc',
					width : 1
					// 这里是为了突出显示加上的
				}
			}
		},
		yAxis : {
			type : 'value',
			axisLine : {
				lineStyle : {
					color : '#ccc',
					width : 1
					// 这里是为了突出显示加上的
				}
			}
		},
		series : series_data
	};

	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 多个井站间的任务完成率大数据分析
 * 
 * @param {}
 *            legend_data
 * @param {}
 *            series_data
 */
function echies_rates(legend_data, series_data) {
	var dom = document.getElementById('completion_rates');
	var myChart = echarts.init(dom);
	var app = {};
	var option = {
		backgroundColor : '#1C86EE',
		title : {
			text : ''
		},
		tooltip : {
			
		},
		legend : {
			data : legend_data,
			x : 'center',
			y : 'bottom',
			type : 'scroll'
		},
		radar : {
			// shape: 'circle',
			name : {
				textStyle : {
					color : '#fff',
					backgroundColor : '#999',
					borderRadius : 3,
					padding : [3, 5]
				}
			},
			indicator : [{
						name : '巡回检查',
						max : 100
					}, {
						name : '维护保养',
						max : 100
					}, {
						name : '动态分析',
						max : 100
					}, {
						name : '属地监督',
						max : 100
					}, {
						name : '临时任务',
						max : 100
					}],
			radius : 120
		},
		series : [{
					name : '任务完成率',
					type : 'radar',
					// areaStyle: {normal: {}},
					data : series_data
				}]
	};
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 五种任务的得分大数据对比分析
 */
function echies_Score(legend_data, series_data) {
	var dom = document.getElementById('Score');
	var myChart = echarts.init(dom);
	var lineStyle = {
		normal : {
			width : 1,
			opacity : 0.5
		}
	};
	var option = {
		backgroundColor : '#1C86EE',
		title : {
			text : '',
			left : 'center',
			textStyle : {
				color : '#eee'
			}
		},
		tooltip : {
			show : true,
			trigger : 'item'
		},
		legend : {
			data : legend_data,
			x : 'center',
			y : 'bottom',
			type : 'scroll'
		},
		radar : {
			indicator : [{
						name : '巡回检查',
						max : 100
					}, {
						name : '维护保养',
						max : 100
					}, {
						name : '动态分析',
						max : 100
					}, {
						name : '属地监督',
						max : 100
					}, {
						name : '临时任务',
						max : 100
					}],
			radius : 120,
			shape : 'circle',
			splitNumber : 5,
			name : {
				textStyle : {
					color : 'rgb(238, 197, 102)'
				}
			},
			splitLine : {
				lineStyle : {
					color : ['rgba(238, 197, 102, 0.1)',
							'rgba(238, 197, 102, 0.2)',
							'rgba(238, 197, 102, 0.4)',
							'rgba(238, 197, 102, 0.6)',
							'rgba(238, 197, 102, 0.8)',
							'rgba(238, 197, 102, 1)'].reverse()
				}
			},
			splitArea : {
				show : false
			},
			axisLine : {
				lineStyle : {	
					color : 'rgba(238, 197, 102, 0.5)'
				}
			}
		},
		series : series_data
	};;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 多井站月度综合任务大数据分析
 * 
 * @param {}
 *            legend_data
 * @param {}
 *            indicator_data
 * @param {}
 *            series_data
 */
function echies_radar(legend_data, series_data) {
	var dom = document.getElementById('completion_rate');
	var myChart = echarts.init(dom);
	var option = {
		backgroundColor : '#1C86EE',
		tooltip : {},
		legend : {
			data : legend_data,
			x : 'center',
			y : 'bottom',
			type : 'scroll'
		},
		radar : {
			// shape: 'circle',
			name : {
				textStyle : {
					color : '#fff',
					backgroundColor : '#999',
					borderRadius : 3,
					padding : [3, 5]
				}
			},
			indicator : (function() {
				var res = [];
				for (var i = 1; i <= 12; i++) {
					res.push({
								text : i + '月',
								max : 100
							});
				}
				return res;
			})(),
			radius : 120
		},
		series : series_data
	};;
	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}

/**
 * 不同井站综合任务总得分大数据对比分析
 */
function echies_nutrients(xData, series_data) {
	var dom = document.getElementById('average_score');
	var myChart = echarts.init(dom);

	var option = {
		backgroundColor : '#1C86EE',
		color : ['#91C7AE'],
		tooltip : {
			trigger : 'axis',
			axisPointer : { // 坐标轴指示器，坐标轴触发有效
				type : 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		dataZoom : [{
					type : 'inside',
					start : 0,
					end : 20
				}, {
					id : 'dataZoomY',
					type : 'slider',
					xAxisIndex : [0],
					filterMode : 'empty'
				}],
		grid : {
			left : '3%',
			right : '4%',
			bottom : '3%',
			containLabel : true
		},
		xAxis : [{
					type : 'category',
					data : xData,
					axisTick : {
						alignWithLabel : true
					},
					axisLabel : {
						interval : 0,// 横轴信息全部显示
						rotate : -30
						// -30度角倾斜显示
					},
					axisLine : {
						lineStyle : {
							color : '#ccc',
							width : 1
							// 这里是为了突出显示加上的
						}
					}
				}],
		yAxis : [{
					type : 'value'
				}],
		series : [{
			name : '任务综合得分',
			type : 'bar',
			// barWidth : '60%',
			itemStyle : {
				normal : {
					// 随机显示
					color : function(d) {
						return "#"
								+ Math.floor(Math.random()
										* (256 * 256 * 256 - 1)).toString(16);
					}
				}
			},
			data : series_data
		}]
	}

	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}
