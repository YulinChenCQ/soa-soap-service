var navs = [{
	"title": "图文组件",
	"icon": "fa-cubes",
	"spread": true,
	"children": [{
		"title": "图文配置",
		"icon": "&#xe641;",
		"href": "graphic_display/html/graphic.html"
	}, {
		"title": "图文管理",
		"icon": "&#xe63c;",
		"href": "graphic_display/html/graphiclist.html"
	}]
}, {
	"title": "报表组件",
	"icon": "fa-cogs",
	"spread": false,
	"children": [ {
		"title": "报表配置",
		"icon": "fa-navicon",
		"href": "chart/html/line-bar-pie.html"
	}, {
		"title": "报表管理",
		"icon": "&#xe62a;",
		"href": "#"
	}]
}];