/**
 * 
 * <模板公共的树形菜单组件js文件>
 * <p>
 * <使用时候直接使用treeTpl导入即可>
 * 
 * @author 欧增奇
 * @version [V1.0, 2017年12月5日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

// 树形模块
layui.define(['common', 'form', 'treeKl'], function(exports)
{
    "use strict";

    // 引入第三方模块
    var $ = layui.$, common = layui.common, tree = layui.treeKl, form = layui.form

    // 常见变量
    , MOD_NAME = 'treeTpl', _WIN = $(window), _DOC = $(document), SHOW = 'layui-show', HIDE = 'layui-hide'

    // 外部接口
    , treeTpl = {}

    // 内部接口
    , inside = {};

    // 解析数据
    inside.analysisData = function(data, config)
    {
        var _n = [], _data = data || [], _conf = config || {}, _sort = _conf.sort || 'sort', _name = _conf.name || 'name';
        for (var _i = 0, lg = _data.length; _i < lg; _i++)
        {
            var _obj = _data[_i], _codes = _obj[_sort].split('-');

            _obj.name = _obj[_name];
            _obj.spread = true;
            // 老大
            if (_codes.length == 1)
            {
                _n.push(_obj);
            } else
            {
                // 孩子
                var objs = _n, _ch;

                for (var _j = 1, _lg = _codes.length; _j < _lg; _j++)
                {
                    _ch = objs[objs.length == 1 ? 0 : objs.length - 1];
                    objs = _ch.children = _ch.children || [];
                }
                objs.push(_obj);
            }
        }
        return _n;
    };

    // 验证是否选择
    treeTpl.verify = function(config)
    {
        var _vthis = $(this), _config = config || {};

        if (!_config.id)
            return false;

        // 需要选择的行数，-1不需要验证
        _config.number = _config.number || -1;

        // 验证失败后的提示语句
        _config.msg = _config.msg || '请勾选需要操作的数据行！';

        // 弹出框配置信息
        _config.config = _config.config || {
            skin : 'sts-msg-warn'
        };

        var _dataId = _config.id || '#tree-id', _dataObj = $(_dataId), selectedData = tree.getSelected(_dataObj);
        if (selectedData.length <= 0 || (_config.number != -1 && selectedData.length != _config.number))
        {
            layer.msg(_config.msg, _config.config);
            return false;
        }
    };

    // 页面删除数据
    treeTpl.deleteData = function(config)
    {
        var _vthis = $(this), _config = config || {};

        if (!_config.id || !_config.field)
            return false;

        // 删除url
        _config.url = _config.url || 'api/deleteList/do';

        // 删除其它参数
        _config.params = _config.params || {};

        var _dataId = _config.id || '#tree-id', _dataObj = $(_dataId), selectedData = tree.getSelected(_dataObj);
        for (var cs = 0, lg = selectedData.length; cs < lg; cs++)
        {
            _config.params['tables.tables[' + cs + '].fields[0].fieldName'] = _config.field;
            _config.params['tables.tables[' + cs + '].fields[0].fieldValue'] = selectedData[cs][_config.field];
            _config.params['tables.tables[' + cs + '].fields[0].fieldKey'] = true;
        }

        layer.confirm('真的删除已选择的行么？', {
            shade : 0.01
        }, function(index)
        {
            common.sendAjax(_config.url, _config.params, function(json)
            {
                if (json.code == 0)
                {
                    config._jqThis && config._jqThis.trigger("kylinEventClick", ['' + config.event.index]);
                } else
                {
                    layer.msg(json.data || json.message || '操作失败！', {
                        icon : 2
                    });
                }
            }, function(json)
            {
                layer.alert((json.responseJSON && json.responseJSON.error && json.responseJSON.message) || '服务或网路错误！', {
                    icon  : 2,
                    shade : 0.01
                });
            });
            layer.close(index);
        });
    };

    // 表单编辑
    treeTpl.form = function(config)
    {
        var _config = config || {}, selectedData;

        // 选中数据
        if (_config.data)
        {
            var _dataId = _config.data || '#tree-id', _dataObj = $(_dataId);
            selectedData = tree.getSelected(_dataObj);
        }

        // 填充
        if (_config.form && selectedData && selectedData.length > 0)
        {
            var _formId = _config.form || '#tree-form-id', _formObj = $(_formId), _name = _config.name && _config.name + '.', _full = _config.full || [];

            for (var _f = 0, _lg = _full.length; _f < _lg; _f++)
            {
                var _fns = _full[_f].split('->');
                _formObj.find('[name="' + _name + _fns[0] + '"]').filter(':not([data-tpl])').val(selectedData[0][_fns.length > 1 ? _fns[1] : _fns[0]] || '');
            }
        }
    };

    // 切换展开和关闭状态
    treeTpl.spread = function(id, config)
    {
        var _id = id || '#tree-id', treeObj = $(_id), _config = config || {};

        if (treeObj.length <= 0)
            return;

        // 异步执行后传过来的点击对象
        var $this = $(this), text = $.trim($this.text()), open = _config.open || [], close = _config.close || [];
        // 判断是展开还是关闭
        if ($this.length <= 0)
            return;

        if (text == open[0])
            $this.html('<i class="layui-icon ' + close[1] + '"></i>' + close[0]);
        else
            $this.html('<i class="layui-icon ' + open[1] + '"></i>' + open[0]);

        treeObj.find('.layui-tree-spread').each(function()
        {
            var _t = $(this), _c = _t.text().charCodeAt(0);
            _c == (text == open[0] ? 58915 : 58917) && _t.click();
        });
    };

    // 刷新组件
    treeTpl.reload = function(id)
    {
        var SELECTED = 'sts-tree-selected', $this = (typeof(id) === "string" && $(id)) || id, treeConfig = common.getConfig($this), _params = common.getParams(treeConfig.init)[0];

        _params.url = _params.url || "api/list/do";
        // 加载数据
        common.sendAjax(_params.url, _params.params || {}, function(json)
        {
            if (json.code == 0)
            {
                $this.empty();
                tree.render({
                    elem  : $this,
                    nodes : inside.analysisData(json.data.objs || json.data, _params),
                    click : function(t, node)
                    {
                        // 点击选中效果
                        $this.find('.' + SELECTED).removeClass(SELECTED);
                        $(t).addClass(SELECTED);

                        // 如果有点击事件
                        var _con = _params.click;
                        if (_con)
                        {
                            // 是否自定义函数
                            var fullFun = _con.customFun;
                            if (fullFun)
                            {
                                var _type = fullFun.split('(')[0], _funs = _type.split('.'), _funThis;
                                for (var fi = 0, _fl = _funs.length; fi < _fl; fi++)
                                {
                                    var _fun = _funs[fi], _obj = _funThis || window;
                                    if (_fun && _obj[_fun])
                                        _funThis = _obj[_fun];
                                }
                                // 已经找到是函数
                                if ($.isFunction(_funThis))
                                {
                                    var result = _funThis.apply(this, [t, node]);
                                    if (typeof result == "boolean" && !result)
                                        return result;
                                }
                            }

                            // 填充数据
                            if (_con.id)
                            {
                                var _form = $(_con.id), _name = (_con.name && _con.name + '.') || '';
                                $.each(node, function(key, val)
                                {
                                    _form.find('[name="' + _name + key + '"]').filter(':not([data-tpl])').val(val);
                                });
                                form.render();
                            }
                        }
                    }
                });
            } else
            {
                $this.html(['<li>', json.data || json.message || '操作失败！', '</li>'].join(''));
            }
        }, function(json)
        {
            $this.html(['<li>', (json.responseJSON && json.responseJSON.error && json.responseJSON.message) || '服务或网路错误！', '</li>'].join(''));
        });
    };

    // 刷新页面
    treeTpl.render = function()
    {
        // 初始化树形
        $('[data-init^="tree"]').each(function()
        {
            treeTpl.reload($(this));
        });
    };

    exports(MOD_NAME, treeTpl);

});