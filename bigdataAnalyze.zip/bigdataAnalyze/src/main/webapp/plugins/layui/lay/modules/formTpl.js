/**
 * 
 * <模板公共的后台组件js文件>
 * <p>
 * <使用时候直接使用formTpl导入即可>
 * 
 * @author 欧增奇 https://www.ouzengqi.com/
 * @version [1.0.0rc1, 2018年01月22日]
 * @see [相关类/方法]
 * @since [kylin/1.0.0]
 */

// 表单模块
layui.define(['element', 'laytpl', 'layer', 'form', 'laydate', 'common'], function(exports)
{
    "use strict";

    // 引入模块
    var $ = layui.$, common = layui.common, element = layui.element, laytpl = layui.laytpl, layer = layui.layer, laydate = layui.laydate, form = layui.form, device = layui.device()

    // 常见变量
    , MOD_NAME = 'formTpl', dom = document, _WIN = $(window), _DOM = $(dom), THIS = 'layui-this', SHOW = 'layui-show', HIDE = 'layui-hide'

    // 内部变量
    , _FORM_NAME = '.layui-form', _PAGE = '.content-page', DANGER = 'layui-form-danger'

    // 属性
    , ATTR = ['data-val', 'data-code', 'data-verify']

    // 外部接口
    , formTpl = {},

    // 内部接口
    inside = {};

    // 多选下拉渲染
    inside.selectMultiple = function($this)
    {
        var $select = $this.next(".layui-form-select"), $input = $select.find('input'), $dl = $select.find("dl"), $vals = ($this.attr('data-val') && $this.attr('data-val').split(',')) || [];

        $dl.empty();

        $select.toggleClass("sts-multiple", true);

        var str = "", _cText = "";
        $("option", $this).each(function()
        {
            var _obj = $(this), _text = _obj.text(), _val = _obj.val();
            if (_val && _val.length > 0)
            {
                str = ["<dd>", "<input type='checkbox' lay-skin='primary' title='", _text || _val, "' value='", _val || _text, "'", function()
                    {
                        var isChecked = $vals.indexOf(_val) > -1;
                        if (isChecked)
                            _cText += (_cText.length > 0 ? ',' : '') + (_text || _val);
                        return isChecked ? 'checked' : '';
                    }(), ">", "</dd>"].join("");
                $dl.append(str);
            }
        });
        $input.val(_cText);

        form.render("checkbox");

        // 点击下拉选项
        $(".sts-multiple .layui-unselect").off("click");
        $(".sts-multiple dd").off("click");
        /*
         * $(".sts-multiple .layui-form-checkbox").css({ 'margin-top' : '0px' });
         */
    };

    // 多选点击效果
    _DOM.on("click", ".sts-multiple dd", function(e)
    {
        var $this = $(this).closest('dd'), multiple = $this.closest(".sts-multiple"), _showInput = multiple.find('.layui-select-title input'), $checkbox = $this.find('.layui-form-checkbox');

        $checkbox.toggleClass('layui-form-checked');

        /*
         * if (_verify.length > 0 && multiple.find('dd .layui-form-checked').length <= 0) { $checkbox.toggleClass('layui-form-checked'); e.stopPropagation(); return false; }
         */
        var _cText = "", _cVal = "";
        $("dd", multiple).each(function()
        {
            var _obj = $(this).find('input'), _text = _obj.attr('title'), _val = _obj.val();
            if ($(this).find('.layui-form-checked').length > 0)
            {
                _cText += (_cText.length > 0 ? ',' : '') + (_text || _val);
                _cVal += (_cVal.length > 0 ? ',' : '') + (_val || '');
            }
        });
        _showInput.val(_cText);
        multiple.prev('select').attr('data-val', _cVal);

        e.stopPropagation();
        return false;
    });

    // 表单reset重置
    formTpl.reset = function(config)
    {
        var _vthis = $(this), _config = config || {};

        // 绑定的表单
        _config.formObj = (_config.form && ((_config.form instanceof $ && _config.form) || $(_config.form))) || _vthis.closest('.layui-form');

        // 强制清理所有，包括隐藏属性
        _config.reset = _config.reset || 'no';

        _config.formObj.find('[name]').filter(':not([data-ignore],[ignore])').each(function()
        {
            var _ethis = $(this), _show = _ethis.is(':visible');

            if (_config.reset == 'all' || _show || function()
            {
                var _tempShow = _ethis.next(_FORM_NAME + '-radio').length > 0;
                if (!_tempShow)
                    _tempShow = _ethis.next(_FORM_NAME + '-select').length > 0;
                if (!_tempShow)
                    _tempShow = _ethis.next(_FORM_NAME + '-checkbox').length > 0;
                if (!_tempShow)
                    _tempShow = _ethis.next(_FORM_NAME + '-switch').length > 0;
                return _tempShow;
            }())
            {
                var _econfig = common.getConfig(_ethis);

                // 多选,或者异步加载
                if (_ethis.is('select[multiple],select[data-multiple],select[data-init^="select"]'))
                    _ethis.attr('data-val', '');
                else
                    _ethis.val(_econfig.input.val || '');

                _ethis.removeClass(DANGER);
            }
        });

        form.render();

        // 多选下拉渲染
        $("select[multiple],select[data-multiple]").each(function()
        {
            inside.selectMultiple($(this));
        });
    };

    // 表单提交
    formTpl.submit = function(config)
    {
        var _vthis = $(this), _config = config || {};

        // 提交url
        _config.url = _config.url || 'api/addOrUpdate/do';

        // 绑定的表单
        _config.formObj = (_config.form && $(_config.form)) || _vthis.closest('.layui-form');

        // 提交其它参数
        _config.params = _config.params || {};

        _config.formObj.find('[name]').filter(':not([data-ignore],[ignore])').each(function()
        {
            var _ethis = $(this), _name = _ethis.attr('name'), _value = common.getJqVal(_ethis);

            // 判断值是否需要填充
            if (_name && _value && _value.indexOf("layui") == 0)
            {
                try
                {
                    var _funThis = common.getFunObj(_value);
                    if (_funThis != null)
                        _value = _funThis.apply(this, common.getParams(_value));
                } catch (e)
                {
                    _value = '';
                }
            }

            if (_name && _value && _value.length > 0)
            {
                // 本来表信息配置
                if (_name.indexOf("table") == 0)
                {
                    _config.params[_name] = _value;
                    return true;
                }

                // 原样输出
                if (_name.indexOf("^") == 0)
                {
                    _config.params[_name.substr(1)] = _value;
                    return true;
                }

                var index = 0;
                for (var property in _config.params)
                    if (function(str, endStr)
                    {
                        var d = str.length - endStr.length;
                        return (d >= 0 && str.lastIndexOf(endStr) == d);
                    }(property, '].fieldName') && _config.params.hasOwnProperty(property))
                        index++;

                _config.params['table.fields[' + index + '].fieldName'] = _name;
                _config.params['table.fields[' + index + '].fieldValue'] = _value;

                // 主键设置
                var _key = (_ethis.attr('data-key') && _ethis.attr('data-key') == 'true') || false;
                if (_key)
                    _config.params['table.fields[' + index + '].fieldKey'] = true;
            }
        });

        var _loadIndex = layer.load(1);
        common.sendAjax(_config.url, _config.params, function(json)
        {
            layer.close(_loadIndex);
            if (json.code == 0)
            {
                layer.msg(json.message || '提交成功！', {
                    icon : 1
                });
                config._jqThis.trigger("kylinEventClick", ['' + config.event.index]);
            } else
            {
                layer.msg(json.data || json.message || '操作失败！', {
                    icon : 2
                });
            }
        }, function(json)
        {
            layer.close(_loadIndex);
            layer.alert((json.responseJSON && json.responseJSON.error && json.responseJSON.message) || '服务或网路错误！', {
                icon  : 2,
                shade : 0.01
            });
        }, {
            async : true
        });
    };

    // 页面初始化
    formTpl.init = function(config)
    {
        var _form = $(_PAGE + '[' + ATTR[1] + '="' + config.code + '"]');
        _form.find('[name]').filter(':not([data-ignore],[ignore])').each(function()
        {
            var _input = $(this);
            // 默认值设置，重置用
            if (typeof(_input.attr(ATTR[0])) == "undefined")
                _input.attr(ATTR[0], _input.val() || '');
        });
        formTpl.reset({
            form  : _form,
            reset : 'all'
        });
    };

    // 刷新页面
    formTpl.render = function(objConfig)
    {
        // 表格初始化
        $('[data-init^="form"]').each(function(index)
        {
            var _ethis = $(this), _form = _ethis.closest(_PAGE);

            // 判断当前是否显示，不显示，不初始化
            if (!_form.is("." + SHOW))
                return true;

            var itemConfig = common.getConfig(_ethis);
            if (objConfig)
            {
                var _funThis, params = common.getParams(itemConfig.init || ''), paramConfig = params && params[0], _name = paramConfig.name && paramConfig.name + '.', _funs = (paramConfig.data && paramConfig.data.split('.')) || [];

                // 得到参数值
                _funThis = common.getFunObj(_funs, objConfig);
                if (_funThis == null)
                    return true;

                $.each(_funThis, function(key, val)
                {
                    var _nameObj = _form.find('[name="' + key + '"],[name="' + _name + key + '"]').filter(':not([data-tpl])');

                    if (_nameObj.length > 0)
                    {
                        // 多选情况
                        if (_nameObj.is('select[multiple],select[data-multiple],select[data-init^="select"]'))
                            _nameObj.attr(ATTR[0], val);

                        // switch
                        else if (_nameObj.is('input[lay-skin="switch"]'))
                        {
                            var vals = (_nameObj.attr(ATTR[0]) || '').split('|');
                            if ((vals && vals.length > 0 && val == vals[0]) || val == 1 || val == 'true')
                                _nameObj.prop('checked', 'true');
                            else
                                _nameObj.removeAttr('checked');
                        } else
                            _nameObj.val(val);
                    }
                });

                // 是否自定义函数
                var fullFun = paramConfig.customFun;
                if (fullFun)
                {
                    var _n_funThis = common.getFunObj(fullFun);
                    if (_n_funThis != null)
                    {
                        var result = _n_funThis.apply(this, [_funThis]);
                        if (typeof result == "boolean" && !result)
                            return result;
                    }
                }
            }
        });

        // 初始化时间组件
        $('[data-init^="time"]').each(function(index)
        {
            var _ethis = $(this), _form = _ethis.closest(_PAGE);

            // 判断当前是否显示，不显示，不初始化
            if (!_form.is("." + SHOW))
                return true;

            var itemConfig = common.getConfig(_ethis);
            if (objConfig && itemConfig.init)
            {
                var params = common.getParams(itemConfig.init || ''), _objConfig = (params && params[0]) || {};

                // 是否定义id
                itemConfig.id = itemConfig.id || 'sts-time-' + function(n, m)
                {
                    return (new Date().getTime()) + '-' + Math.floor(Math.random() * (m - n + 1) + n)
                }(11111, 999999);

                // 防止元素没有id
                _ethis.attr('id', itemConfig.id);

                _objConfig.elem = _objConfig.elem || '#' + itemConfig.id;

                laydate.render(_objConfig);
            }
        });

        // 初始化下拉选项
        $('[data-init^="select"]').each(function(index)
        {
            var _ethis = $(this), _form = _ethis.closest(_PAGE);

            // 判断当前是否显示，不显示，不初始化
            if (!_form.is("." + SHOW))
                return true;

            var itemConfig = common.getConfig(_ethis);
            if (objConfig && itemConfig.init)
            {
                var params = common.getParams(itemConfig.init || ''), _objConfig = (params && params[0]) || {};

                // 是否异步加载数据
                if (_objConfig.url)
                {
                    common.sendAjax(_objConfig.url, _objConfig.where || {}, function(jsonData, e)
                    {
                        if (jsonData.code == 0 && jsonData.data.objs)
                        {
                            _ethis.html(laytpl((_objConfig.tpl && $(_objConfig.tpl).html()) || _ethis.html() || '').render(jsonData.data));
                            _ethis.is('select[data-init^="select"]') && function()
                            {
                                _ethis.val(_ethis.attr('data-val') || '');
                            }();
                            form.render('select');
                            _ethis.is('select[multiple],select[data-multiple]') && inside.selectMultiple(_ethis);
                        }
                    }, function()
                    {
                        _ethis.html('<option value="">数据加载异常！</option>');
                        form.render('select');
                    }, {
                        isCache : true
                    });
                }
            }
        });

        form.render();

        // 多选下拉渲染
        $("select[multiple],select[data-multiple]").each(function()
        {
            inside.selectMultiple($(this));
        });
    };

    // 公共-表单验证
    formTpl.verify = function(config)
    {

        var _vthis = $(this), _config = config || {}, verify = form.config.verify;

        // 绑定的表单
        _config.formObj = (_config.form && ((_config.form instanceof $ && _config.form) || $(_config.form))) || _vthis.closest('.layui-form');

        // 获取需要校验的元素
        var verifyElem = _config.formObj.find('[' + ATTR[2] + ']').filter(':not([data-ignore],[ignore])'), stop = null, KYLIN_MSG_WARN = 'sts-msg-warn';

        // 开始校验
        layui.each(verifyElem, function(_, item)
        {
            var othis = $(this), othisConfig = common.getConfig(othis), vers = othisConfig.input.verify, value = common.getJqVal(othis);

            // 获取验证配置
            if (vers)
            {
                vers = eval(vers);
                if (!$.isArray(vers))
                    vers = [vers];
            } else
                return true;

            othis.removeClass(DANGER);

            layui.each(vers, function(_, thisVer)
            {
                var errorText = '' // 用户自定义 错误 提示文本
                , isFn = typeof verify[thisVer.regExp] === 'function';

                // 匹配验证规则
                var isTrue = isFn ? errorText = thisVer.msg || verify[thisVer.regExp](value, item) : function()
                {
                    if (verify[thisVer.regExp])
                    {
                        return !verify[thisVer.regExp][0].test(value);
                    } else
                    {
                        var reg = eval(thisVer.regExp);
                        return !reg.test(value);
                    }
                }();
                errorText = errorText || thisVer.msg || verify[thisVer.regExp][1] || '输入错误！';

                // 如果是必填项或者非空命中校验，则阻止提交，弹出提示
                if ((isTrue && thisVer.regExp === 'required') || (isTrue && value))
                {
                    // 提示层风格
                    switch (thisVer.verType)
                    {
                        case 'alert' :
                            layer.alert(errorText, {
                                title      : '提示',
                                shade      : 0.01,
                                shadeClose : true
                            });
                            break;
                        case 'msg' :
                            layer.msg(errorText, {
                                icon  : 5,
                                shift : 6
                            });
                            break;

                        // 默认tips
                        default :
                            layer.tips(errorText, function()
                            {
                                if (typeof othis.attr('lay-ignore') !== 'string')
                                {
                                    if (item.tagName.toLowerCase() === 'select' || /^checkbox|radio$/.test(item.type))
                                    {
                                        return othis.next();
                                    }
                                }
                                return othis;
                            }(), {
                                tips : 1,
                                skin : KYLIN_MSG_WARN
                            });

                    }
                    if (!device.android && !device.ios)
                        item.focus(); // 非移动设备自动定位焦点
                    othis.addClass(DANGER);
                    return stop = true;
                }
            });
            if (stop)
                return stop;
        });
        return stop ? (false) : (true);
    };

    exports(MOD_NAME, formTpl);
});
