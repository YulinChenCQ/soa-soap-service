/**
 * 
 * <模板公共的js文件>
 * <p>
 * <使用时候直接使用common导入即可>
 * 
 * @author 欧增奇 https://www.ouzengqi.com/
 * @version [1.0.0rc1, 2018年01月22日]
 * @see [相关类/方法]
 * @since [kylin/1.0.0]
 */

// 公共模块
layui.define(['laytpl', 'layer', 'encrypt'], function(exports)
{
    "use strict";

    // 引入模块
    var $ = layui.$, laytpl = layui.laytpl, layer = layui.layer, encrypt = layui.encrypt

    // 字符常量
    , MOD_NAME = 'common', dom = document, _WIN = $(window), _DOM = $(dom)

    // 
    , _FORM_NAME = '.layui-form'

    // 属性
    , ATTR = ['data-event', 'data-code', 'data-href', 'data-tpl', 'data-data', 'data-init', 'data-val', 'data-verify', 'data-expr']

    // 其它元素字符
    , DIVI = ['.', '#', ';', ',', '|']

    // 外部接口
    , common = {
        // 公共配置文件
        config : {
            // 基本请求
            urls : {
                // 首页
                index            : '/',
                // 主页
                main             : '/admin/main.html',
                // 退出登录
                logout           : '/logout/do',
                // 强行退出登录
                'q!logout'       : '/logout',
                // 后台登录
                loginDo          : '/login/do',
                // 登录
                login            : '/admin/login.html',
                // 修改密码
                updatePasswordDo : '/updatePassword/do',
                // 修改密码
                updatePassword   : '/admin/updatePassword.html'
            }
        },
        // 认证信息
        auth   : {
            token : 'soa.sts.tk',
            time  : 'soa.sts.ti',
            sign  : 'soa.sts.si'
        },
        // 缓存
        cache  : {
            // 过期时间，单位：毫秒
            overdue : 120000
        }
    };

    /**
     * 对Date的扩展，将 Date 转化为指定格式的String
     * <p>
     * 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符<br>
     * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) <br>
     * 例子：<br>
     * (new Date()).format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423<br>
     * (new Date()).format("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18
     */
    Date.prototype.format = function(fmt)
    {
        var date = this, o = {
            "M+" : date.getMonth() + 1, // 月份
            "d+" : date.getDate(), // 日
            "h+" : date.getHours(), // 小时
            "H+" : date.getHours(), // 小时
            "m+" : date.getMinutes(), // 分
            "s+" : date.getSeconds(), // 秒
            "q+" : Math.floor((date.getMonth() + 3) / 3), // 季度
            "S"  : function()
            {
                var str = '', milliseconds = String(date.getMilliseconds());
                for (var i = milliseconds.length; i < 3; i++)
                    str += '0';
                return str + milliseconds;
            }
        };
        if (/(y+)/.test(fmt))
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt))
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };

    // 判断字符串以什么结尾
    /**
     * 判断字符串以什么结尾
     * <p>
     * str:待判断的字符串<br>
     * endStr:结束的字符串
     */
    String.prototype.endWith = function(endStr)
    {
        if ($.isEmptyObject(endStr))
            return false;

        var d = this.length - endStr.length;
        return (d >= 0 && this.lastIndexOf(endStr) == d);
    };

    // 创建签名
    common.createSign = function(params)
    {
        // 参数数组
        var objArr = [];

        if (!$.isEmptyObject(params))
            for (var key in params)
                objArr.push(key);
        // objArr.push('timestamp=' + new Date().getTime());

        // 排序 小到大
        objArr.sort();

        // 拼接参数
        var sign = "";
        for (var i = 0, lg = objArr.length; i < lg; i++)
        {
            var key = objArr[i] + "";
            var value = params[key] + "";
            sign += (sign.length > 0 ? '&' : '') + key + '=' + value;
        }

        // 编码解决一致性
        sign = encodeURIComponent(sign);
        // console.log(sign);

        // md5
        sign = encrypt.md5.hex_md5(sign);

        // 位移
        sign = encrypt.shift(sign, false, 3);

        // base64
        sign = encrypt.base64.encode(sign).replace(/=/g, "");
        // console.log(sign);
        return sign;
    };

    // 公共-发送Ajax请求(默认post)
    /**
     * 公共-发送Ajax请求(默认post)
     * <p>
     * url:请求的url（必填）<br>
     * params:请求的参数<br>
     * callbackFun:请求的成功返回回调（服务器返回json对象，e）<br>
     * errorFun:请求的失败回调（服务器返回json对象，e）<br>
     * config:额外的配置（无法重写以下属性：url，data，success，error）<br>
     */
    common.sendAjax = function(url, params, callbackFun, errorFun, config)
    {
        var $this = this, url = common.config.urls[url || ''] || url || '', params = $.extend(true, {}, params || {}), config = config || {};

        if (url.length <= 0)
            return;

        var user = common.data('sts.user') || common.data('acc') || {};
        // timestamp,token,sign必须要有
        params[common.auth.token] = user.token || '';
        params[common.auth.time] = new Date().getTime();
        // sign一定要放在最后，因为不纳入编码
        params[common.auth.sign] = common.createSign(params);

        // 合并修改
        $.extend(config, {
            url     : url,
            data    : params,
            success : function(json, e)
            {
                // 缓存数据
                config.isCache && json.code == 0 && common.data(common.hashCode(url), {
                    time : new Date().getTime(),
                    json : json,
                    e    : e
                }, sessionStorage);

                if ($.isFunction(callbackFun))
                {
                    callbackFun(json, e);
                } else if (json.code && json.code != 0)
                    layui.hint().error(json);
            },
            error   : function(json, e)
            {
                if ($.isFunction(errorFun))
                    errorFun(json, e);
                else if (json.code && json.code != 0)
                    layui.hint().error('获取信息失败，url：' + url + '失败\nparams：' + params + '！');
            }
        });

        config.type = config.type || 'post';
        config.dataType = config.dataType || 'json';

        // 提取缓存的数据
        if (config.isCache)
        {
            var _jsonConfig = common.data(common.hashCode(url), null, sessionStorage);
            var _time = new Date().getTime();
            if (_jsonConfig && _time - _jsonConfig.time <= common.cache.overdue)
            {
                if ($.isFunction(callbackFun))
                {
                    callbackFun(_jsonConfig.json, _jsonConfig.e);
                    return;
                } else
                    common.data(common.hashCode(url), 'null', sessionStorage);
            }
        }

        $.ajax(config);
    };

    // 判断是否为jq选择器
    /**
     * 判断是否为jq选择器
     * <p>
     * str:待判断的字符串
     */
    common.jqSelector = function(str)
    {
        try
        {
            // 本身为空
            if ($.isEmptyObject(str))
                return false;

            // 查找是否有laytpl模板引擎的语法
            if (str.indexOf('{{') != -1)
                return false;

            // jq编译
            return $(str).length > 0;
        } catch (e)
        {
            return false;
        }
    };

    // 公共-当前元素的值
    /**
     * 公共-当前元素的值
     * <p>
     * obj:jq对象
     */
    common.getJqVal = function(obj)
    {
        if (obj.next(_FORM_NAME + '-radio').length > 0)
        {
            obj.each(function()
            {
                if ($(this).next(_FORM_NAME + '-radio').is(_FORM_NAME + '-radioed'))
                {
                    obj = $(this);
                    return false;
                }
            });
        } else if (obj.next(_FORM_NAME + '-select').length > 0)
        {
            // 判断是否为多选
            if (obj.is('select[multiple],select[data-multiple]'))
                return obj.attr('data-val') || '';

            var $obj = obj.next(_FORM_NAME + '-select').find('input');
            obj.find('option').filter('[text="' + $obj.val() + '"]').attr('selected', true);
        } else if (obj.next(_FORM_NAME + '-checkbox').length > 0)
        {
            return obj.next(_FORM_NAME + '-checkbox').is(_FORM_NAME + '-checked');
        } else if (obj.next(_FORM_NAME + '-switch').length > 0)
        {
            // 判断是否有设置的备选值
            var isChecked = obj.next(_FORM_NAME + '-switch').is(_FORM_NAME + '-onswitch'), vals = (obj.attr('data-val') || '').split('|');
            if (vals && vals.length > 0)
                return vals[isChecked ? 0 : 1];
            else
                return isChecked;
        }
        return obj.val() || '';
    };

    // js实现java里面的hashCode
    /**
     * js实现java里面的hashCode
     * <p>
     * str:待转换的字符串
     */
    common.hashCode = function(str)
    {
        var _str = '';
        // 判断类型-数组
        if ($.isArray(str))
            for (var is = 0; is < str.length; is++)
                _str += str[is];
        else
            _str = str + '';
        _str = _str || '';

        var h = 0, len = _str.length, t = 2147483648;
        for (var i = 0; i < len; i++)
        {
            h = 31 * h + _str.charCodeAt(i);
            if (h > 2147483647)
                h %= t;
        }
        return h;
    };

    // 提取字符串括号里面的参数
    /**
     * 提取字符串括号里面的参数
     * <p>
     * str:待提取的字符串
     */
    common.getParams = function(str)
    {
        var $this = this, params = [], _code = [-1, -1, -1, -1], _str = str || '', addStr = function(thisStr)
        {
            _code[0] = (_code[0] === -1 ? '' : _code[0]) + thisStr;
        };

        for (var i = 0; i < _str.length; i++)
        {
            var thisStr = _str.charAt(i);
            switch (thisStr)
            {
                // 1
                case '(' :
                    if (_code[3] > 0 && _code[3] == i - 1)
                    {
                        addStr(thisStr);
                        _code[3] = -1;
                    } else if (_code[3] === -1)
                        _code = [-1, i, -1, -1];
                    break;

                // 2
                case ')' :
                    if (_code[3] > 0 && _code[3] == i - 1)
                    {
                        addStr(thisStr);
                        _code[3] = -1;
                    } else if (_code[3] === -1 && _code[0] != -1)
                    {
                        var jsCode = _code[0];
                        try
                        {
                            // 去除括号里面的转义
                            jsCode = jsCode.replace(/\\\(/g, '(');
                            jsCode = jsCode.replace(/\\\)/g, ')');
                            params = params.concat(eval('[' + jsCode + ']'));
                        } catch (e)
                        {
                            layui.hint().error('提取参数异常\n\n原字符：' + str + '\n\n现字符：' + _str.substring(i) + '\n\n位置：' + i);
                        }
                        _code = [-1, -1, -1, -1];
                    }
                    break;

                // 3
                case '\\' :
                    _code[3] = i;
                    addStr(thisStr);
                    break;

                // 0
                default :
                    addStr(thisStr);
                    _code[3] = -1;

            }
        }
        return params;
    };

    // 读取数据
    common.data = function(_key, _val, _storage)
    {
        var key = encrypt.trans(encrypt.base64.encode((_key || 'sts') + '')), storage = _storage || localStorage;

        if (_val == 'null')
            storage.removeItem(key);
        else if (_val)
        {
            try
            {
                storage.setItem(key, encrypt.trans(encrypt.base64.encode(JSON.stringify(_val || {}))));
            } catch (e)
            {
                storage.setItem(key, encrypt.trans(encrypt.base64.encode(_val || '')));
            }
        } else
        {
            var val = storage.getItem(key);
            try
            {
                if (val)
                    return JSON.parse(encrypt.base64.decode(encrypt.trans(val)));
            } catch (e)
            {
            }
            return val;
        }
    };

    // 读取元素配置信息
    /**
     * 读取元素配置信息
     * <p>
     * jqObj:jq选择对象
     */
    common.getConfig = function(jqObj)
    {

        if (jqObj.length <= 0)
            return {};

        var tagName = jqObj[0].tagName.toLowerCase(), config = {
            // 元素id
            id     : jqObj.attr('id'),
            // 元素名称
            name   : jqObj.attr('name'),
            // 初始化元素
            init   : jqObj.attr(ATTR[5]),
            // 元素事件
            events : (jqObj.attr(ATTR[0]) && jqObj.attr(ATTR[0]).split(DIVI[2])) || [],
            // 元素一位code
            code   : jqObj.attr(ATTR[1]) || 0,
            // 模板内容替换里面类型
            laytpl : jqObj.attr(ATTR[3]) && (common.jqSelector(jqObj.attr(ATTR[3])) ? $(jqObj.attr(ATTR[3])).html() : jqObj.attr(ATTR[3])),
            // 链接信息
            a      : {
                // 标题
                title  : $.trim(jqObj.attr('title') || jqObj.text() || ''),
                // 链接地址
                href   : jqObj.attr('href') || jqObj.attr(ATTR[2]),
                // 打开方式
                target : jqObj.attr('target')
            },
            // 输入框
            input  : {
                // 老的值
                val    : jqObj.attr(ATTR[6]),
                // 验证
                verify : jqObj.attr(ATTR[7]),
                // 条件连接关系
                expr   : jqObj.attr(ATTR[8])
            },
            // 其它的数据包
            data   : jqObj.attr(ATTR[4])
        };

        switch (tagName)
        {
            // 处理表格数据
            case 'table' :
                // 表格相关
                config.table = eval('(' + (config.data || '{}') + ')');

                // 处理列
                config.table.cols = [];

                jqObj.find('thead tr').each(function()
                {
                    var _feThis = $(this), _col = [];
                    _feThis.find('th').each(function()
                    {
                        var _feT = $(this), _data = eval('(' + (_feT.attr(ATTR[4]) || '{}') + ')');
                        _data.title = _data.title || $.trim(_feT.text() || '');
                        _col.push(_data);
                    });
                    config.table.cols.push(_col);
                });
                break;

            default :
        }

        return config;
    };

    // 查询函数是否存在
    common.getFunObj = function(fun, obj)
    {
        if ($.isEmptyObject(fun))
            return null;

        var _funs = $.isArray(fun) ? fun : (fun.split('(')[0] || '').split('.'), _funThis = obj || window;
        for (var fi = 0; fi < _funs.length; fi++)
        {
            var _fun = _funs[fi], _obj = _funThis || window;
            if (_fun && _obj[_fun])
                _funThis = _obj[_fun];
        }

        return _funThis || null;
    };

    // js 生成uuid
    common.uuid = function(len, radix)
    {
        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
        var uuid = [], i;
        radix = radix || chars.length;

        if (len)
        {
            // Compact form
            for (i = 0; i < len; i++)
                uuid[i] = chars[0 | Math.random() * radix];
        } else
        {
            // rfc4122, version 4 form
            var r;

            // rfc4122 requires these characters
            uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
            uuid[14] = '4';

            // Fill in random data. At i==19 set the high bits of clock sequence as
            // per rfc4122, sec. 4.1.5
            for (i = 0; i < 36; i++)
            {
                if (!uuid[i])
                {
                    r = 0 | Math.random() * 16;
                    uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
                }
            }
        }
        return uuid.join('');
    }

    exports(MOD_NAME, common);
});
