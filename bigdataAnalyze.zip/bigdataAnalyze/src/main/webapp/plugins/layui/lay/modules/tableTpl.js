/**
 * 
 * <模板公共的后台组件js文件>
 * <p>
 * <使用时候直接使用tableTpl导入即可>
 * 
 * @author 欧增奇 https://www.ouzengqi.com/
 * @version [1.0.0rc1, 2018年01月22日]
 * @see [相关类/方法]
 * @since [kylin/1.0.0]
 */

// 表格模块
layui.define(['element', 'laytpl', 'layer', 'common', 'tableKl'], function(exports)
{
    "use strict";

    // 引入模块
    var $ = layui.$, common = layui.common, element = layui.element, laytpl = layui.laytpl, layer = layui.layer, tableKl = layui.tableKl

    // 常见变量
    , MOD_NAME = 'tableTpl', dom = document, _WIN = $(window), _DOM = $(dom), THIS = 'layui-this', SHOW = 'layui-show', HIDE = 'layui-hide'

    // 内部变量
    , _FORM_NAME = '.layui-form', _PAGE = '.content-page'

    // 外部接口
    , tableTpl = {},

    // 内部接口
    inside = {};

    // 表格列（行）点击事件
    inside.tableTrTdClick = function()
    {
        var _rthis = $(this), table = _rthis.closest('.layui-table-view').prev('table[data-init="table"]'), itemConfig = common.getConfig(table);

        // 添加行监听
        if (_rthis.find('.laytable-cell-checkbox').length <= 0 && itemConfig.table && itemConfig.table.trClick)
        {
            var _funThis = common.getFunObj(itemConfig.table.trClick);
            if (_funThis == null)
                return true;

            itemConfig.table.id = itemConfig.table.id || itemConfig.id || 'sts-' + index;

            var _index = parseInt(_rthis.closest('tr').attr('data-index') || '0');
            var trData = tableKl.cache[itemConfig.table.id][_index];
            _funThis.apply(this, [trData]);
        }
    };

    // 刷新页面
    tableTpl.render = function()
    {
        // 表格初始化
        $('[data-init^="table"]').each(function(index)
        {
            var _ethis = $(this);

            // 判断当前是否显示，不显示，不初始化
            if (!_ethis.closest(_PAGE).is("." + SHOW))
                return true;

            var itemConfig = common.getConfig(_ethis);
            if (itemConfig.table)
            {
                itemConfig.table.id = itemConfig.table.id || itemConfig.id || 'sts-' + index;
                itemConfig.table.elem = itemConfig.table.elem || '#' + itemConfig.id || '#sts-' + index;
                itemConfig.table.url = itemConfig.table.url || 'api/listPage/do';

                // 默认一些参数
                itemConfig.table.request = itemConfig.table.request || {
                    // 页码的参数名称，默认：page
                    pageName  : 'page.currentPage',
                    // 每页数据量的参数名，默认：limit
                    limitName : 'page.everyPage'
                };
                itemConfig.table.response = itemConfig.table.response || {
                    // 数据状态的字段名称，默认：code
                    statusName : 'code',
                    // 成功的状态码，默认：0
                    statusCode : 0,
                    // 状态信息的字段名称，默认：msg
                    msgName    : 'message',
                    // 数据总数的字段名称，默认：count
                    countName  : 'count',
                    // 数据列表的字段名称，默认：data
                    dataName   : 'objs'
                };
                itemConfig.table.method = itemConfig.table.method || 'post';
                // 返回前回掉
                itemConfig.table.before = function(res)
                {
                    if (res.code != -1)
                    {
                        if (res.data.page)
                            res.count = res.data.page.totalCount;
                        res.objs = res.data.data;
                    }
                };
                tableKl.render(itemConfig.table);
            }
        });

        // 行监听
        var tableTrTd = '.layui-table-view .layui-table-body table tr td';
        _DOM.off('click', tableTrTd, inside.tableTrTdClick);
        _DOM.on('click', tableTrTd, inside.tableTrTdClick);
    };

    // 验证表格是否选中
    tableTpl.verify = function(config)
    {
        var _vthis = $(this), _config = config || {};

        if (!_config.id)
            return false;

        // 需要选择的行数，-1不需要验证
        _config.number = _config.number || -1;

        // 验证失败后的提示语句
        _config.msg = _config.msg || '请勾选需要操作的数据行！';

        // 弹出框配置信息
        _config.config = _config.config || {
            skin : 'sts-msg-warn'
        };

        var checkStatus = tableKl.checkStatus(_config.id);
        if (checkStatus.data.length <= 0 || (_config.number != -1 && checkStatus.data.length != _config.number))
        {
            layer.msg(_config.msg, _config.config);
            return false;
        }
    };

    // 页面搜索表格
    tableTpl.search = function(config)
    {
        var _vthis = $(this), _config = config || {}, _where = {};

        if (!_config.id)
            return false;

        // 绑定的表单
        _config.formObj = _config.form && $(_config.form);

        _config.formObj.find('[name]').each(function()
        {
            var _ethis = $(this), _config = common.getConfig(_ethis), _val = _ethis.val();

            if (_config.name)
            {
                if (_config.input.expr)
                    _where[_config.name.split('.')[0] + '.customWhere'] = function()
                    {
                        var ns = _config.name.split('.'), q_where = _where[ns[0] + '.customWhere'] ? ' and ' : '';
                        if (_val)
                            return q_where + ns[1] + _config.input.expr + '\'' + _val + '\'';
                        else
                            return _where[ns[0] + '.customWhere'] ? _where[ns[0] + '.customWhere'] : '';
                    }();
                else
                    _where[_config.name] = _val;
            }
        });

        tableKl.reload(_config.id, {
            where : _where
        });
    };

    // 页面删除数据
    tableTpl.deleteData = function(config)
    {
        var _vthis = $(this), _config = config || {};

        if (!_config.id || !_config.field)
            return false;

        // 删除url
        _config.url = _config.url || 'api/deleteList/do';

        // 删除其它参数
        _config.params = _config.params || {};

        var checkStatus = tableKl.checkStatus(_config.id);
        for (var cs = 0, lg = checkStatus.data.length; cs < lg; cs++)
        {
            _config.params['tables.tables[' + cs + '].fields[0].fieldName'] = _config.field;
            _config.params['tables.tables[' + cs + '].fields[0].fieldValue'] = checkStatus.data[cs][_config.field];
            _config.params['tables.tables[' + cs + '].fields[0].fieldKey'] = true;
        }

        layer.confirm('真的删除已选择的行么？', {
            shade : 0.01
        }, function(index)
        {
            common.sendAjax(_config.url, _config.params, function(json)
            {
                if (json.code == 0)
                {
                    // tableKl.reload(_config.id);
                    config._jqThis && config._jqThis.trigger("kylinEventClick", ['' + config.event.index]);
                } else
                {
                    layer.msg(json.data || json.message || '操作失败！', {
                        icon : 2
                    });
                }
            }, function(json)
            {
                layer.alert((json.responseJSON && json.responseJSON.error && json.responseJSON.message) || '服务或网路错误！', {
                    icon  : 2,
                    shade : 0.01
                });
            });
            layer.close(index);
        });
    };

    exports(MOD_NAME, tableTpl);
});
