/**
 * 
 * <模板公共的后台组件js文件>
 * <p>
 * <使用时候直接使用adminTpl导入即可>
 * 
 * @author 欧增奇 https://www.ouzengqi.com/
 * @version [1.0.0rc1, 2018年01月22日]
 * @see [相关类/方法]
 * @since [kylin/1.0.0]
 */

// 后端模块
layui.define(['element', 'laytpl', 'layer', 'common', 'formTpl'], function(exports)
{
    "use strict";

    // 引入模块
    var $ = layui.$, common = layui.common, device = layui.device(), element = layui.element, laytpl = layui.laytpl, layer = layui.layer, formTpl = layui.formTpl

    // 常见变量
    , MOD_NAME = 'adminTpl', dom = document, _WIN = $(window), _DOM = $(dom), THIS = 'layui-this', SHOW = 'layui-show', HIDE = 'layui-hide'

    // 内部变量
    , _FORM_NAME = '.layui-form', _PAGE = '.content-page', LABEL = '.sts-label', HEADER = '.sts-header', MENU_COLUMN = '.sts-menu .sts-column', NAV_ITEM = 'layui-nav-item', NAV_ITEMED = 'layui-nav-itemed', NAV_ELEM = 'layui-nav', SPREAD_LEFT = 'layui-icon-spread-left', SPREAD_RIGHT = 'layui-icon-shrink-right', MENU = 'sts-menu', PAGE = 'content-page', TAB = '.sts-content>.content-tab'

    // 属性
    , ATTR = ['data-event', 'data-code', 'data-tpl']

    // 元素值
    , headerContent = $('.sts-content'), shade = $('.body-shade'), tab = $(TAB), content = $('.sts-content'), flexible = $('[data-event="flexible"]')

    // 其它元素字符
    , DIVI = ['.', '#', ';', ',', '|'], EVENT_TYPE = ['flexible', 'switchPage', 'rightPage', 'leftPage', 'refresh', 'page', 'insidePage', 'backPage', 'submit', 'layui.formTpl.submit', 'layui.tableTpl.deleteData', 'layui.treeTpl.deleteData', 'closePage', 'updatePassword', 'logout'], STATUS = ['success', 'notmodified', 'error', 'timeout', 'parsererror']

    // 错误页面
    , TPL_ERROR = ['<div class="layui-fluid sts-error">', '<i class="layui-icon layui-icon-face-cry"></i>', '<div class="layui-text">'
        //
        , '{{# var code=d.code||"404",message=d.message||"加载的过程中出错了呢"; }}状态：{{ code }}<br>{{ message }}'
        // 
        , '</div>', '</div>'].join('')

    // 选项卡tab
    , TPL_TAB = ['{{# var title=d.a.title||"未知"; }}'
        //
        , '<li class="layui-nav-item layui-this" data-event="switchPage(\'{{ d.a.href }}\',\'{{ title }}\')" data-code="{{ d.code }}">', '<div>'
        // 
        , '<span>{{ title }}</span>', '<i class="layui-icon layui-icon-close" data-event="closePage"></i>', '</div>', '</li>'].join('')

    // 右键菜单
    , TPL_RIGHT_MENU = ['<ul class="layui-nav layui-nav-tree">'
        // 
        , '<li class="layui-nav-item"><a>关闭标签</a></li>', '<li class="sts-division-item"></li>'
        //
        , '<li class="layui-nav-item sts-ban-item"><a>关闭其它标签</a></li>'
        // 
        , '<li class="layui-nav-item sts-ban-item"><a>关闭左边标签</a></li>'
        // 
        , '<li class="layui-nav-item sts-ban-item"><a>关闭右边标签</a></li>'
        //
        , '<li class="layui-nav-item"><a>关闭所有标签</a></li>'
        //
        , '</ul>'].join('')

    // 外部接口
    , adminTpl = {
        // 版本号
        v      : '5.0.0rc4',
        // 公共配置文件
        config : {
            // 加载页面超过时间显示加载进度条，单位：毫秒
            progresstime : 200,
            // 加载页面超时时间，单位：毫秒
            overtime     : 10000
        }
    },

    // 内部接口
    inside = {
        rightClick : false,
        // 事件
        ons        : []
    };

    // 动态调节当前显示页面的高度
    inside.showHeight = function()
    {
        var _show = $('.content-page').filter('.layui-show'), _full = _show.find('.sts-height-full');
        _full.removeAttr('style');
        if (device.weixin || device.android || device.ios || _WIN.width() < 768 || function()
        {
            var _height = _WIN.height(), _tabHeight = tab.height(), _headerHeight = $('.sts-header').height(), _showHeight = _show.height();
            return _height - (tab.is(":hidden") ? 0 : _tabHeight) - _headerHeight <= _showHeight;
        }())
        {
            _full.length > 0 && _full.css({
                height : 'auto'
            });
        }
    };

    // 初始化界面等等
    inside.init = function()
    {
        // 初始化页面code
        $(TAB + ' [' + ATTR[0] + '*=' + EVENT_TYPE[1] + '],' + MENU_COLUMN + ' [href],' + MENU_COLUMN + ' [data-href]').each(function()
        {
            var _ethis = $(this), itemConfig = common.getConfig(_ethis);

            // 如果地址为空，则放弃
            if (!itemConfig.a.href && itemConfig.events.length <= 0)
                return true;

            var _params = [itemConfig.a.href, itemConfig.a.title || ''];
            $.each(itemConfig.events, function(n, value)
            {
                var _type = value.split('(')[0];
                if (_type == EVENT_TYPE[1])
                {
                    _params = common.getParams(value);
                    return false;
                }
            });

            _ethis.attr(ATTR[1], common.hashCode(_params[0]));
        });

        _WIN.resize();
    };

    // 恢复页面或打开首页
    inside.recovery = function()
    {
        var _page, hash = (location.hash || '#').split('#')[1];

        // 左边导航>>顶部导航>>默认首页跳转
        if (hash)
            _page = $(MENU_COLUMN + ' [' + ATTR[1] + '=' + hash + ']');
        if (hash && _page.length <= 0)
            _page = $(TAB + ' [' + ATTR[1] + '=' + hash + ']');

        if ($.isEmptyObject(_page) || _page.length <= 0)
            _page = $(TAB + ' [' + ATTR[1] + ']');

        _page.eq(0).trigger("click");
    };

    // 内部执行函数
    inside.eval = function(pthis, fullFun)
    {
        var value = (fullFun || '').replace(/\n/g, ''), _type = value.split('(')[0], _params = common.getParams(value), result = true;
        // 自定义函数调用，存在才调用(考虑多层，钻取)

        // 自己就是一个函数
        if (value.indexOf("function") != -1)
            result = eval(value);
        // 已经存在已有的函数
        else if (_type && $.isFunction(window[_type]))
            // result = _params.length > 0 ? eval(value) : window[_type]();
            result = window[_type].apply(window, _params);
        // 分层钻取函数
        else if (_type)
        {
            var _funs = _type.split('.'), _funThis;
            for (var fi = 0; fi < _funs.length; fi++)
            {
                var _fun = _funs[fi], _obj = _funThis || window;
                if (_fun && _obj[_fun])
                    _funThis = _obj[_fun];
            }
            // 已经找到是函数
            if ($.isFunction(_funThis))
                result = _funThis.apply(pthis, _params);
            // result = _params.length > 0 ? eval(value) : _funThis();
        }
        return result;
    };

    // 内部刷新页面
    /**
     * 内部刷新页面
     * <p>
     * _this:元素jq对象<br>
     * _config:当前元素配置，默认：读取当前元素的配置信息<br>
     */
    inside.loadPage = function(_this, _config)
    {
        _config = $.extend(true, _config || {}, common.getConfig(_this));

        // 初始化 参数
        var isCache = function()
        {
            // 是否读取缓存,默认：true
            return typeof _config.isCache === "undefined" ? true : _config.isCache;
        }(), isInside = function()
        {
            // 是否内部跳转,默认：false
            return typeof _config.isInside === "undefined" ? false : _config.isInside;
        }(), this_elem = tab.find(DIVI[0] + NAV_ELEM), _params = function()
        {
            // 升级版兼容以前数据
            var _inParams = function()
            {
                var _value = (_config.event && _config.event.value) || _config.events[(_config.event && _config.event.index) || 0];
                // 判断是否是刷新
                if (_config.event && _config.event.value == EVENT_TYPE[4])
                {
                    $.each(_config.events, function(n, v)
                    {
                        v = $.trim(v);
                        switch (v.split('(')[0])
                        {
                            case EVENT_TYPE[1] :
                            case EVENT_TYPE[5] :
                            case EVENT_TYPE[6] :
                                _value = v;
                                break;

                            default :
                        }
                    });
                }
                return _config.params || common.getParams(_value) || []
            }();

            if (_inParams[0] && typeof(_inParams[0]) != "object")
                return {
                    url   : _inParams.length > 0 ? _inParams[0] : '',
                    title : _inParams.length > 1 ? _inParams[1] : ''
                };
            return _inParams[0];
        }(), code = (_config.code === 0 && common.hashCode(_params.url)) || _config.code;

        // 补足code
        if (_config.code === 0)
            _this.attr(ATTR[1], code);

        // 判断页面是否存在，不存在直接创建加载页面
        var codePage = content.find(DIVI[0] + PAGE + '[' + ATTR[1] + '=' + code + ']');
        content.find(DIVI[0] + PAGE).removeClass(SHOW);
        if (!isCache || codePage.length <= 0)
        {
            // 创建页面
            if (codePage.length <= 0)
                codePage = $('<div></div>').toggleClass(PAGE, true).attr(ATTR[1], code);
            codePage.toggleClass(SHOW, true);

            // 如果200毫秒没有加载完成，才显示加载进度
            var loadIndex, clearProgressIndex = setTimeout(function()
            {
                loadIndex = layer.load(1);
            }, adminTpl.config.progresstime), clearOverIndex = setTimeout(function()
            {
                // 防止卡死界面
                layer.close(loadIndex);
                codePage.empty();
                codePage.append(laytpl(TPL_ERROR).render({
                    'code'    : 'timeout(' + adminTpl.config.overtime + ')',
                    'message' : '加载 ' + _params.url + ' ，超过 ' + adminTpl.config.overtime + ' 毫秒！'
                }));
            }, adminTpl.config.overtime);

            // 判断是否是 其它的外部页面
            if (_params.url.indexOf('http') > -1)
            {
                var iframe = $('<iframe src="' + _params.url + '" frameborder="0" class="sts-iframe"></iframe>');
                codePage.empty();
                codePage.append(iframe);
                content.find('.content-tab').after(codePage);
                // 监听状态
                iframe.load(function()
                {
                    layer.close(loadIndex);
                    clearInterval(clearProgressIndex);
                    clearInterval(clearOverIndex);
                });
            } else
            {
                // 异步添加
                content.find('.content-tab').after(codePage.load(_params.url, function(response, status, xhr)
                {
                    layer.close(loadIndex);
                    clearInterval(clearProgressIndex);
                    clearInterval(clearOverIndex);
                    // 判断页面情况
                    // STATUS=['success', 'notmodified', 'error', 'timeout','parsererror']
                    switch (status)
                    {
                        // 成功
                        case STATUS[0] :
                            // 内页跳转，是否有返回 需要处理，是否隐藏
                            if (isInside)
                                codePage.find('[' + ATTR[0] + '*="' + EVENT_TYPE[7] + '"]').attr(ATTR[1], (location.hash || '#').split('#')[1]);
                            break;

                        case STATUS[1] :
                        case STATUS[2] :
                        case STATUS[3] :
                        case STATUS[4] :
                            codePage.empty();
                            codePage.append(laytpl(TPL_ERROR).render({
                                'code'    : status + '(' + xhr.status + ')',
                                'message' : '加载 ' + _params.url + ' ，加载到现在还是错误了！' + xhr.responseText
                            }));
                            break;

                        default :
                    }

                    // 更新表单初始化
                    formTpl.init({
                        code : code
                    });

                    adminTpl.render({
                        config : _config,
                        params : _params
                    });
                }));
            }
        } else
        {
            codePage.toggleClass(SHOW, true);

            // 更新表单初始化
            formTpl.init({
                code : code
            });

            adminTpl.render({
                config : _config,
                params : _params
            });
        }

        if (!isInside)
        {
            // 页面地址路由，内部页面跳转不需要路由
            location.hash = code;

            // 点击效果
            this_elem.find(DIVI[0] + THIS).removeClass(THIS);
            this_elem.find('[' + ATTR[1] + '=' + code + ']').addClass(THIS);

            // 切换导航栏目
            var menu_column = $(MENU_COLUMN), thisItem = menu_column.find('[' + ATTR[1] + '=' + code + ']');

            // 删除当前效果
            // menu_column.find(DIVI[0] + NAV_ITEMED).removeClass(NAV_ITEMED);
            menu_column.find(DIVI[0] + THIS).removeClass(THIS);

            // 添加当前效果
            thisItem.closest(DIVI[0] + NAV_ITEM).toggleClass(NAV_ITEMED, true);
            // 2层目录
            thisItem.closest('dl').closest('dd').toggleClass(NAV_ITEMED, true);
            thisItem.closest('dd').toggleClass(THIS, true);
        }
    };

    // 当浏览器大小变化时
    _WIN.resize(function(isExe)
    {
        // 关闭右键菜单
        if (inside.rightClick)
        {
            inside.rightClick = false;
            layer.closeAll('page');
        }

        $(DIVI[0] + MENU).removeAttr('style');
        headerContent.removeAttr('style');

        flexible.removeClass(SPREAD_LEFT + ' ' + SPREAD_RIGHT);
        if (_WIN.width() > 768)
        {
            shade.hide();
            flexible.addClass(SPREAD_RIGHT);
        } else
            flexible.addClass(SPREAD_LEFT);
    });

    // 监听导航(a)点击事件-处理
    _DOM.on('click', MENU_COLUMN + ' [href],' + MENU_COLUMN + ' [data-href]', function(e)
    {
        var _this = $(this), _config = common.getConfig(_this);

        // 判断打开方式，如果是新开页面，直接放过
        if (_config.a.target && _config.a.target == '_blank')
            return true;

        // 判断页面是否存在当前tab，存在直接点击即可，不存在新增tab
        var item = tab.find(DIVI[0] + NAV_ITEM + '[' + ATTR[1] + '=' + _config.code + ']');
        if (item.length > 0)
            item.eq(0).trigger("click");
        else
        {
            // 生成新的
            item = $(laytpl(TPL_TAB).render(_config));

            // 添加进入并点击
            tab.find(DIVI[0] + NAV_ELEM).append(item);
            item.trigger("click");
        }
        return false;
    });

    // 导航栏目右键菜单
    _DOM.on("contextmenu", '.content-tab .' + NAV_ITEM, function()
    {
        return false;
    });
    _DOM.on('mousedown', 'body', function(e)
    {
        // 点击去除本身元素以外的单击
        if (inside.rightClick && 1 == e.which)
        {
            inside.rightClick = false;
            layer.closeAll('page');
        }
    });
    _DOM.on('mousedown', '.content-tab .' + NAV_ITEM, function(e)
    {
        if (3 == e.which)
        {
            inside.rightClick = false;
            layer.closeAll('page');
            layer.open({
                type     : 1,
                shade    : 0,
                title    : false,
                closeBtn : 0,
                resize   : false,
                offset   : [e.pageY, function()
                    {
                        var _x = e.pageX, _w = _WIN.width();
                        if (_x + 120 <= _w)
                            return _x;
                        else if (_x - 120 > 0)
                            return _x - 120;
                        else
                            return (_w - 118) / 2;
                    }()],
                skin     : 'sts-right-menu',
                content  : TPL_RIGHT_MENU,
                success  : function(layero, index)
                {
                    inside.rightClick = true;
                    var target = $(e.target), BAN = 'sts-ban-item', _item = target.closest(DIVI[0] + NAV_ITEM), _banItem = layero.find(DIVI[0] + BAN);

                    // 关闭其它标签
                    if (_item.siblings('li').length > 0)
                        _banItem.eq(0).removeClass(BAN);
                    else
                        _banItem.eq(0).remove();
                    // 关闭左边标签
                    if (_item.prevAll('li').length > 0)
                        _banItem.eq(1).removeClass(BAN);
                    else
                        _banItem.eq(1).remove();
                    // 关闭右边标签
                    if (_item.nextAll('li').length > 0)
                        _banItem.eq(2).removeClass(BAN);
                    else
                        _banItem.eq(2).remove();

                    // 监听事件
                    layero.find('a').click(function()
                    {
                        var _text = $(this).text();
                        switch (_text)
                        {
                            case '关闭标签' :
                                _item.find('i').click();
                                break;
                            case '关闭其它标签' :
                                _item.siblings('li').find('i').click();
                                break;
                            case '关闭左边标签' :
                                _item.prevAll('li').find('i').click();
                                break;
                            case '关闭右边标签' :
                                _item.nextAll('li').find('i').click();
                                break;
                            case '关闭所有标签' :
                                _item.siblings('li').find('i').click();
                                _item.find('i').click();
                                break;
                            default :
                        }
                    });
                }
            });
        }
    });

    // 监听点击事件-处理(先解除底层框架默认事件)
    $(DIVI[0] + NAV_ITEM + '[' + ATTR[0] + ']').off('click');
    _DOM.on('click kylinEventClick', '[' + ATTR[0] + ']', function kylinEventClick(event, eventIndex)
    {
        var pthis = this, _this = $(pthis), _config = common.getConfig(_this), stop = true, _eventIndex = eventIndex || -1;

        $.each(_config.events, function(n, _value)
        {
            // 执行过的事件
            if (n <= _eventIndex)
                return true;

            var value = $.trim(_value), _type = value.split('(')[0], _params = common.getParams(value), _event = {
                index : n,
                value : value
            };
            switch (_type)
            {

                // 侧边伸缩
                case EVENT_TYPE[0] :
                    // 判断当前是上面状态SPREAD_RIGHT:.layui-icon-shrink-right SPREAD_LEFT:.layui-icon-spread-left .sts-menu

                    var isRight = flexible.hasClass(SPREAD_RIGHT), menu = $(DIVI[0] + MENU);
                    flexible.removeClass(SPREAD_LEFT + ' ' + SPREAD_RIGHT);

                    // 切换状态
                    if (isRight)
                    {
                        flexible.addClass(SPREAD_LEFT);

                        menu.attr('style', 'transform:translate3d(-220px,0,0);-webkit-transform: translate3d(-220px,0,0);');
                        headerContent.css({
                            'left'  : '0px',
                            'width' : '+=220px'
                        });
                        if (_WIN.width() <= 768)
                            shade.hide();
                    } else
                    {
                        flexible.addClass(SPREAD_RIGHT);

                        menu.attr('style', 'transform:translate3d(0px,0,0);-webkit-transform: translate3d(0px,0,0);');
                        headerContent.css({
                            'left'  : '220px',
                            'width' : '-=220px'
                        }).filter('.layout-left').css({
                            'width' : ''
                        });
                        if (_WIN.width() <= 768)
                            shade.show();
                    }
                    break;

                // 页面切换
                case EVENT_TYPE[1] :
                    inside.loadPage(_this, $.extend(true, {
                            event : _event
                        }, _config));
                    break;

                // 下/右一页
                case EVENT_TYPE[2] :
                    var _nav = _this.prev(DIVI[0] + NAV_ELEM), _item = _nav.find(DIVI[0] + NAV_ITEM), _biasLeft = 0, _last = false, _end = ($(DIVI[0] + SPREAD_LEFT).is(":hidden") ? 260 : 40) + tab.width();

                    _item.each(function(_l)
                    {
                        var _e_this = $(this), _e_width = _e_this.width(), _e_left = _e_this.offset().left, _e_end = _e_left + _e_width;
                        if (_e_end <= _end)
                        {
                            _last = _l == _item.length - 1;
                            _biasLeft -= _e_width;
                        } else
                            // 不满足直接终止
                            return false;
                    });

                    // 没有后面页面了，停止移动效果
                    if (!_last)
                        _nav.animate({
                            "left" : _biasLeft + "px"
                        });
                    break;

                // 上/左一页
                case EVENT_TYPE[3] :
                    var _nav = _this.next(DIVI[0] + NAV_ELEM), _item = _nav.find(DIVI[0] + NAV_ITEM), _biasLeft = 0, _navLeft = _nav.offset().left, _start = _navLeft - 40 + tab.width();

                    // 倒序
                    for (var _it = _item.length - 1; _it > 0; _it--)
                    {
                        var _e_this = _item.eq(_it), _e_start = _e_this.offset().left

                        if (_e_start <= _start)
                            _biasLeft += _e_this.width();
                    }

                    var _animateLeft = {
                        left : '+=' + _biasLeft + 'px'
                    };
                    // 第一个，停止移动效果
                    if ((_navLeft + _biasLeft) > 0)
                        _animateLeft.left = '0px';
                    _nav.animate(_animateLeft);
                    break;

                // 刷新页面
                case EVENT_TYPE[4] :
                    var refreshThis = content.find(DIVI[0] + PAGE).filter(DIVI[0] + SHOW).eq(0);
                    // 查找当前页面卡片里面的数据，如果没有找到直接跳过
                    if (refreshThis.length <= 0)
                        break;

                    // 查找栏目上面的
                    var _refreshConfig = common.getConfig(refreshThis), isInside = false;
                    refreshThis = $('[' + ATTR[0] + '*="' + EVENT_TYPE[1] + '"][' + ATTR[1] + '="' + _refreshConfig.code + '"]');

                    // 查找内容页面
                    if (refreshThis.length <= 0)
                    {
                        isInside = true;
                        refreshThis = $('[' + ATTR[1] + '="' + _refreshConfig.code + '"]').filter('[' + ATTR[0] + '*="' + EVENT_TYPE[5] + '"],[' + ATTR[0] + '*="' + EVENT_TYPE[6] + '"]');
                    }

                    // 默认刷新首页信息，如果没有找到直接跳过
                    if (refreshThis.length <= 0)
                        break;

                    inside.loadPage(refreshThis, $.extend(true, {
                            isCache  : false,
                            isInside : isInside,
                            event    : _event
                        }, _config));
                    break;

                // 内页跳转页面
                case EVENT_TYPE[5] :
                case EVENT_TYPE[6] :
                    inside.loadPage(_this, $.extend(true, {
                            isInside : true,
                            event    : _event
                        }, _config));
                    break;

                // 内页返回页面
                case EVENT_TYPE[7] :
                    inside.loadPage(_this, $.extend(true, {
                            event : _event
                        }, _config));
                    break;

                // 表单提交 submit,layui.formTpl.submit
                case EVENT_TYPE[8] :
                case EVENT_TYPE[9] :
                    formTpl.submit.apply(pthis, [$.extend(true, {
                            _jqThis : _this,
                            event   : _event
                        }, _params[0])]);
                    return stop = false;

                    // 表格删除 layui.tableTpl.deleteData
                case EVENT_TYPE[10] :
                    if (layui.tableTpl)
                    {
                        layui.tableTpl.deleteData.apply(pthis, [$.extend(true, {
                            _jqThis : _this,
                            event   : _event
                        }, _params[0])]);
                        return stop = false;
                    }

                    // 树形删除 layui.treeTpl.deleteData
                case EVENT_TYPE[11] :
                    if (layui.treeTpl)
                    {
                        layui.treeTpl.deleteData.apply(pthis, [$.extend(true, {
                            _jqThis : _this,
                            event   : _event
                        }, _params[0])]);
                        return stop = false;
                    }

                    // 关闭页面
                case EVENT_TYPE[12] :
                    // 删除tab
                    var _thisNavItem = _this.closest(DIVI[0] + NAV_ITEM), _thisNavItemConfig = common.getConfig(_thisNavItem);
                    // 删除缓存内容
                    if (_thisNavItemConfig.code != 0)
                        content.find(DIVI[0] + PAGE + '[' + ATTR[1] + '="' + _thisNavItemConfig.code + '"]').remove();

                    // 是否隐藏tab栏目，如果只有一个了，切换到首页并隐藏
                    var _nav_item = _thisNavItem.siblings(DIVI[0] + NAV_ITEM), _index_item = _thisNavItem.index() - 2;
                    _thisNavItem.remove();
                    if (_nav_item.length <= 0)
                    {
                        $(TAB + ' [' + ATTR[0] + '*=' + EVENT_TYPE[1] + ']').trigger("click");
                    } else if (!_nav_item.is('.' + THIS))
                    {
                        // 切换到他的附近页面
                        _nav_item.eq(_index_item <= 0 ? 0 : _index_item).trigger("click");
                    }

                    return stop = false;

                    // 修改密码
                case EVENT_TYPE[13] :
                    var _upConfig = _params[0] || {};
                    layer.open($.extend(true, {
                        type       : 1,
                        title      : '修改密码',
                        shade      : 0.01,
                        skin       : 'sts-open layui-card',
                        area       : function()
                        {
                            // 自动调节宽度
                            var _wWidth = $(window).width();
                            if (_wWidth > 460)
                                _wWidth = 460;
                            else
                                _wWidth -= 40;
                            return _wWidth + 'px';
                        }(),
                        btn        : false,
                        shadeClose : true,
                        success    : function(layero, index)
                        {
                            var _oldH = layero.height(), _oldW = layero.width(), _url = _upConfig.url || common.config.urls.updatePassword, _content = layero.find('.layui-layer-content');
                            _content.load(_url, {}, function(response, status, xhr)
                            {
                                // 采用异步加载后居中
                                if (status == 'success')
                                    layero.css({
                                        'top'  : '-=' + (1 + (layero.height() - _oldH) / 2) + 'px',
                                        'left' : '-=' + (1 + (layero.width() - _oldW) / 2) + 'px'
                                    });
                                else
                                    _content.html('加载 ' + _url + '页面失败， 状态：' + status + '(' + xhr.status + ')');
                            });
                        },
                        content    : ''
                    }, _upConfig));
                    break;

                // 退出登录
                case EVENT_TYPE[14] :
                    var _upConfig = _params[0] || {};
                    // 发送退出请求
                    common.sendAjax('logout', {}, function(json)
                    {
                        if (json.code == 0)
                            window.location.href = _upConfig.url || common.config.urls.login;
                        else
                            // 强行退出
                            common.sendAjax('q!logout', {}, function(json)
                            {
                                window.location.href = _upConfig.url || common.config.urls.login;
                            });
                    }, function()
                    {
                        layer.msg('退出登录失败！', {
                            skin : 'sts-msg-warn'
                        });
                    });
                    break;

                default :
                    var result = inside.eval(pthis, value);
                    if (typeof result == "boolean")
                        return stop = result;
            }

            // 处理其它的事件
            for (var o = 0; o < inside.ons.length; o++)
            {
                var on = inside.ons[o];
                on.event == _type && on.aop == 'after' && on.fun();
            }
        });
        return stop;
    });

    // 内部初始化页面
    inside.init();

    // 恢复页面或打开首页
    inside.recovery();

    // 刷新页面
    adminTpl.render = function(objConfig)
    {
        // 所有对象配置
        var kylinConfig = function()
        {
            // 扩展框架属性
            return $.extend(true, {
                sts : objConfig || {}
            }, layui);
        }();

        // 模板更新
        $('[' + ATTR[2] + ']').each(function()
        {
            var _ethis = $(this);

            // 判断当前是否显示，不显示，不初始化
            if ((_ethis.closest(_PAGE).length > 0 && !_ethis.closest(_PAGE).is("." + SHOW)) || !_ethis.is(":visible"))
                return true;

            var itemConfig = common.getConfig(_ethis);
            if (itemConfig.laytpl)
            {
                var result = laytpl(itemConfig.laytpl.replace(/data-ignore=""|ignore=""/g, ' ')).render(kylinConfig) || '', tagName = _ethis[0].tagName.toLowerCase();
                switch (tagName)
                {
                    case 'input' :
                    case 'select' :
                    case 'textarea' :
                        _ethis.val(result);
                        break;

                    default :
                        _ethis.html(result);
                }
            }
        });

        // 更新表单数据
        formTpl.render(kylinConfig);

        // 辅助显示ui
        $(LABEL).each(function()
        {
            var _ethis = $(this);

            // 判断当前是否显示，不显示，不初始化
            if (!_ethis.closest(_PAGE).is("." + SHOW))
                return true;

            var title = _ethis.attr('title');
            title || _ethis.attr('title', $.trim(_ethis.text() || ''));
        });

        // inside.showHeight();
    };

    // 事件添加
    adminTpl.on = function(eventType, aopType, fun)
    {
        var temp = {
            event : eventType,
            aop   : aopType,
            fun   : fun
        }, isOk = true;

        for (var o = 0; o < inside.ons.length; o++)
        {
            var on = inside.ons[o];
            if (on.event == temp.event && on.aop == temp.aop)
            {
                isOk = false;
                break;
            }
        }

        isOk && inside.ons.push(temp);
    };

    exports(MOD_NAME, adminTpl);
});
