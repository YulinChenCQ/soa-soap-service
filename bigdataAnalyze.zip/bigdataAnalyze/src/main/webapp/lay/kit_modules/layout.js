/** kitadmin-v2.1.0 MIT License By http://kit.zhengjinfan.cn Author Van Zheng */
;"use strict";layui.define(function(i){i("layout",{})});
//# sourceMappingURL=layout.js.map
