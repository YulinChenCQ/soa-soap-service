// 通用黨法
/**
 * getBeforeDate(n) 0当前日期 3 前3天
 */
var data_date = getBeforeDate(1);
var data_date1 = getBeforeDate(0);
var data_parallelAxis = ['差', '良', '优'];

var h = window.innerHeight;
var height = h / 2 - 10;
/** *获取日期 年-月-日*********** */
function getBeforeDate(n) {
	var n = n;
	var d = new Date();
	var year = d.getFullYear();
	var mon = d.getMonth() + 1;
	var day = d.getDate();
	if (day <= n) {
		if (mon > 1) {
			mon = mon - 1;
		} else {
			year = year - 1;
			mon = 12;
		}
	}
	d.setDate(d.getDate() - n);
	year = d.getFullYear();
	mon = d.getMonth() + 1;
	day = d.getDate();
	s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-"
			+ (day < 10 ? ('0' + day) : day);
	return s;
}

function check_out_sum(grade) {
	var dataCountWeightValue = parseFloat(grade.dataCountWeightValue == ""
			? '0'
			: grade.dataCountWeightValue);
	var averageTimeWeightValue = parseFloat(grade.averageTimeWeightValue == ""
			? '0'
			: grade.averageTimeWeightValue);
	var rfidCountWeightValue = parseFloat(grade.rfidCountWeightValue == ""
			? '0'
			: grade.rfidCountWeightValue);
	var keyStepWeightValue = parseFloat(grade.keyStepWeightValue == ""
			? '0'
			: grade.keyStepWeightValue);
	var problemCountWeightValue = parseFloat(grade.problemCountWeightValue == ""
			? '0'
			: grade.problemCountWeightValue);
	var stepCountWeightValue = parseFloat(grade.stepCountWeightValue == ""
			? '0'
			: grade.stepCountWeightValue);
	var pictureCountWeightValue = parseFloat(grade.pictureCountWeightValue == ""
			? '0'
			: grade.pictureCountWeightValue);
	var descCountWeightValue = parseFloat(grade.descCountWeightValue == ""
			? '0'
			: grade.descCountWeightValue);
			
			
	console.log(dataCountWeightValue);
	console.log(averageTimeWeightValue);
	console.log(rfidCountWeightValue);
	console.log(keyStepWeightValue);
	console.log(problemCountWeightValue);
	console.log(stepCountWeightValue);
	console.log(pictureCountWeightValue);
	console.log(descCountWeightValue);
	weight_value = dataCountWeightValue * 1000 + averageTimeWeightValue * 1000
			+ rfidCountWeightValue * 1000 + keyStepWeightValue * 1000
			+ problemCountWeightValue * 1000 + stepCountWeightValue * 1000
			+ pictureCountWeightValue * 1000 + descCountWeightValue * 1000;
	return weight_value / 1000;

}
