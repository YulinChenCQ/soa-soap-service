package com.soa.bigdataAnalyze.entity;

import java.io.Serializable;

public class BiStepInfo  implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -8809292883913205484L;

	private String id;//ID	

    private String taskId;//����ID

    private String stepName;//��������

    private String stepDetail;//������ϸ����

    private String executionTime;//����ʱ��

    private String standbyOne;//����1

    private String standbyTwo;//����2

    private String standbyThree;//����3

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId == null ? null : taskId.trim();
    }

    public String getStepName() {
        return stepName;
    }

    public void setStepName(String stepName) {
        this.stepName = stepName == null ? null : stepName.trim();
    }

    public String getStepDetail() {
        return stepDetail;
    }

    public void setStepDetail(String stepDetail) {
        this.stepDetail = stepDetail == null ? null : stepDetail.trim();
    }

    public String getExecutionTime() {
        return executionTime;
    }

    public void setExecutionTime(String executionTime) {
        this.executionTime = executionTime == null ? null : executionTime.trim();
    }

    public String getStandbyOne() {
        return standbyOne;
    }

    public void setStandbyOne(String standbyOne) {
        this.standbyOne = standbyOne == null ? null : standbyOne.trim();
    }

    public String getStandbyTwo() {
        return standbyTwo;
    }

    public void setStandbyTwo(String standbyTwo) {
        this.standbyTwo = standbyTwo == null ? null : standbyTwo.trim();
    }

    public String getStandbyThree() {
        return standbyThree;
    }

    public void setStandbyThree(String standbyThree) {
        this.standbyThree = standbyThree == null ? null : standbyThree.trim();
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BiStepInfo [id=" + id + ", taskId=" + taskId + ", stepName=" + stepName + ", stepDetail=" + stepDetail
				+ ", executionTime=" + executionTime + ", standbyOne=" + standbyOne + ", standbyTwo=" + standbyTwo
				+ ", standbyThree=" + standbyThree + "]";
	}
}