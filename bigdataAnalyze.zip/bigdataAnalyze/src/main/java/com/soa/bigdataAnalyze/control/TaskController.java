
/**
 * <一句话功能描述>
 * <p>处理巡检任务大数据分析相关请求
 * @author 陈宇林
 * @version [版本号, 2018年9月7日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

package com.soa.bigdataAnalyze.control;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.soa.bigdataAnalyze.entity.InspectionTaskRecord;
import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.service.TaskService;

@Controller
@RequestMapping("/task")
public class TaskController {

	@Autowired
	private TaskService taskService;

	/**
	 * 获取单井站的数据
	 * 
	 * @param beginDate
	 * @param endDate
	 * @param welId
	 * @return
	 */
	@RequestMapping(value = "/getSingleWelTaskInfo", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	@ResponseBody
	public String getInspectionTaskInfo(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate, @RequestParam("welId") String welId,
			@RequestParam("taskType") String taskType) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, taskType, welId);

		//long time1 = System.currentTimeMillis();
		JSONObject returnJo = taskService.getSingleWelTaskInfo(condition,true);
		//long time2 = System.currentTimeMillis();
		//System.out.println("请求花费时间：" + ((time2 - time1) / 1000));

		return returnJo.toString();

	}

	/**
	 * 获取多井站的数据
	 * 
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value = "/getMultipleWelTaskInfo", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	@ResponseBody
	public String getMultipleWelTaskInfo(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate ,@RequestParam("taskType") String taskType) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, taskType, null);

		JSONObject returnJo = taskService.getMultipleWelTaskInfo(condition,true);
		return returnJo.toString();

	}

}
