package com.soa.bigdataAnalyze.mapper;

import com.soa.bigdataAnalyze.entity.BiEquipmentRecord;
import com.soa.bigdataAnalyze.entity.BiEquipmentRecordExample;
import com.soa.bigdataAnalyze.entity.QueryCondition;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface BiEquipmentRecordMapper {
    long countByExample(BiEquipmentRecordExample example);

    int deleteByExample(BiEquipmentRecordExample example);

    int deleteByPrimaryKey(String id);

    int insert(BiEquipmentRecord record);

    int insertSelective(BiEquipmentRecord record);

    List<BiEquipmentRecord> selectByExample(BiEquipmentRecordExample example);

    BiEquipmentRecord selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") BiEquipmentRecord record, @Param("example") BiEquipmentRecordExample example);

    int updateByExample(@Param("record") BiEquipmentRecord record, @Param("example") BiEquipmentRecordExample example);

    int updateByPrimaryKeySelective(BiEquipmentRecord record);

    int updateByPrimaryKey(BiEquipmentRecord record);
    
    /**
     * 获取设备记录信息（按逐个设备统计）
     * @param ifVerify
     * @return
     */
    List<Map<String, String>> findRecordInfoByDevice(QueryCondition condition);
    
    /**
     * 获取设备记录信息（按设备大类统计）
     * @param condition
     * @return
     */
    List<Map<String,String>> findRecordInfoByClass(QueryCondition condition);
    
    /**
     * 获取设备记录信息（按设备小类统计）
     * @param condition
     * @return
     */
    List<Map<String,String>> findRecordInfoBySubclass(QueryCondition condition);
    
    /**
     * 获取多井站的记录信息（按设备大类统计）
     * @param condition
     * @return
     */
    List<Map<String,String>> findRecordInofOfWelsByClass(QueryCondition condition);
    
    /**
     * 获取多井站的记录信息（按设备小类统计）
     * @param condition
     * @return
     */
    List<Map<String,String>> findRecordInfOfWelsBySubclass(QueryCondition condition);
    
    
    /**
     * 按设备大类分组，查询设备数量、异常数量、完好率信息
     * @param condition
     * @return
     */
    List<Map<String,String>> findEquipSituation(QueryCondition condition);
    
    /**
     * 根据设备大类分组，查询各个井站的设备数量、异常设备数量、完好率信息
     * @param condition
     * @return
     */
    List<Map<String,String>> findEquipSituationOfWels(QueryCondition condition);
    
    /**
     * 查询设备的大类
     * @return
     */
    List<String> findClassOfEquip();
    
    /**
     * 获取设备表的井站和井站名称
     * @return
     */
    List<Map<String,String>> findWelInfo();
    
    
    /**
     *根据设备大类统计,获取各个大类设备数量
     * @return
     */
    List<Map<String,String>> findCountOfEquClass(QueryCondition condition);
    
    /**
     * 根据井站统计设备数量
     * @param condition
     * @return
     */
    List<Map<String,String>> findCountOfWel(QueryCondition condition);
   
    /**
     * 查询设备的详细信息
     * @param condition
     * @return
     */
    List<Map<String,String>> findEquipmentInfo(QueryCondition condition);
    
    /**
     * 按井站统计设备总数、异常设备数量、设备完好率
     * @return
     */
    List<Map<String,String>> findEquSituationOfWel(QueryCondition condition);
    /**
     * 按设备小类设备总数、异常设备数量、设备完好率
     * @return
     */
    List<Map<String,String>> findEquSituationOfSubclass(QueryCondition condition);

	/**
	 * 
	 * 根据设备小类统计设备数量
	 * @param condition
	 * @return
	 */
	List<Map<String, String>> findCountOfSubclass(QueryCondition condition);
    
}