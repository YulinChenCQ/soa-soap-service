
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年9月7日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.entity;


import org.json.JSONObject;

public class InspectionTaskRecord {
	
	private JSONObject inspectionTaskRecords;//巡检任务记录
	
	private JSONObject taskChart;//任务分析图数据
	
	private JSONObject stepChart;//步骤分析图数据

	/**
	 * @return the inspectionTaskRecords
	 */
	public JSONObject getInspectionTaskRecords() {
		return inspectionTaskRecords;
	}

	/**
	 * @return the taskChart
	 */
	public JSONObject getTaskChart() {
		return taskChart;
	}

	/**
	 * @return the stepChart
	 */
	public JSONObject getStepChart() {
		return stepChart;
	}

	/**
	 * @param inspectionTaskRecords the inspectionTaskRecords to set
	 */
	public void setInspectionTaskRecords(JSONObject inspectionTaskRecords) {
		this.inspectionTaskRecords = inspectionTaskRecords;
	}

	/**
	 * @param taskChart the taskChart to set
	 */
	public void setTaskChart(JSONObject taskChart) {
		this.taskChart = taskChart;
	}

	/**
	 * @param stepChart the stepChart to set
	 */
	public void setStepChart(JSONObject stepChart) {
		this.stepChart = stepChart;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InspectionTaskRecord [inspectionTaskRecords=" + inspectionTaskRecords + ", taskChart=" + taskChart
				+ ", stepChart=" + stepChart + "]";
	}

	
	

}
