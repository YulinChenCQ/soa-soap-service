package com.soa.bigdataAnalyze.entity;

import java.util.List;

import org.springframework.stereotype.Component;

/**
 * 查询条件
 * @author Administrator
 *
 */
@Component
public class QueryCondition {
	
	private String beginDate;//开始时间
	private String endDate;//结束时间
	private String taskType;//任务类型
	private String welId;//井站id
	private boolean flag;//是否查询步骤信息标志
	private String statisticsType;//统计类型
	
	private String ifVerify;//是否是需要校验设备
	
	private List<String> welIds;//多个井站id
	
	private List<String> equClasses;//多个设备大类
	
	public QueryCondition() {
		super();
	}
	
	public QueryCondition(String beginDate, String endDate, String taskType, String welId) {
		super();
		this.beginDate = beginDate;
		this.endDate = endDate;
		this.taskType = taskType;
		this.welId = welId;
	}
	



	/**
	 * @param welIds
	 * @param equClasses
	 */
	public QueryCondition(List<String> welIds, List<String> equClasses) {
		super();
		this.welIds = welIds;
		this.equClasses = equClasses;
	}

	/**
	 * @return the equClasses
	 */
	public List<String> getEquClasses() {
		return equClasses;
	}

	/**
	 * @param equClasses the equClasses to set
	 */
	public void setEquClasses(List<String> equClasses) {
		this.equClasses = equClasses;
	}

	/**
	 * @return the beginDate
	 */
	public String getBeginDate() {
		return beginDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @return the taskType
	 */
	public String getTaskType() {
		return taskType;
	}

	/**
	 * @return the welId
	 */
	public String getWelId() {
		return welId;
	}

	/**
	 * @return the flag
	 */
	public boolean isFlag() {
		return flag;
	}

	/**
	 * @return the statisticsType
	 */
	public String getStatisticsType() {
		return statisticsType;
	}

	/**
	 * @return the ifVerify
	 */
	public String getIfVerify() {
		return ifVerify;
	}

	/**
	 * @param beginDate the beginDate to set
	 */
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @param taskType the taskType to set
	 */
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	/**
	 * @param welId the welId to set
	 */
	public void setWelId(String welId) {
		this.welId = welId;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	/**
	 * @param statisticsType the statisticsType to set
	 */
	public void setStatisticsType(String statisticsType) {
		this.statisticsType = statisticsType;
	}

	/**
	 * @param ifVerify the ifVerify to set
	 */
	public void setIfVerify(String ifVerify) {
		this.ifVerify = ifVerify;
	}

	/**
	 * @return the welIds
	 */
	public List<String> getWelIds() {
		return welIds;
	}

	/**
	 * @param welIds the welIds to set
	 */
	public void setWelIds(List<String> welIds) {
		this.welIds = welIds;
	}
	

}
