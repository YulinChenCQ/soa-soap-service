
/**
 * <一句话功能描述>
 * <p>设备运维大数据分析数据接口
 * @author 陈宇林
 * @version [版本号, 2018年9月30日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.control;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.service.EquipmentAnalyzeService;
import com.soa.bigdataAnalyze.util.TransformUtil;

@RestController
@RequestMapping("equipmentAnalyze")
public class EquipmentAnalyzeController {

	@Autowired
	private EquipmentAnalyzeService equipmentAnalyzeService;

	/**
	 * 获取设备记录信息（按逐个设备统计）
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param ifVerify
	 *            是否是需要校验设备 :1->需要校验;2->不需要校验
	 * @param welId
	 *            井站id
	 * @return json格式，例如： {"data":[{"name":"电动执行机构,ee0138d4","value":[2,2,1,2]},
	 *         ue":[2,1,4,5]},{"name":"测温套,1e393cd4","value":[3,1,1,3]}]}
	 */
	@RequestMapping(value = "/getRecordInfoByDevice", method = RequestMethod.POST, produces = "text/plain;charset=utf-8;")
	public String getRecordInfoByDevice(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate, @RequestParam("ifVerify") String ifVerify,
			@RequestParam("welId") String welId) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welId);
		condition.setIfVerify(ifVerify);
		return equipmentAnalyzeService.getRecordInfoByDevice(condition).toString();
	}

	/**
	 * 获取设备记录信息（按设备大类统计）
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param ifVerify（可以为空）
	 *            是否是需要校验设备 :1->需要校验;2->不需要校验
	 * @param welId
	 *            井站id
	 * @return json格式，例如： { "indicator": [ { "max": 332, "text": "操作记录" }, { "max":
	 *         175, "text": "（异常）隐患记录" }, { "max": 291, "text": "维护保养记录" }, { "max":
	 *         306, "text": "检维修记录" }, { "max": 303, "text": "校验记录" }, { "max": 100,
	 *         "text": "故障率" } ], "data": [ { "name": "工艺设备", "value": [ 237, 130,
	 *         234, 236, 264, 74 ] }, { "name": "通信设备", "value": [ 36, 25, 42, 35,
	 *         35, 65 ] }, { "name": "辅助设备", "value": [ 7, 4, 7, 7, 7, 75 ] }, {
	 *         "name": "机泵设备", "value": [ 14, 8, 12, 13, 14, 67 ] }, { "name":
	 *         "电气设备", "value": [ 5, 6, 6, 7, 8, 63 ] }, { "name": "仪表设备", "value":
	 *         [ 332, 175, 291, 306, 303, 71 ] }, { "name": "其它", "value": [ 49, 24,
	 *         44, 53, 52, 75 ] } ], "legendData": [ "工艺设备", "通信设备", "辅助设备", "机泵设备",
	 *         "电气设备", "仪表设备", "其它" ] }
	 */
	@RequestMapping(value = "/getRecordInfoByClass", method = RequestMethod.POST, produces = "text/plain;charset=utf-8;")
	public String getRecordInfoByClass(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate, String ifVerify, @RequestParam("welId") String welId) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welId);
		condition.setIfVerify(ifVerify);
		return equipmentAnalyzeService.getRecordInfoByClass(condition).toString();
	}

	/**
	 * 获取设备记录信息（按设备小类统计）
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param ifVerify
	 *            是否是需要校验设备 :1->需要校验;2->不需要校验
	 * @param welId
	 *            井站id
	 * @return
	 */
	@RequestMapping(value = "/getRecordInfoBySubclass", method = RequestMethod.POST, produces = "text/plain;charset=utf-8;")
	public String getRecordInfoBySubclass(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate, @RequestParam("ifVerify") String ifVerify,
			@RequestParam("welId") String welId) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welId);
		condition.setIfVerify(ifVerify);
		return equipmentAnalyzeService.getRecordInfoBySubclass(condition).toString();
	}

	/**
	 * 获取多井站设备记录信息(按设备大类统计)
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param ifVerify
	 *            是否是需要校验设备 :1->需要校验;2->不需要校验
	 * @param welIds
	 *            多个井站id
	 * @return
	 */
	@RequestMapping(value = "/getRecordInfoOfWelsByClass", method = RequestMethod.POST, produces = "text/plain;charset=utf-8;")
	public String getRecordInfoOfWelsByClass(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate,String ifVerify,
			String welIds) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		condition.setWelIds(TransformUtil.strToList(welIds));
		condition.setIfVerify(ifVerify);
		return equipmentAnalyzeService.getRecordInfoOfWelsByClass(condition).toString();
	}

	/**
	 * 获取多井站设备记录信息（按设备小类统计）
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param ifVerify
	 *            是否是需要校验设备 :1->需要校验;2->不需要校验
	 * @param welIds
	 *            多个井站id
	 * @return
	 */
	@RequestMapping(value = "/getRecordInfoOfWelsBySubclass", method = RequestMethod.POST, produces = "text/plain;charset=utf-8;")
	public String getRecordInfoOfWelsBySubclass(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate, @RequestParam("ifVerify") String ifVerify,
			String welIds) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		condition.setWelIds(TransformUtil.strToList(welIds));
		condition.setIfVerify(ifVerify);
		return equipmentAnalyzeService.getRecordInfoOfWelsBySubclass(condition).toString();
	}

	/**
	 * 根据设备大类分组，获取设备数量、异常设备数量，设备的完好率
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return json 格式，例如：
	 *         {"tHead":["工艺设备","机泵设备","通信设备","辅助设备","电气设备","仪表设备","其它"],
	 *         "exceptionNumData": [12,1,1,0,0,8,2],
	 *         "numData":[2843,113,230,90,70,3717,688],
	 *         "tData":[{"num7":688,"num6":3717,"SERVICEABILITY_RATE1":1,"SERVICEABILITY_RATE3":1,"EXCEPTION_NUM5":0,"SERVICEABILITY_RATE2":0.99,"EXCEPTION_NUM4":0,"EXCEPTION_NUM3":1,"SERVICEABILITY_RATE5":1,"EXCEPTION_NUM2":1,"SERVICEABILITY_RATE4":1,"EXCEPTION_NUM1":12,"SERVICEABILITY_RATE7":1,"SERVICEABILITY_RATE6":1,"EXCEPTION_NUM7":2,"EXCEPTION_NUM6":8,"num1":2843,"num5":70,"num4":90,"num3":230,"num2":113}],"rateData":[1,0.99,1,1,1,1,1]}
	 * 
	 * 
	 * 
	 */
	@RequestMapping(value = "/getEquipSituation", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getEquipSituation(String beginDate, String endDate) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return equipmentAnalyzeService.getEquipSituation(condition).toString();
	}

	/**
	 * 根据设备大类分组，获取各个井站设备数量、异常设备数量，设备的完好率
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return
	 */
	@RequestMapping(value = "/getEquipSituationOfWels", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getEquipSituationOfWels(String beginDate, String endDate) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return equipmentAnalyzeService.getEquipSituationOfWels(condition).toString();
	}

	/**
	 * 获取设备表的井站信息和设备大类
	 * 
	 * @return json格式，例如： { "wel_info": [ { "wel_name": "磨溪009-3-X3井", "wel_id":
	 *         "64532c29f7594a8fb7c9041a099925c5" }], "equ_class": [ "工艺设备", "机泵设备",
	 *         "辅助设备", "通信设备", "电气设备", "仪表设备", "其它" ] }
	 */
	@RequestMapping(value = "/getWelIInfoAndEquClass", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getWelIInfoAndEquClass() {
		return equipmentAnalyzeService.getWelIInfoAndEquClass().toString();
	}

	/**
	 * 根据设备大类统计，查询各个大类的设备数量
	 * 
	 * @param welId
	 *            井站id
	 * @param equClass
	 * @return
	 */
	@RequestMapping(value = "/getCountOfEquClass", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getCountOfEquClass(String welIds, String equClasses) {

		QueryCondition condition = new QueryCondition(TransformUtil.strToList(welIds),
				TransformUtil.strToList(equClasses));

		return equipmentAnalyzeService.getCountOfEquClass(condition).toString();
	}

	/**
	 * 根据井站统计设备数量
	 * 
	 * @param welIds
	 *            井站id
	 * @param equClasses
	 *            设备大类
	 * @return
	 */
	@RequestMapping(value = "/getCountOfWel", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getCountOfWel(String welIds, String equClasses) {
		QueryCondition condition = new QueryCondition(TransformUtil.strToList(welIds),
				TransformUtil.strToList(equClasses));
		return equipmentAnalyzeService.getCountOfWel(condition).toString();
	}

	/**
	 * 获取设备详细信息
	 * 
	 * @param welIds
	 *            井站id
	 * @param equClasses
	 *            设备大类
	 * @return json 格式，例如：{ "data": [{ "EQU_MODEL": "KQ47F", "EQU_RFID": "6aeb9239",
	 *         "EQU_INSTALL_POSITION": "发球筒大小头前端氮气置换进发球筒", "EQU_TYPE_NAME": "阀门",
	 *         "EQU_PRODUC_DATE": "2015-06-01\n\t\t00:00:00", "EQU_MANUFACTURER":
	 *         "五洲阀门有限公司", "EQU_SN": "1503250177", "EQU_MEMO_THREE": "工艺设备",
	 *         "EQU_COMMISSION_DATE": "2016-02-29 00:00:00", "EQU_POSITION_NUM":
	 *         "660-PG-050313", "WEL_NAME": "磨溪009-8-X1井" }, { "EQU_MODEL":
	 *         "YTU-100S", "EQU_RFID": "ba7c9439", "EQU_INSTALL_POSITION": "计量管段下游",
	 *         "EQU_TYPE_NAME": "就地仪表", "EQU_PRODUC_DATE":
	 *         "2015-05-01\n\t\t00:00:00", "EQU_MANUFACTURER": "重庆布莱迪仪器仪表有限公司",
	 *         "EQU_SN": "1520169", "EQU_MEMO_THREE": "仪表设备", "EQU_COMMISSION_DATE":
	 *         "2016-02-29 00:00:00", "EQU_POSITION_NUM": "660-PG-009", "WEL_NAME":
	 *         "磨溪009-8-X1井" }]}
	 */
	@RequestMapping(value = "/getEqumentInfo", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getEqumentInfo(String welIds, String equClasses) {
		QueryCondition condition = new QueryCondition(TransformUtil.strToList(welIds),
				TransformUtil.strToList(equClasses));
		return equipmentAnalyzeService.getEqumentInfo(condition).toString();
	}
	
	
	/**
	 * 根据井站统计设备总数、异常设备数量、设备完好率
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value = "/getEquSituationOfWel", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getEquSituationOfWel(String beginDate,String endDate) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return equipmentAnalyzeService.getEquSituationOfWel(condition).toString();
	}
	
	/**
	 * 根据设备小类统计设备总数、异常设备数量、设备完好率
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value = "/getEquSituationOfSubclass", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getEquSituationOfSubclass(String beginDate,String endDate) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return equipmentAnalyzeService.getEquSituationOfSubclass(condition).toString();
	}
	
	/**
	 * 根据设备小类统计设备数量
	 * 
	 * @param welIds
	 *            井站id
	 * @param equClasses
	 *            设备大类
	 * @return
	 */
	@RequestMapping(value = "/getCountOfSubclass", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getCountOfSubclass(String welIds, String equClasses) {
		QueryCondition condition = new QueryCondition(TransformUtil.strToList(welIds),
				TransformUtil.strToList(equClasses));
		return equipmentAnalyzeService.getCountOfSubclass(condition).toString();
	}

}
