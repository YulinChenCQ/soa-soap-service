
/**
 * <һ�仰��������>
 * <p>
 * @author ������
 * @version [�汾��, 2018��9��16��]
 * @see [�����/����]
 * @since [��Ʒ/ģ��汾]
 */
package com.soa.bigdataAnalyze.util;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

public class PropertiesUtil {
	 
 
    private static Properties props;
 
    static {
        
        props = new Properties();
        try {
            props.load(new InputStreamReader(PropertiesUtil.class.getClassLoader().getResourceAsStream("redisConfig"),"UTF-8"));
        } catch (IOException e) {
        	e.printStackTrace();
        }
    }
 
    public static String getProperty(String key){
        String value = props.getProperty(key.trim());
        if(value == null || value.isEmpty()){
            return null;
        }
        return value.trim();
    }
 
    public static String getProperty(String key,String defaultValue){
 
        String value = props.getProperty(key.trim());
        if(value == null || value.isEmpty()){
            value = defaultValue;
        }
        return value.trim();
    }
    
    
    public static void main(String[] args) {
		System.out.println(getProperty("redisServer"));
	}
 
 
 
}
