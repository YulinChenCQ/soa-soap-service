
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年9月30日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.mapper.BiEquipmentRecordMapper;
import com.soa.bigdataAnalyze.util.DataHandleUtil;
import com.soa.bigdataAnalyze.util.MathUtil;

@Service
public class EquipmentAnalyzeService {

	@Autowired
	private BiEquipmentRecordMapper equipmentRecordMapper;

	/**
	 * 获取设备记录信息（按逐个设备统计）
	 * 
	 * @param ifVerify
	 * @return
	 */
	public JSONObject getRecordInfoByDevice(QueryCondition condition) {

		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findRecordInfoByDevice(condition);

		List<JSONObject> dataJsonList = new ArrayList<JSONObject>();

		Double operationNumMax = null;
		Double exceptionNumMax = null;
		Double tendingNumMax = null;
		Double maintainNumMax = null;
		Double verifyNumMax = null;
		List<JSONObject> indicatorList = new ArrayList<JSONObject>();

		if ("1".equals(condition.getIfVerify())) {
			// 需要校验设备
			for (Map<String, String> result : results) {

				JSONObject dataJson = new JSONObject();
				List<Double> dataLit = new ArrayList<Double>();

				Double operationNum = Double.parseDouble(result.get("OPERATION_NUM"));
				operationNumMax = DataHandleUtil.getMax(operationNumMax, operationNum);

				Double exceptionNum = Double.parseDouble(result.get("EXCEPTION_NUM"));
				exceptionNumMax = DataHandleUtil.getMax(exceptionNumMax, exceptionNum);

				Double tendingNum = Double.parseDouble(result.get("TENDING_NUM"));
				tendingNumMax = DataHandleUtil.getMax(tendingNumMax, tendingNum);

				Double maintainNum = Double.parseDouble(result.get("MAINTAIN_NUM"));
				maintainNumMax = DataHandleUtil.getMax(maintainNumMax, maintainNum);

				Double verifyNum = Double.parseDouble(result.get("VERIFY_NUM"));
				verifyNumMax = DataHandleUtil.getMax(verifyNumMax, verifyNum);

				dataLit.add(operationNum);// 操作记录数
				dataLit.add(exceptionNum);// （异常）隐患记录数
				dataLit.add(tendingNum);// 维护保养记录数
				dataLit.add(maintainNum);// 检维修记录数
				dataLit.add(verifyNum);// 校验记录数

				try {
					dataJson.put("name", result.get("EQU_SIGN"));// 设备名称+rfid
					dataJson.put("value", dataLit);
					dataJsonList.add(dataJson);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

			indicatorList.add(DataHandleUtil.getIndicator("操作记录", operationNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("（异常）隐患记录", exceptionNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("维护保养记录", tendingNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("检维修记录", maintainNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("校验记录", verifyNumMax * 1.2));
		} else if ("2".equals(condition.getIfVerify())) {
			// 不需要校验设备
			for (Map<String, String> result : results) {
				JSONObject dataJson = new JSONObject();
				List<Double> dataLit = new ArrayList<Double>();
				Double operationNum = Double.parseDouble(result.get("OPERATION_NUM"));
				operationNumMax = DataHandleUtil.getMax(operationNumMax, operationNum);

				Double exceptionNum = Double.parseDouble(result.get("EXCEPTION_NUM"));
				exceptionNumMax = DataHandleUtil.getMax(exceptionNumMax, exceptionNum);

				Double tendingNum = Double.parseDouble(result.get("TENDING_NUM"));
				tendingNumMax = DataHandleUtil.getMax(tendingNumMax, tendingNum);

				Double maintainNum = Double.parseDouble(result.get("MAINTAIN_NUM"));
				maintainNumMax = DataHandleUtil.getMax(maintainNumMax, maintainNum);

				dataLit.add(operationNum);// 操作记录数
				dataLit.add(exceptionNum);// （异常）隐患记录数
				dataLit.add(tendingNum);// 维护保养记录数
				dataLit.add(maintainNum);// 检维修记录数

				try {
					dataJson.put("name", result.get("EQU_SIGN"));
					dataJson.put("value", dataLit);
					dataJsonList.add(dataJson);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

			indicatorList.add(DataHandleUtil.getIndicator("操作记录", operationNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("（异常）隐患记录", exceptionNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("维护保养记录", tendingNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("检维修记录", maintainNumMax * 1.2));
		}

		try {
			reJo.put("data", dataJsonList);
			reJo.put("indicator", indicatorList);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * 获取设备记录信息（按设备大类统计）
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getRecordInfoByClass(QueryCondition condition) {

		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findRecordInfoByClass(condition);
		//System.out.println(results);

		List<String> legendData = new ArrayList<String>();
		List<JSONObject> dataList = new ArrayList<JSONObject>();
		Double operationNumMax = null;
		Double exceptionNumMax = null;
		Double tendingNumMax = null;
		Double maintainNumMax = null;
		Double verifyNumMax = null;
		Double failureRateMax = Double.parseDouble("100");

		for (Map<String, String> result : results) {
			List<Double> value = new ArrayList<Double>();

			JSONObject dataJson = new JSONObject();
			String className = result.get("EQU_MEMO_THREE");// 设备大类名称
			Double operationNum = Double.parseDouble(result.get("OPERATION_NUM"));
			operationNumMax = DataHandleUtil.getMax(operationNumMax, operationNum);

			Double exceptionNum = Double.parseDouble(result.get("EXCEPTION_NUM"));
			exceptionNumMax = DataHandleUtil.getMax(exceptionNumMax, exceptionNum);

			Double tendingNum = Double.parseDouble(result.get("TENDING_NUM"));
			tendingNumMax = DataHandleUtil.getMax(tendingNumMax, tendingNum);

			Double maintainNum = Double.parseDouble(result.get("MAINTAIN_NUM"));
			maintainNumMax = DataHandleUtil.getMax(maintainNumMax, maintainNum);

			Double verifyNum = Double.parseDouble(result.get("VERIFY_NUM"));
			verifyNumMax = DataHandleUtil.getMax(verifyNumMax, verifyNum);

			Double failureRate = Double.parseDouble(result.get("FAILURERATE"));

			value.add(operationNum);// 操作记录数
			value.add(exceptionNum);// 异常记录数
			value.add(tendingNum);// 维护保养数
			value.add(maintainNum);// 检维修数
			value.add(verifyNum);// 校验记录数
			value.add(failureRate);// 故障率

			legendData.add(className);
			try {
				dataJson.put("name", className);
				dataJson.put("value", value);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			dataList.add(dataJson);
		}

		List<JSONObject> indicatorList = new ArrayList<JSONObject>();
		//System.out.println("operationNumMax:>>>>>>" + operationNumMax);
		indicatorList.add(DataHandleUtil.getIndicator("操作记录", operationNumMax * 1.2));
		indicatorList.add(DataHandleUtil.getIndicator("（异常）隐患记录", exceptionNumMax * 1.2));
		indicatorList.add(DataHandleUtil.getIndicator("维护保养记录", tendingNumMax * 1.2));
		indicatorList.add(DataHandleUtil.getIndicator("检维修记录", maintainNumMax * 1.2));
		indicatorList.add(DataHandleUtil.getIndicator("校验记录", verifyNumMax * 1.2));
		indicatorList.add(DataHandleUtil.getIndicator("故障率", failureRateMax * 1.2));

		try {
			reJo.put("legendData", legendData);
			reJo.put("data", dataList);
			reJo.put("indicator", indicatorList);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * 获取设备记录信息（按设备小类统计）
	 * 
	 * @param condition
	 *            查询条件
	 * @return
	 */
	public JSONObject getRecordInfoBySubclass(QueryCondition condition) {

		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findRecordInfoBySubclass(condition);

		List<String> legendData = new ArrayList<String>();
		List<JSONObject> dataList = new ArrayList<JSONObject>();
		Double operationNumMax = null;
		Double exceptionNumMax = null;
		Double tendingNumMax = null;
		Double maintainNumMax = null;
		Double verifyNumMax = null;
		Double failureRateMax = Double.parseDouble("100");
		List<JSONObject> indicatorList = new ArrayList<JSONObject>();

		if ("1".equals(condition.getIfVerify())) {
			for (Map<String, String> result : results) {
				List<Double> value = new ArrayList<Double>();

				JSONObject dataJson = new JSONObject();
				String className = result.get("EQU_TYPE_NAME");// 设备小类名称
				Double operationNum = Double.parseDouble(result.get("OPERATION_NUM"));
				operationNumMax = DataHandleUtil.getMax(operationNumMax, operationNum);

				Double exceptionNum = Double.parseDouble(result.get("EXCEPTION_NUM"));
				exceptionNumMax = DataHandleUtil.getMax(exceptionNumMax, exceptionNum);

				Double tendingNum = Double.parseDouble(result.get("TENDING_NUM"));
				tendingNumMax = DataHandleUtil.getMax(tendingNumMax, tendingNum);

				Double maintainNum = Double.parseDouble(result.get("MAINTAIN_NUM"));
				maintainNumMax = DataHandleUtil.getMax(maintainNumMax, maintainNum);

				Double verifyNum = Double.parseDouble(result.get("VERIFY_NUM"));
				verifyNumMax = DataHandleUtil.getMax(verifyNumMax, verifyNum);

				Double failureRate = Double.parseDouble(result.get("FAILURERATE"));

				value.add(operationNum);// 操作记录数
				value.add(exceptionNum);// 异常记录数
				value.add(tendingNum);// 维护保养数
				value.add(maintainNum);// 检维修数
				value.add(verifyNum);// 校验记录数
				value.add(failureRate);// 故障率

				legendData.add(className);
				try {
					dataJson.put("name", className);
					dataJson.put("value", value);
				} catch (JSONException e) {
					e.printStackTrace();
				}
				dataList.add(dataJson);
			}
			indicatorList.add(DataHandleUtil.getIndicator("操作记录", operationNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("（异常）隐患记录", exceptionNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("维护保养记录", tendingNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("检维修记录", maintainNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("校验记录", verifyNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("故障率", failureRateMax * 1.2));
		} else if ("2".equals(condition.getIfVerify())) {
			for (Map<String, String> result : results) {
				List<Double> value = new ArrayList<Double>();

				JSONObject dataJson = new JSONObject();
				String className = result.get("EQU_TYPE_NAME");// 设备小类名称
				Double operationNum = Double.parseDouble(result.get("OPERATION_NUM"));
				operationNumMax = DataHandleUtil.getMax(operationNumMax, operationNum);

				Double exceptionNum = Double.parseDouble(result.get("EXCEPTION_NUM"));
				exceptionNumMax = DataHandleUtil.getMax(exceptionNumMax, exceptionNum);

				Double tendingNum = Double.parseDouble(result.get("TENDING_NUM"));
				tendingNumMax = DataHandleUtil.getMax(tendingNumMax, tendingNum);

				Double maintainNum = Double.parseDouble(result.get("MAINTAIN_NUM"));
				maintainNumMax = DataHandleUtil.getMax(maintainNumMax, maintainNum);

				Double failureRate = Double.parseDouble(result.get("FAILURERATE"));

				value.add(operationNum);// 操作记录数
				value.add(exceptionNum);// 异常记录数
				value.add(tendingNum);// 维护保养数
				value.add(maintainNum);// 检维修数
				value.add(failureRate);// 故障率

				legendData.add(className);
				try {
					dataJson.put("name", className);
					dataJson.put("value", value);
				} catch (JSONException e) {
					e.printStackTrace();
				}
				dataList.add(dataJson);
			}
			indicatorList.add(DataHandleUtil.getIndicator("操作记录", operationNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("（异常）隐患记录", exceptionNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("维护保养记录", tendingNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("检维修记录", maintainNumMax * 1.2));
			indicatorList.add(DataHandleUtil.getIndicator("故障率", failureRateMax * 1.2));
		} else {
			try {
				reJo.put("status", "-1");
				reJo.put("message", "无效的ifverify参数值");
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		try {
			reJo.put("legendData", legendData);
			reJo.put("data", dataList);
			reJo.put("indicator", indicatorList);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * @param condition
	 * @return
	 */
	public JSONObject getRecordInfoOfWelsByClass(QueryCondition condition) {
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findRecordInofOfWelsByClass(condition);
		// System.out.println(results);

		/**
		 * key-井站，value-井站对应的数据
		 */
		Map<String, List<JSONObject>> dataMap = new HashMap<String, List<JSONObject>>();

		for (Map<String, String> result : results) {

			List<JSONObject> data = dataMap.get(result.get("WEL_NAME"));

			if (data == null || data.isEmpty()) {
				data = new ArrayList<JSONObject>();
			}
			List<Double> valueList = new ArrayList<Double>();
			valueList.add(Double.parseDouble(result.get("OPERATION_NUM")));// 操作记录数
			valueList.add(Double.parseDouble(result.get("EXCEPTION_NUM")));// (异常)隐患记录数
			valueList.add(Double.parseDouble(result.get("TENDING_NUM")));// 维护保养数
			valueList.add(Double.parseDouble(result.get("MAINTAIN_NUM")));// 检维修数
			valueList.add(Double.parseDouble(result.get("VERIFY_NUM")));// 校验数
			valueList.add(Double.parseDouble(result.get("FAILURERATE")));// 故障率
			JSONObject dataJson = new JSONObject();
			try {
				dataJson.put("name", result.get("EQU_MEMO_THREE"));
				dataJson.put("value", valueList);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			data.add(dataJson);
			dataMap.put(result.get("WEL_NAME"), data);
		}
		JSONObject lineStyle = null;
		try {
			lineStyle = new JSONObject("{width: 1}");
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		List<String> legendData = new ArrayList<String>();
		List<JSONObject> seriesData = new ArrayList<JSONObject>();
		Set<String> keys = dataMap.keySet();
		for (String key : keys) {
			legendData.add(key);
			JSONObject seriesJson = new JSONObject();
			try {
				seriesJson.put("name", key);
				seriesJson.put("data", dataMap.get(key));
				seriesJson.put("type", "radar");
				seriesJson.put("lineStyle", lineStyle);
				seriesData.add(seriesJson);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		try {
			reJo.put("seriesData", seriesData);
			reJo.put("legendData", legendData);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * @param condition
	 * @return
	 */
	public JSONObject getRecordInfoOfWelsBySubclass(QueryCondition condition) {
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findRecordInfOfWelsBySubclass(condition);
		// System.out.println(results);

		/**
		 * key-井站，value-井站对应的数据
		 */
		Map<String, List<JSONObject>> dataMap = new HashMap<String, List<JSONObject>>();

		/**
		 * echart图线条样式
		 */
		JSONObject lineStyle = null;
		try {
			lineStyle = new JSONObject("{width: 1}");
		} catch (JSONException e1) {
			e1.printStackTrace();
		}

		if ("1".equals(condition.getIfVerify())) {
			// 需要校验设备
			for (Map<String, String> result : results) {

				List<JSONObject> data = dataMap.get(result.get("WEL_NAME"));

				if (data == null || data.isEmpty()) {
					data = new ArrayList<JSONObject>();
				}
				List<Double> valueList = new ArrayList<Double>();
				valueList.add(Double.parseDouble(result.get("OPERATION_NUM")));// 操作记录数
				valueList.add(Double.parseDouble(result.get("EXCEPTION_NUM")));// (异常)隐患记录数
				valueList.add(Double.parseDouble(result.get("TENDING_NUM")));// 维护保养数
				valueList.add(Double.parseDouble(result.get("MAINTAIN_NUM")));// 检维修数
				valueList.add(Double.parseDouble(result.get("VERIFY_NUM")));// 校验数
				valueList.add(Double.parseDouble(result.get("FAILURERATE")));// 故障率
				JSONObject dataJson = new JSONObject();
				try {
					dataJson.put("name", result.get("EQU_TYPE_NAME"));
					dataJson.put("value", valueList);
				} catch (JSONException e) {
					e.printStackTrace();
				}
				data.add(dataJson);
				dataMap.put(result.get("WEL_NAME"), data);
			}

		} else if ("2".equals(condition.getIfVerify())) {
			// 不需要校验设备
			for (Map<String, String> result : results) {

				List<JSONObject> data = dataMap.get(result.get("WEL_NAME"));

				if (data == null || data.isEmpty()) {
					data = new ArrayList<JSONObject>();
				}
				List<Double> valueList = new ArrayList<Double>();
				valueList.add(Double.parseDouble(result.get("OPERATION_NUM")));// 操作记录数
				valueList.add(Double.parseDouble(result.get("EXCEPTION_NUM")));// (异常)隐患记录数
				valueList.add(Double.parseDouble(result.get("TENDING_NUM")));// 维护保养数
				valueList.add(Double.parseDouble(result.get("MAINTAIN_NUM")));// 检维修数
				valueList.add(Double.parseDouble(result.get("FAILURERATE")));// 故障率
				JSONObject dataJson = new JSONObject();
				try {
					dataJson.put("name", result.get("EQU_TYPE_NAME"));
					dataJson.put("value", valueList);
				} catch (JSONException e) {
					e.printStackTrace();
				}
				data.add(dataJson);
				dataMap.put(result.get("WEL_NAME"), data);
			}
		} else {
			try {
				reJo.put("status", "-1");
				reJo.put("message", "传入的ifverify值有误");
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		List<String> legendData = new ArrayList<String>();
		List<JSONObject> seriesData = new ArrayList<JSONObject>();
		Set<String> keys = dataMap.keySet();
		for (String key : keys) {
			legendData.add(key);
			JSONObject seriesJson = new JSONObject();
			try {
				seriesJson.put("name", key);
				seriesJson.put("data", dataMap.get(key));
				seriesJson.put("type", "radar");
				seriesJson.put("lineStyle", lineStyle);
				seriesData.add(seriesJson);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		try {
			reJo.put("seriesData", seriesData);
			reJo.put("legendData", legendData);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * 根据设备大类分组，获取各个井站设备数量、异常设备数量，设备的完好率
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getEquipSituation(QueryCondition condition) {

		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findEquipSituation(condition);

		// System.out.println(results);

		List<String> tHead = new ArrayList<String>();
		List<JSONObject> tData = new ArrayList<JSONObject>();
		int i = 1;

		JSONObject dataJson = new JSONObject();

		List<Double> numData = new ArrayList<Double>();
		List<Double> exceptionNumData = new ArrayList<Double>();
		List<Double> rateData = new ArrayList<Double>();
		for (Map<String, String> result : results) {
			tHead.add(result.get("EQU_MEMO_THREE"));
			Double num = Double.parseDouble(result.get("NUM"));// 设备总数
			Double exceptionNum = Double.parseDouble(result.get("EXCEPTION_NUM"));// 异常设备数
			Double rate = Double.parseDouble(result.get("SERVICEABILITY_RATE")) * 100;// 设备完好率

			try {
				dataJson.put("NUM" + i, num);
				dataJson.put("EXCEPTION_NUM" + i, exceptionNum);
				dataJson.put("SERVICEABILITY_RATE" + i, rate + "%");
			} catch (JSONException e) {
				e.printStackTrace();
			}
			numData.add(num);
			exceptionNumData.add(exceptionNum);
			rateData.add(rate);
			i++;
		}
		tData.add(dataJson);

		/**
		 * 构造返回数据
		 */

		try {
			reJo.put("tHead", tHead);
			reJo.put("tData", tData);
			reJo.put("numData", numData);
			reJo.put("exceptionNumData", exceptionNumData);
			reJo.put("rateData", rateData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * @param condition
	 * @return
	 */
	public JSONObject getEquipSituationOfWels(QueryCondition condition) {

		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findEquipSituationOfWels(condition);

		List<String> equClasses = equipmentRecordMapper.findClassOfEquip();
		int nameRemark = 1;

		Map<String, String> nameRemarkMap = new HashMap<String, String>();
		for (String equClass : equClasses) {
			nameRemarkMap.put(equClass, nameRemark + "");
			nameRemark++;
		}

		Map<String, List<Map<String, String>>> welsData = new HashMap<String, List<Map<String, String>>>();

		for (Map<String, String> result : results) {
			List<Map<String, String>> welDataList = welsData.get(result.get("WEL_NAME"));
			if (welDataList == null || welDataList.isEmpty()) {
				welDataList = new ArrayList<Map<String, String>>();
			}
			welDataList.add(result);
			welsData.put(result.get("WEL_NAME"), welDataList);
		}

		Set<String> keys = welsData.keySet();

		Double totalNum = 0.0;
		Double totalExceptionNum = 0.0;
		int serial_num = 1;
		List<JSONObject> tData = new ArrayList<JSONObject>();
		List<String> tHead = new ArrayList<String>();
		for (String key : keys) {
			List<Map<String, String>> welDataList = welsData.get(key);
			JSONObject welDataJson = new JSONObject();
			for (Map<String, String> welDataMap : welDataList) {
				// System.out.println("welDataMap>>>>" + welDataMap);
				String equClass = welDataMap.get("EQU_MEMO_THREE");

				Double num = Double.parseDouble(welDataMap.get("NUM"));
				Double exceptionNumData = Double.parseDouble(welDataMap.get("EXCEPTION_NUM"));
				Double rate = Double.parseDouble(welDataMap.get("SERVICEABILITY_RATE")) * 100;
				totalNum += num;
				totalExceptionNum += exceptionNumData;
				try {

					welDataJson.put("SERIAL_NUM", serial_num);
					welDataJson.put("WEL_NAME", key);
					welDataJson.put("NUM" + nameRemarkMap.get(equClass), num);// 设备总数
					welDataJson.put("EXCEPTION_NUM" + nameRemarkMap.get(equClass), exceptionNumData);// 异常设备数
					welDataJson.put("SERVICEABILITY_RATE" + nameRemarkMap.get(equClass), rate + "%");// 设备完好率
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

			try {
				welDataJson.put("total_num", totalNum);
				welDataJson.put("tatal_exception_num", totalExceptionNum);
				welDataJson.put("total_rate",
						MathUtil.getRound((totalNum - totalExceptionNum) / totalNum * 100, 2) + "%");
			} catch (JSONException e) {
				e.printStackTrace();
			}

			tData.add(welDataJson);
			serial_num++;
		}

		try {
			reJo.put("tData", tData);
			reJo.put("tHead", equClasses);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * 获取设备表的井站名称和井站id
	 * 
	 * @return
	 */
	public JSONObject getWelIInfoAndEquClass() {
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> welInfos = equipmentRecordMapper.findWelInfo();// 井站信息

		List<JSONObject> welInfoList = new ArrayList<JSONObject>();
		for (Map<String, String> welInfo : welInfos) {

			JSONObject welInfoJson = new JSONObject();
			try {
				welInfoJson.put("wel_name", welInfo.get("WEL_NAME"));
				welInfoJson.put("wel_id", welInfo.get("WEL_ID"));
			} catch (JSONException e) {
				e.printStackTrace();
			}
			welInfoList.add(welInfoJson);
		}

		List<String> equClasses = equipmentRecordMapper.findClassOfEquip();// 设备大类

		try {
			reJo.put("wel_info", welInfoList);
			reJo.put("equ_class", equClasses);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * 按设备大类统计，获取各个大类设备数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountOfEquClass(QueryCondition condition) {

		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findCountOfEquClass(condition);

		List<JSONObject> dataList = new ArrayList<JSONObject>();
		List<String> legendData = new ArrayList<String>();
		for (Map<String, String> result : results) {
			JSONObject dataJson = new JSONObject();
			legendData.add(result.get("EQU_MEMO_THREE"));
			try {
				dataJson.put("name", result.get("EQU_MEMO_THREE"));
				dataJson.put("value", Integer.parseInt(result.get("NUM")));
			} catch (JSONException e) {
				e.printStackTrace();
			}
			dataList.add(dataJson);

		}

		try {
			reJo.put("data", dataList);
			reJo.put("legendData", legendData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * 根据井站统计设备数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountOfWel(QueryCondition condition) {
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findCountOfWel(condition);

		List<JSONObject> dataList = new ArrayList<JSONObject>();
		List<String> legendData = new ArrayList<String>();
		for (Map<String, String> result : results) {
			JSONObject dataJson = new JSONObject();
			legendData.add(result.get("WEL_NAME"));
			try {
				dataJson.put("name", result.get("WEL_NAME"));
				dataJson.put("value", Integer.parseInt(result.get("NUM")));
			} catch (JSONException e) {
				e.printStackTrace();
			}
			dataList.add(dataJson);

		}

		try {
			reJo.put("data", dataList);
			reJo.put("legendData", legendData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * 获取设备的详细信息
	 * 
	 * @param condition
	 *            WEL_NAME,EQU_MEMO_THREE,EQU_TYPE_NAME,EQU_RFID,EQU_MODEL,TO_CHAR(EQU_PRODUC_DATE,'YYYY-MM-DD
	 *            HH24:MI:SS') AS
	 *            EQU_PRODUC_DATE,TO_CHAR(EQU_COMMISSION_DATE,'YYYY-MM-DD
	 *            HH24:MI:SS') AS
	 *            EQU_COMMISSION_DATE,EQU_INSTALL_POSITION,EQU_MANUFACTURER,EQU_POSITION_NUM,EQU_SN
	 * @return
	 */
	public JSONObject getEqumentInfo(QueryCondition condition) {
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findEquipmentInfo(condition);

		List<JSONObject> dataList = new ArrayList<JSONObject>();
		for (Map<String, String> result : results) {
			JSONObject dataJson = new JSONObject();
			try {
				dataJson.put("WEL_NAME", result.get("WEL_NAME"));// 井站名称
				dataJson.put("EQU_MEMO_THREE", result.get("EQU_MEMO_THREE"));// 设备大类
				dataJson.put("EQU_TYPE_NAME", result.get("EQU_TYPE_NAME"));// 设备小类
				dataJson.put("EQU_RFID", result.get("EQU_RFID"));// RFID
				dataJson.put("EQU_NAME", result.get("EQU_NAME"));// 设备名称
				dataJson.put("EQU_MODEL", result.get("EQU_MODEL"));// 设备型号
				dataJson.put("EQU_PRODUC_DATE", result.get("EQU_PRODUC_DATE"));// 出厂日期
				dataJson.put("EQU_COMMISSION_DATE", result.get("EQU_COMMISSION_DATE"));// 投运日期
				dataJson.put("EQU_INSTALL_POSITION", result.get("EQU_INSTALL_POSITION"));// 安装位置
				dataJson.put("EQU_MANUFACTURER", result.get("EQU_MANUFACTURER"));// 生产厂家
				dataJson.put("EQU_POSITION_NUM", result.get("EQU_POSITION_NUM"));// 设备位号
				dataJson.put("EQU_SN", result.get("EQU_SN"));// 产品序列号
			} catch (JSONException e) {
				e.printStackTrace();
			}
			dataList.add(dataJson);
		}
		try {
			reJo.put("data", dataList);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * 根据井站统计设备总数、异常设备数量、设备完好率
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getEquSituationOfWel(QueryCondition condition) {
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findEquSituationOfWel(condition);

		List<JSONObject> dataList = new ArrayList<JSONObject>();
		for (Map<String, String> result : results) {
			JSONObject dataJson = new JSONObject();

			try {
				dataJson.put("WEL_NAME", result.get("WEL_NAME"));// 井站名称
				dataJson.put("NUM", result.get("NUM"));// 设备总数
				dataJson.put("EXCEPTION_NUM", result.get("EXCEPTION_NUM"));// 设备异常数
				dataJson.put("SERVICEABILITY_RATE", Double.parseDouble(result.get("SERVICEABILITY_RATE")) * 100 + "%");// 设备完好率
			} catch (JSONException e) {
				e.printStackTrace();
			}
			dataList.add(dataJson);

		}
		try {
			reJo.put("data", dataList);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * 根据设备小类统计设备总数、异常设备数量、设备完好率
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getEquSituationOfSubclass(QueryCondition condition) {
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findEquSituationOfSubclass(condition);

		List<JSONObject> dataList = new ArrayList<JSONObject>();
		for (Map<String, String> result : results) {
			JSONObject dataJson = new JSONObject();

			try {
				dataJson.put("SUBCLASS", result.get("EQU_TYPE_NAME"));// 设备小类
				dataJson.put("NUM", result.get("NUM"));// 设备总数
				dataJson.put("EXCEPTION_NUM", result.get("EXCEPTION_NUM"));// 设备异常数
				dataJson.put("SERVICEABILITY_RATE", Double.parseDouble(result.get("SERVICEABILITY_RATE")) * 100 + "%");// 设备完好率
			} catch (JSONException e) {
				e.printStackTrace();
			}
			dataList.add(dataJson);

		}
		try {
			reJo.put("data", dataList);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * 
	 * 根据设备小类统计设备数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountOfSubclass(QueryCondition condition) {
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = equipmentRecordMapper.findCountOfSubclass(condition);

		List<JSONObject> dataList = new ArrayList<JSONObject>();
		for (Map<String, String> result : results) {
			JSONObject dataJson = new JSONObject();
			try {
				dataJson.put("name", result.get("EQU_TYPE_NAME"));
				dataJson.put("value", Integer.parseInt(result.get("NUM")));
			} catch (JSONException e) {
				e.printStackTrace();
			}
			dataList.add(dataJson);

		}

		try {
			reJo.put("data", dataList);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

}
