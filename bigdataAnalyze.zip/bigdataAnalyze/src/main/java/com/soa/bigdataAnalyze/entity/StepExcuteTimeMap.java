
/**
 * <һ�仰��������>
 * <p>
 * @author ������
 * @version [�汾��, 2018��9��17��]
 * @see [�����/����]
 * @since [��Ʒ/ģ��汾]
 */
package com.soa.bigdataAnalyze.entity;

import java.io.Serializable;
import java.util.Map;

public class StepExcuteTimeMap implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8306031077297999110L;
	
	Map<String,String> stepExcuteTimeMap;

	/**
	 * @return the stepExcuteTimeMap
	 */
	public Map<String, String> getStepExcuteTimeMap() {
		return stepExcuteTimeMap;
	}

	/**
	 * @param stepExcuteTimeMap the stepExcuteTimeMap to set
	 */
	public void setStepExcuteTimeMap(Map<String, String> stepExcuteTimeMap) {
		this.stepExcuteTimeMap = stepExcuteTimeMap;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "StepExcuteTimeMap [stepExcuteTimeMap=" + stepExcuteTimeMap + "]";
	}
	
	

}
