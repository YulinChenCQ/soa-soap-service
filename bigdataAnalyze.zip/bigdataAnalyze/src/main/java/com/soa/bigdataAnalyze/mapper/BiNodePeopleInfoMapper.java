package com.soa.bigdataAnalyze.mapper;

import com.soa.bigdataAnalyze.entity.BiNodePeopleInfo;
import com.soa.bigdataAnalyze.entity.BiNodePeopleInfoExample;
import com.soa.bigdataAnalyze.entity.QueryCondition;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface BiNodePeopleInfoMapper {
    long countByExample(BiNodePeopleInfoExample example);

    int deleteByExample(BiNodePeopleInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(BiNodePeopleInfo record);

    int insertSelective(BiNodePeopleInfo record);

    List<BiNodePeopleInfo> selectByExample(BiNodePeopleInfoExample example);

    BiNodePeopleInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") BiNodePeopleInfo record, @Param("example") BiNodePeopleInfoExample example);

    int updateByExample(@Param("record") BiNodePeopleInfo record, @Param("example") BiNodePeopleInfoExample example);

    int updateByPrimaryKeySelective(BiNodePeopleInfo record);

    int updateByPrimaryKey(BiNodePeopleInfo record);
    
   
}