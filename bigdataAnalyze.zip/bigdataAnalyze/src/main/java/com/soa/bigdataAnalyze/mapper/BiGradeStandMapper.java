package com.soa.bigdataAnalyze.mapper;

import com.soa.bigdataAnalyze.entity.BiGradeStand;
import com.soa.bigdataAnalyze.entity.BiGradeStandExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface BiGradeStandMapper {
    long countByExample(BiGradeStandExample example);

    int deleteByExample(BiGradeStandExample example);

    int insert(BiGradeStand record);

    int insertSelective(BiGradeStand record);

    List<BiGradeStand> selectByExample(BiGradeStandExample example);

    int updateByExampleSelective(@Param("record") BiGradeStand record, @Param("example") BiGradeStandExample example);

    int updateByExample(@Param("record") BiGradeStand record, @Param("example") BiGradeStandExample example);
    
    /**
     * ��ѯ���е�Ȩ�ء���׼ֵ��Ϣ
     * @return
     */
    List<BiGradeStand> findAll();
    
    /**
     * �����������ͺ�ά���������޸�Ȩ�ء���׼ֵ��Ϣ
     * @return
     */
    int updateByTaskTypeAndDimNameEn(@Param("record") BiGradeStand record);
    
    
}