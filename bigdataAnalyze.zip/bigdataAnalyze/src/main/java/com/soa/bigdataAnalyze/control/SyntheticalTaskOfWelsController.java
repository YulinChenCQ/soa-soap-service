
/**
 * <一句话功能描述>
 * <p>多井站综合任务大数据分析接口
 * @author 陈宇林
 * @version [版本号, 2018年9月30日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.service.SyntheticalTaskOfWelsService;

@RestController
@RequestMapping("syntheticalTaskOfWels")
public class SyntheticalTaskOfWelsController {

	@Autowired
	private SyntheticalTaskOfWelsService syntheticalTaskOfWelsService;

	/**
	 * 获取各个井站每种任务的任务数量
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return json格式，如： {"temporary":[95,92,96,94], "tending":[99,98,96],
	 *         "welName":["磨溪205井","磨溪008-X2井","磨溪201井"],
	 *         "inspection":[98,92,96,92,99,93,], "dynamicAnalysis":[96,94,98],
	 *         "territorialSupervision":[95,97,95]} 其中：inspection->巡回检查任务数量
	 *         tending->维护保养任务数量 dynamicAnalysis->动态分析任务数量
	 *         territorialSupervision->属地监督任务数量 temporary->临时任务数量
	 * 
	 */
	@RequestMapping(value = "/getCountOfWelByType", method = RequestMethod.POST, produces = "texe/plain;charset=utf-8")
	public String getCountOfWelByType(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return syntheticalTaskOfWelsService.getCountOfWelByType(condition).toString();
	}

	/**
	 * 获取各个井站每种任务的完成率
	 * 
	 * @param beginDate
	 * @param endDate
	 * @return json 格式 例如:
	 *         {"seriesData":[{"name":"磨溪009-8-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪108井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-3-X3井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"高石001-X7井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪12井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪022-X3井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-17-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"北6集气站","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-H19井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-H8井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"高石12井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"高石001-X6井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪204井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-X16井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"西区复线末站","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪119井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪8井组","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-3-X2井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"西北区集气站","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"西眉清管站","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪13井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪9井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"白鹤桥联合站","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-H1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"西区复线首站","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-11-X2井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-7-X2井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪17井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-4-X2井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-15-H1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"高石001-X5井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"高石3井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"西区集气站","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"高石001-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪16-C1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-3-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-20-H2井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪118井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-X6井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-6井组","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪22井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"22井区试采集气站","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-11-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪10井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-X2井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪18井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-20-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-4-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪202井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪105井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"高石001-X4井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"高石2井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪101井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-12-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-7-H1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"东区集气站","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-18-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪109井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-2-H2井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"高石001-X8井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-H3井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪11井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-X5井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-H21井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪009-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪002-X1井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪205井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪008-X2井","value":[0.96,0.96,0.96,0.96,0.96]},{"name":"磨溪201井","value":[0.96,0.96,0.96,0.96,0.96]}],"legendData":["磨溪009-8-X1井","磨溪108井","磨溪009-3-X3井","高石001-X7井","磨溪12井","磨溪022-X3井","磨溪008-17-X1井","北6集气站","磨溪008-H19井","磨溪008-H8井","高石12井","高石001-X6井","磨溪204井","磨溪008-X16井","西区复线末站","磨溪119井","磨溪8井组","磨溪009-3-X2井","西北区集气站","西眉清管站","磨溪13井","磨溪9井","白鹤桥联合站","磨溪008-H1井","西区复线首站","磨溪008-11-X2井","磨溪008-7-X2井","磨溪17井","磨溪009-4-X2井","磨溪008-15-H1井","高石001-X5井","高石3井","西区集气站","高石001-X1井","磨溪16-C1井","磨溪009-3-X1井","磨溪008-20-H2井","磨溪118井","磨溪009-X6井","磨溪008-6井组","磨溪22井","22井区试采集气站","磨溪008-11-X1井","磨溪10井","磨溪009-X2井","磨溪18井","磨溪008-20-X1井","磨溪009-4-X1井","磨溪202井","磨溪105井","高石001-X4井","高石2井","磨溪101井","磨溪008-12-X1井","磨溪008-7-H1井","东区集气站","磨溪008-18-X1井","磨溪109井","磨溪009-2-H2井","高石001-X8井","磨溪008-H3井","磨溪11井","磨溪009-X5井","磨溪008-H21井","磨溪009-X1井","磨溪002-X1井","磨溪205井","磨溪008-X2井","磨溪201井"]}
	 * 
	 */
	@RequestMapping(value = "/getFinishRateOfWelsByType", method = RequestMethod.POST, produces = "texe/plain;charset=utf-8")
	public String getFinishRateOfWelsByType(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return syntheticalTaskOfWelsService.getFinishRateOfWelsByType(condition).toString();
	}

	/**
	 * 获取所有井站各种任务的得分
	 * 
	 * @param beginDate
	 * @param endDate
	 * @return json格式，例如： { "data": [ { "name": "磨溪009-8-X1井", "value": [ 75.33,
	 *         73.5, 74.75, 75.26, 73.75 ] }, { "name": "磨溪108井", "value": [ 76.44,
	 *         74.83, 74.06, 74.86, 74.49 ] }, { "name": "磨溪009-3-X3井", "value": [
	 *         75.37, 75.12, 74.85, 74.01, 74.04 ] } ], "legendData":
	 *         ["磨溪009-8-X1井", "磨溪108井", "磨溪009-3-X3井" ] }
	 */
	@RequestMapping(value = "/getTaskScoreOfWels", method = RequestMethod.POST, produces = "texe/plain;charset=utf-8")
	public String getTaskScoreOfWels(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);

		return syntheticalTaskOfWelsService.getTaskScoreOfWels(condition).toString();
	}

	/**
	 * 获取所有井站的综合任务得分
	 * 
	 * @param beginDate
	 * @param endDate
	 * @return json格式，例如： { "xData": [ "磨溪008-6井组", "磨溪008-7-H1井", "磨溪008-7-X2井" ],
	 *         "yData": [ 74.56, 75.49, 75.79 ] }
	 */
	@RequestMapping(value = "/getTaskScore", method = RequestMethod.POST, produces = "texe/plain;charset=utf-8")
	public String getTaskScore(@RequestParam("beginDate") String beginDate, @RequestParam("endDate") String endDate) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return syntheticalTaskOfWelsService.getTaskScore(condition).toString();
	}

	/**
	 * 获取所有井站每个月份任务综合得分 注：参数可以为空，若为空直接统计数据库的所有数据，不为空则根据参数过滤数据
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return
	 */
	@RequestMapping(value = "/getTaskScoreByMonth", method = RequestMethod.POST, produces = "texe/plain;charset=utf-8")
	public String getTaskScoreByMonth(String beginDate, String endDate) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);

		return syntheticalTaskOfWelsService.getTaskScoreByMonth(condition).toString();

	}

}
