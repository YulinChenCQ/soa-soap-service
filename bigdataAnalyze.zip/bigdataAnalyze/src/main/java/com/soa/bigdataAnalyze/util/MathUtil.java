
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年10月25日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;

/**
 * @author 70769
 *
 */
public class MathUtil {

	/**
	 * 获取一个min~max区间的随机数
	 * 
	 * @param min
	 *            整数
	 * @param max
	 *            整数
	 * @return
	 */
	public static double getRandomDoubleOfArea(double min, double max) {
		double result = Math.random() * (max - min) + min;

		BigDecimal bg = new BigDecimal(result).setScale(2, RoundingMode.UP);
		result = bg.doubleValue();
		return result;
	}

	/**
	 * 对小数进行四舍五入
	 * 
	 * @param number
	 *            需要四舍五入的数字
	 * @param decimalDigits
	 *            保留的小数位数
	 * @return
	 */
	public static Double getRound(double number, int decimalDigits) {
		BigDecimal bg = new BigDecimal(number);
		double f1 = bg.setScale(decimalDigits, BigDecimal.ROUND_HALF_UP).doubleValue();
		return f1;
	}
	
	public static String randomHexStr(int len) {
        try {
            StringBuffer result = new StringBuffer();
            for(int i=0;i<len;i++) {
                //随机生成0-15的数值并转换成16进制
                result.append(Integer.toHexString(new Random().nextInt(16)));
            }
            return result.toString().toUpperCase();
        } catch (Exception e) {
            System.out.println("获取16进制字符串异常，返回默认...");
            return "00CCCC";
        }
    }

	public static void main(String[] args) {

		System.out.println(getRound(3211.333332651654,3));

	}

}
