
/**
 * <一句话功能描述>
 * <p>问题大数据分析数据接口
 * @author 陈宇林
 * @version [版本号, 2018年9月30日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.service.ProblemAnalyzeService;

@RestController
@RequestMapping("problemAnalyze")
public class ProblemAnalyzeController {

	@Autowired
	private ProblemAnalyzeService problemAnalyzeService;

	/**
	 * 根据条件获取各种问题类型对应的问题数量
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param welIds
	 *            井站id（多个）
	 * @return json格式 ,例如: { "legendData": [ "物的不安全状态", "人的不安全行为", "管理因素", "环境因素" ],
	 *         "valueData": [ { "name": "物的不安全状态", "value": 356 }, { "name":
	 *         "人的不安全行为", "value": 85 }, { "name": "管理因素", "value": 83}, { "name":
	 *         "环境因素", "value": 254} ] }
	 */

	@RequestMapping(value = "/getCountByType", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getCountByType(@RequestParam("beginDate") String beginDate, @RequestParam("endDate") String endDate,
			@RequestParam("welIds") String welIds) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welIds);
		return problemAnalyzeService.getCountByType(condition).toString();
	}

	/**
	 * 根据条件获取各种问题处理类型的问题数量
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param welIds
	 *            井站id（多个）
	 * @return json格式，例如： { "legendData": [ "未处理", "待执行", "待反馈", "待验证", "已销项",
	 *         "已销项(井站员工自行处理)", "未处理(已纳入隐患)", "分析处理(已启动任务)" ], "valueData": [ {
	 *         "name": "未处理", "value": 340 }, { "name": "待执行", "value": 107 }, {
	 *         "name": "待反馈", "value": 221 }, { "name": "待验证", "value": 367 }, {
	 *         "name": "已销项", "value": 295 }, { "name": "已销项(井站员工自行处理)", "value":
	 *         285 }, { "name": "未处理(已纳入隐患)", "value": 225 }, { "name":
	 *         "分析处理(已启动任务)", "value": 285 } ] }
	 */
	@RequestMapping(value = "/getCountByState", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getCountByState(@RequestParam("beginDate") String beginDate, @RequestParam("endDate") String endDate,
			@RequestParam("welIds") String welIds) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welIds);
		return problemAnalyzeService.getCountByState(condition).toString();
	}

	/**
	 * 根据条件获取各种问题级别的问题数量
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param welIds
	 *            井站id（多个）
	 * @return json格式，例如： { "legendData": [ "轻微", "一般", "严重", "非常严重" ], "valueData":
	 *         [ { "name": "轻微", "value": 225 }, { "name": "一般", "value": 328 }, {
	 *         "name": "严重", "value": 201 }, { "name": "非常严重", "value": 293 } ] }
	 */
	@RequestMapping(value = "/getCountByGrade", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getCountByGrade(@RequestParam("beginDate") String beginDate, @RequestParam("endDate") String endDate,
			@RequestParam("welIds") String welIds) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welIds);
		return problemAnalyzeService.getCountByGrade(condition).toString();

	}

	/**
	 * 根据条件获取各种问题来源的问题数量
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param welIds
	 *            井站id（多个）
	 * @return json格式，例如： { "legendData": [ "井站上报", "整改通知", "安全检查" ], "valueData": [
	 *         { "name": "井站上报", "value": 141 }, { "name": "整改通知", "value": 61 }, {
	 *         "name": "安全检查", "value": 33 } ] }
	 */
	@RequestMapping(value = "/getCountBySource", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getCountBySource(@RequestParam("beginDate") String beginDate, @RequestParam("endDate") String endDate,
			@RequestParam("welIds") String welIds) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welIds);
		return problemAnalyzeService.getCountBySource(condition).toString();

	}

	/**
	 * 获取各个井站上报问题的质量
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return json格式，例如： { "seriesData": [ { "data": [ 35.93, 68.96, 5.34, 51.57,
	 *         1.12, 55, 33.91 ], "name": "磨溪22井", "type": "parallel" }, { "data": [
	 *         22.86, 57.2, 54.04, 61.32, 2.81, 96, 44.09 ], "name": "磨溪109井",
	 *         "type": "parallel" }, { "data": [ 76.95, 34.02, 49.74, 86.15, 1.6,
	 *         49, 50.97 ], "name": "磨溪009-4-X1井", "type": "parallel" } ],
	 *         "legendData": [ "磨溪22井", "磨溪109井", "磨溪009-4-X1井" ] , "tableDatas":[{
	 *         "welStation" : "磨溪22井", "countOfPictureRate" : "12.9%",
	 *         "countOfVoiceRate" : "36.08%", "problemGrade" : 73.13,
	 *         "countOfDelByselfRate" : "93.97%", "countOfReDeviceRate" : "89.14%",
	 *         "numOfDesc" : 71, "countRate" : "23.46%" }, { "welStation" :
	 *         "磨溪109井", "countOfPictureRate" : "28.84%", "countOfVoiceRate" :
	 *         "29.92%", "problemGrade" : 54.75, "countOfDelByselfRate" : "37.5%",
	 *         "countOfReDeviceRate" : "69.83%", "numOfDesc" : 18, "countRate" :
	 *         "79.55%" }, { "welStation" : "磨溪009-4-X1井", "countOfPictureRate" :
	 *         "27.19%", "countOfVoiceRate" : "32.17%", "problemGrade" : 50.6,
	 *         "countOfDelByselfRate" : "69.02%", "countOfReDeviceRate" : "52.63%",
	 *         "numOfDesc" : 14, "countRate" : "47.37%" }] }
	 */

	@RequestMapping(value = "/getProblemQuality", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getProblemQuality(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return problemAnalyzeService.getProblemQuality(condition).toString();

	}

	/**
	 * 获取所有井站处理问题时各个节点的平均处理时间
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return json格式，例如： { "nameData": [ "问题上报", "问题上报人（闭环销项）", "调度室",
	 *         "任务接收人（执行现场整改）", "QHSE办公室", "专业技术岗（验证问题是否已按要求整改）",
	 *         "专业技术岗（分级任务-调用子流程）", "部门负责人" ], "valueData": [ 1.54, 1.54, 13.49,
	 *         13.49, 13.51, 13.53, 13.53, 13.54 ] }
	 */
	@RequestMapping(value = "/getTimeCostOfProblemNode", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getTimeCostOfProblemNode(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return problemAnalyzeService.getTimeCostOfProblemNode(condition).toString();

	}

	/**
	 * 获取每个问题处理的每个节点花费的时间
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return json格式，例如：{ "data" : [[20.33, 12.51, 23.98, 7.49, 11.14, 20.63,
	 *         1.93], [3.77, 7, 11.49, 6.34, 20.12, 4.4, 0.74], [17.72, 12.1, 8.22,
	 *         8.11, 3.16, 5.92, 0.57]] }
	 */
	@RequestMapping(value = "/getTimeCostOfEveryProblemNode", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getTimeCostOfEveryProblemNode(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return problemAnalyzeService.getTimeCostOfEveryProblemNode(condition).toString();
	}

	/**
	 * 获取问题处理各个环节每个员工的处理平均时间
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return json格式，例如: { "seriesData": [ [ 0, 6, 1.52 ], [ 1, 1, 13.37 ], [ 2, 4,
	 *         13.59 ], [ 3, 2, 13.52 ], [ 6, 5, 13.45 ], [ 7, 4, 13.49 ], [ 8, 3,
	 *         13.47 ], [ 9, 6, 1.55 ], [ 10, 3, 13.52 ], [ 11, 6, 1.55 ], [ 13, 1,
	 *         13.31 ], [ 14, 0, 13.5 ], [ 15, 1, 13.6 ], [ 16, 0, 13.42 ], [ 17, 3,
	 *         13.45 ], [ 18, 5, 13.51 ], [ 19, 2, 13.32 ], [ 20, 4, 13.49 ], [ 21,
	 *         5, 13.42 ], [ 22, 2, 13.54 ], [ 23, 0, 13.47 ] ], "yAxis3DData": [
	 *         "调度室", "QHSE办公室", "部门负责人", "专业技术岗（分级任务-调用子流程）", "任务接收人（执行现场整改）",
	 *         "专业技术岗（验证问题是否已按要求整改）", "问题上报人（闭环销项）" ], "xAxis3DData": [ "陈国良", "甘宇",
	 *         "陈尔庆", "何小平", "聂军", "周昀阳", "陈明均", "蔡永良", "陈强", "张玉冰", "王亚辉", "廖丽君",
	 *         "张冰晶", "刘涛", "涂涵翌", "孙小虎", "蒋树林", "陈林", "张洁", "戴巍", "李波", "刘业俊",
	 *         "曾忱", "何海洋" ] }
	 */
	@RequestMapping(value = "/getPeopleEfficiencyOfProblem", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getPeopleEfficiencyOfProblem(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, null);
		return problemAnalyzeService.getPeopleEfficiencyOfProblem(condition).toString();
	}

}
