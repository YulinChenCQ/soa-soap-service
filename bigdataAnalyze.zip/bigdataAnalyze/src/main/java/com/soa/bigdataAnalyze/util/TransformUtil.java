
/**
 * <一句话功能描述>
 * <p>转换格式工具类
 * @author 陈宇林
 * @version [版本号, 2018年11月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TransformUtil {
	
	/**
	 * 将字符串转换为List,元素之间需用逗号隔开，如：
	 * "1,2,3,4"->['1','2','3','4']
	 * @param listStr
	 * @return
	 */
	public static List<String> strToList(String listStr){
		
		if(listStr == null || "".equals(listStr) || listStr.isEmpty()) {
			return null;
		}
		List<String> reList = new ArrayList<String>();
		String [] strs = listStr.split(",");
		reList = Arrays.asList(strs);
		return reList;
	};

}
