package com.soa.bigdataAnalyze.entity;

import java.util.ArrayList;
import java.util.List;

public class BiEquipmentRecordExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public BiEquipmentRecordExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andEquIdIsNull() {
            addCriterion("EQU_ID is null");
            return (Criteria) this;
        }

        public Criteria andEquIdIsNotNull() {
            addCriterion("EQU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andEquIdEqualTo(String value) {
            addCriterion("EQU_ID =", value, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdNotEqualTo(String value) {
            addCriterion("EQU_ID <>", value, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdGreaterThan(String value) {
            addCriterion("EQU_ID >", value, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdGreaterThanOrEqualTo(String value) {
            addCriterion("EQU_ID >=", value, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdLessThan(String value) {
            addCriterion("EQU_ID <", value, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdLessThanOrEqualTo(String value) {
            addCriterion("EQU_ID <=", value, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdLike(String value) {
            addCriterion("EQU_ID like", value, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdNotLike(String value) {
            addCriterion("EQU_ID not like", value, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdIn(List<String> values) {
            addCriterion("EQU_ID in", values, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdNotIn(List<String> values) {
            addCriterion("EQU_ID not in", values, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdBetween(String value1, String value2) {
            addCriterion("EQU_ID between", value1, value2, "equId");
            return (Criteria) this;
        }

        public Criteria andEquIdNotBetween(String value1, String value2) {
            addCriterion("EQU_ID not between", value1, value2, "equId");
            return (Criteria) this;
        }

        public Criteria andOperationNumIsNull() {
            addCriterion("OPERATION_NUM is null");
            return (Criteria) this;
        }

        public Criteria andOperationNumIsNotNull() {
            addCriterion("OPERATION_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andOperationNumEqualTo(Long value) {
            addCriterion("OPERATION_NUM =", value, "operationNum");
            return (Criteria) this;
        }

        public Criteria andOperationNumNotEqualTo(Long value) {
            addCriterion("OPERATION_NUM <>", value, "operationNum");
            return (Criteria) this;
        }

        public Criteria andOperationNumGreaterThan(Long value) {
            addCriterion("OPERATION_NUM >", value, "operationNum");
            return (Criteria) this;
        }

        public Criteria andOperationNumGreaterThanOrEqualTo(Long value) {
            addCriterion("OPERATION_NUM >=", value, "operationNum");
            return (Criteria) this;
        }

        public Criteria andOperationNumLessThan(Long value) {
            addCriterion("OPERATION_NUM <", value, "operationNum");
            return (Criteria) this;
        }

        public Criteria andOperationNumLessThanOrEqualTo(Long value) {
            addCriterion("OPERATION_NUM <=", value, "operationNum");
            return (Criteria) this;
        }

        public Criteria andOperationNumIn(List<Long> values) {
            addCriterion("OPERATION_NUM in", values, "operationNum");
            return (Criteria) this;
        }

        public Criteria andOperationNumNotIn(List<Long> values) {
            addCriterion("OPERATION_NUM not in", values, "operationNum");
            return (Criteria) this;
        }

        public Criteria andOperationNumBetween(Long value1, Long value2) {
            addCriterion("OPERATION_NUM between", value1, value2, "operationNum");
            return (Criteria) this;
        }

        public Criteria andOperationNumNotBetween(Long value1, Long value2) {
            addCriterion("OPERATION_NUM not between", value1, value2, "operationNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumIsNull() {
            addCriterion("EXCEPTION_NUM is null");
            return (Criteria) this;
        }

        public Criteria andExceptionNumIsNotNull() {
            addCriterion("EXCEPTION_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andExceptionNumEqualTo(Long value) {
            addCriterion("EXCEPTION_NUM =", value, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumNotEqualTo(Long value) {
            addCriterion("EXCEPTION_NUM <>", value, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumGreaterThan(Long value) {
            addCriterion("EXCEPTION_NUM >", value, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumGreaterThanOrEqualTo(Long value) {
            addCriterion("EXCEPTION_NUM >=", value, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumLessThan(Long value) {
            addCriterion("EXCEPTION_NUM <", value, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumLessThanOrEqualTo(Long value) {
            addCriterion("EXCEPTION_NUM <=", value, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumIn(List<Long> values) {
            addCriterion("EXCEPTION_NUM in", values, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumNotIn(List<Long> values) {
            addCriterion("EXCEPTION_NUM not in", values, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumBetween(Long value1, Long value2) {
            addCriterion("EXCEPTION_NUM between", value1, value2, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andExceptionNumNotBetween(Long value1, Long value2) {
            addCriterion("EXCEPTION_NUM not between", value1, value2, "exceptionNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumIsNull() {
            addCriterion("TENDING_NUM is null");
            return (Criteria) this;
        }

        public Criteria andTendingNumIsNotNull() {
            addCriterion("TENDING_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andTendingNumEqualTo(Long value) {
            addCriterion("TENDING_NUM =", value, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumNotEqualTo(Long value) {
            addCriterion("TENDING_NUM <>", value, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumGreaterThan(Long value) {
            addCriterion("TENDING_NUM >", value, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumGreaterThanOrEqualTo(Long value) {
            addCriterion("TENDING_NUM >=", value, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumLessThan(Long value) {
            addCriterion("TENDING_NUM <", value, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumLessThanOrEqualTo(Long value) {
            addCriterion("TENDING_NUM <=", value, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumIn(List<Long> values) {
            addCriterion("TENDING_NUM in", values, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumNotIn(List<Long> values) {
            addCriterion("TENDING_NUM not in", values, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumBetween(Long value1, Long value2) {
            addCriterion("TENDING_NUM between", value1, value2, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andTendingNumNotBetween(Long value1, Long value2) {
            addCriterion("TENDING_NUM not between", value1, value2, "tendingNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumIsNull() {
            addCriterion("MAINTAIN_NUM is null");
            return (Criteria) this;
        }

        public Criteria andMaintainNumIsNotNull() {
            addCriterion("MAINTAIN_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andMaintainNumEqualTo(Long value) {
            addCriterion("MAINTAIN_NUM =", value, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumNotEqualTo(Long value) {
            addCriterion("MAINTAIN_NUM <>", value, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumGreaterThan(Long value) {
            addCriterion("MAINTAIN_NUM >", value, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumGreaterThanOrEqualTo(Long value) {
            addCriterion("MAINTAIN_NUM >=", value, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumLessThan(Long value) {
            addCriterion("MAINTAIN_NUM <", value, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumLessThanOrEqualTo(Long value) {
            addCriterion("MAINTAIN_NUM <=", value, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumIn(List<Long> values) {
            addCriterion("MAINTAIN_NUM in", values, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumNotIn(List<Long> values) {
            addCriterion("MAINTAIN_NUM not in", values, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumBetween(Long value1, Long value2) {
            addCriterion("MAINTAIN_NUM between", value1, value2, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andMaintainNumNotBetween(Long value1, Long value2) {
            addCriterion("MAINTAIN_NUM not between", value1, value2, "maintainNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumIsNull() {
            addCriterion("VERIFY_NUM is null");
            return (Criteria) this;
        }

        public Criteria andVerifyNumIsNotNull() {
            addCriterion("VERIFY_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andVerifyNumEqualTo(Long value) {
            addCriterion("VERIFY_NUM =", value, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumNotEqualTo(Long value) {
            addCriterion("VERIFY_NUM <>", value, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumGreaterThan(Long value) {
            addCriterion("VERIFY_NUM >", value, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumGreaterThanOrEqualTo(Long value) {
            addCriterion("VERIFY_NUM >=", value, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumLessThan(Long value) {
            addCriterion("VERIFY_NUM <", value, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumLessThanOrEqualTo(Long value) {
            addCriterion("VERIFY_NUM <=", value, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumIn(List<Long> values) {
            addCriterion("VERIFY_NUM in", values, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumNotIn(List<Long> values) {
            addCriterion("VERIFY_NUM not in", values, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumBetween(Long value1, Long value2) {
            addCriterion("VERIFY_NUM between", value1, value2, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andVerifyNumNotBetween(Long value1, Long value2) {
            addCriterion("VERIFY_NUM not between", value1, value2, "verifyNum");
            return (Criteria) this;
        }

        public Criteria andIfVerifyIsNull() {
            addCriterion("IF_VERIFY is null");
            return (Criteria) this;
        }

        public Criteria andIfVerifyIsNotNull() {
            addCriterion("IF_VERIFY is not null");
            return (Criteria) this;
        }

        public Criteria andIfVerifyEqualTo(String value) {
            addCriterion("IF_VERIFY =", value, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyNotEqualTo(String value) {
            addCriterion("IF_VERIFY <>", value, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyGreaterThan(String value) {
            addCriterion("IF_VERIFY >", value, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyGreaterThanOrEqualTo(String value) {
            addCriterion("IF_VERIFY >=", value, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyLessThan(String value) {
            addCriterion("IF_VERIFY <", value, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyLessThanOrEqualTo(String value) {
            addCriterion("IF_VERIFY <=", value, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyLike(String value) {
            addCriterion("IF_VERIFY like", value, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyNotLike(String value) {
            addCriterion("IF_VERIFY not like", value, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyIn(List<String> values) {
            addCriterion("IF_VERIFY in", values, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyNotIn(List<String> values) {
            addCriterion("IF_VERIFY not in", values, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyBetween(String value1, String value2) {
            addCriterion("IF_VERIFY between", value1, value2, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andIfVerifyNotBetween(String value1, String value2) {
            addCriterion("IF_VERIFY not between", value1, value2, "ifVerify");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIsNull() {
            addCriterion("STANDBY_ONE is null");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIsNotNull() {
            addCriterion("STANDBY_ONE is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyOneEqualTo(String value) {
            addCriterion("STANDBY_ONE =", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotEqualTo(String value) {
            addCriterion("STANDBY_ONE <>", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneGreaterThan(String value) {
            addCriterion("STANDBY_ONE >", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_ONE >=", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLessThan(String value) {
            addCriterion("STANDBY_ONE <", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_ONE <=", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLike(String value) {
            addCriterion("STANDBY_ONE like", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotLike(String value) {
            addCriterion("STANDBY_ONE not like", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIn(List<String> values) {
            addCriterion("STANDBY_ONE in", values, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotIn(List<String> values) {
            addCriterion("STANDBY_ONE not in", values, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneBetween(String value1, String value2) {
            addCriterion("STANDBY_ONE between", value1, value2, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotBetween(String value1, String value2) {
            addCriterion("STANDBY_ONE not between", value1, value2, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIsNull() {
            addCriterion("STANDBY_TWO is null");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIsNotNull() {
            addCriterion("STANDBY_TWO is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoEqualTo(String value) {
            addCriterion("STANDBY_TWO =", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotEqualTo(String value) {
            addCriterion("STANDBY_TWO <>", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoGreaterThan(String value) {
            addCriterion("STANDBY_TWO >", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_TWO >=", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLessThan(String value) {
            addCriterion("STANDBY_TWO <", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_TWO <=", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLike(String value) {
            addCriterion("STANDBY_TWO like", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotLike(String value) {
            addCriterion("STANDBY_TWO not like", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIn(List<String> values) {
            addCriterion("STANDBY_TWO in", values, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotIn(List<String> values) {
            addCriterion("STANDBY_TWO not in", values, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoBetween(String value1, String value2) {
            addCriterion("STANDBY_TWO between", value1, value2, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotBetween(String value1, String value2) {
            addCriterion("STANDBY_TWO not between", value1, value2, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIsNull() {
            addCriterion("STANDBY_THREE is null");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIsNotNull() {
            addCriterion("STANDBY_THREE is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeEqualTo(String value) {
            addCriterion("STANDBY_THREE =", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotEqualTo(String value) {
            addCriterion("STANDBY_THREE <>", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeGreaterThan(String value) {
            addCriterion("STANDBY_THREE >", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_THREE >=", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLessThan(String value) {
            addCriterion("STANDBY_THREE <", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_THREE <=", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLike(String value) {
            addCriterion("STANDBY_THREE like", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotLike(String value) {
            addCriterion("STANDBY_THREE not like", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIn(List<String> values) {
            addCriterion("STANDBY_THREE in", values, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotIn(List<String> values) {
            addCriterion("STANDBY_THREE not in", values, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeBetween(String value1, String value2) {
            addCriterion("STANDBY_THREE between", value1, value2, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotBetween(String value1, String value2) {
            addCriterion("STANDBY_THREE not between", value1, value2, "standbyThree");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}