package com.soa.bigdataAnalyze.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class BiTaskRecordExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public BiTaskRecordExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andTaskIdIsNull() {
            addCriterion("TASK_ID is null");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNotNull() {
            addCriterion("TASK_ID is not null");
            return (Criteria) this;
        }

        public Criteria andTaskIdEqualTo(String value) {
            addCriterion("TASK_ID =", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotEqualTo(String value) {
            addCriterion("TASK_ID <>", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThan(String value) {
            addCriterion("TASK_ID >", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThanOrEqualTo(String value) {
            addCriterion("TASK_ID >=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThan(String value) {
            addCriterion("TASK_ID <", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThanOrEqualTo(String value) {
            addCriterion("TASK_ID <=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLike(String value) {
            addCriterion("TASK_ID like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotLike(String value) {
            addCriterion("TASK_ID not like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIn(List<String> values) {
            addCriterion("TASK_ID in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotIn(List<String> values) {
            addCriterion("TASK_ID not in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdBetween(String value1, String value2) {
            addCriterion("TASK_ID between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotBetween(String value1, String value2) {
            addCriterion("TASK_ID not between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andRecordDayIsNull() {
            addCriterion("RECORD_DAY is null");
            return (Criteria) this;
        }

        public Criteria andRecordDayIsNotNull() {
            addCriterion("RECORD_DAY is not null");
            return (Criteria) this;
        }

        public Criteria andRecordDayEqualTo(Date value) {
            addCriterionForJDBCDate("RECORD_DAY =", value, "recordDay");
            return (Criteria) this;
        }

        public Criteria andRecordDayNotEqualTo(Date value) {
            addCriterionForJDBCDate("RECORD_DAY <>", value, "recordDay");
            return (Criteria) this;
        }

        public Criteria andRecordDayGreaterThan(Date value) {
            addCriterionForJDBCDate("RECORD_DAY >", value, "recordDay");
            return (Criteria) this;
        }

        public Criteria andRecordDayGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("RECORD_DAY >=", value, "recordDay");
            return (Criteria) this;
        }

        public Criteria andRecordDayLessThan(Date value) {
            addCriterionForJDBCDate("RECORD_DAY <", value, "recordDay");
            return (Criteria) this;
        }

        public Criteria andRecordDayLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("RECORD_DAY <=", value, "recordDay");
            return (Criteria) this;
        }

        public Criteria andRecordDayIn(List<Date> values) {
            addCriterionForJDBCDate("RECORD_DAY in", values, "recordDay");
            return (Criteria) this;
        }

        public Criteria andRecordDayNotIn(List<Date> values) {
            addCriterionForJDBCDate("RECORD_DAY not in", values, "recordDay");
            return (Criteria) this;
        }

        public Criteria andRecordDayBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("RECORD_DAY between", value1, value2, "recordDay");
            return (Criteria) this;
        }

        public Criteria andRecordDayNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("RECORD_DAY not between", value1, value2, "recordDay");
            return (Criteria) this;
        }

        public Criteria andWelStationIsNull() {
            addCriterion("WEL_STATION is null");
            return (Criteria) this;
        }

        public Criteria andWelStationIsNotNull() {
            addCriterion("WEL_STATION is not null");
            return (Criteria) this;
        }

        public Criteria andWelStationEqualTo(String value) {
            addCriterion("WEL_STATION =", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationNotEqualTo(String value) {
            addCriterion("WEL_STATION <>", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationGreaterThan(String value) {
            addCriterion("WEL_STATION >", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationGreaterThanOrEqualTo(String value) {
            addCriterion("WEL_STATION >=", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationLessThan(String value) {
            addCriterion("WEL_STATION <", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationLessThanOrEqualTo(String value) {
            addCriterion("WEL_STATION <=", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationLike(String value) {
            addCriterion("WEL_STATION like", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationNotLike(String value) {
            addCriterion("WEL_STATION not like", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationIn(List<String> values) {
            addCriterion("WEL_STATION in", values, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationNotIn(List<String> values) {
            addCriterion("WEL_STATION not in", values, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationBetween(String value1, String value2) {
            addCriterion("WEL_STATION between", value1, value2, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationNotBetween(String value1, String value2) {
            addCriterion("WEL_STATION not between", value1, value2, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationIdIsNull() {
            addCriterion("WEL_STATION_ID is null");
            return (Criteria) this;
        }

        public Criteria andWelStationIdIsNotNull() {
            addCriterion("WEL_STATION_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWelStationIdEqualTo(String value) {
            addCriterion("WEL_STATION_ID =", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdNotEqualTo(String value) {
            addCriterion("WEL_STATION_ID <>", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdGreaterThan(String value) {
            addCriterion("WEL_STATION_ID >", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdGreaterThanOrEqualTo(String value) {
            addCriterion("WEL_STATION_ID >=", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdLessThan(String value) {
            addCriterion("WEL_STATION_ID <", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdLessThanOrEqualTo(String value) {
            addCriterion("WEL_STATION_ID <=", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdLike(String value) {
            addCriterion("WEL_STATION_ID like", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdNotLike(String value) {
            addCriterion("WEL_STATION_ID not like", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdIn(List<String> values) {
            addCriterion("WEL_STATION_ID in", values, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdNotIn(List<String> values) {
            addCriterion("WEL_STATION_ID not in", values, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdBetween(String value1, String value2) {
            addCriterion("WEL_STATION_ID between", value1, value2, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdNotBetween(String value1, String value2) {
            addCriterion("WEL_STATION_ID not between", value1, value2, "welStationId");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNull() {
            addCriterion("TASK_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNotNull() {
            addCriterion("TASK_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeEqualTo(String value) {
            addCriterion("TASK_TYPE =", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotEqualTo(String value) {
            addCriterion("TASK_TYPE <>", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThan(String value) {
            addCriterion("TASK_TYPE >", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThanOrEqualTo(String value) {
            addCriterion("TASK_TYPE >=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThan(String value) {
            addCriterion("TASK_TYPE <", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThanOrEqualTo(String value) {
            addCriterion("TASK_TYPE <=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLike(String value) {
            addCriterion("TASK_TYPE like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotLike(String value) {
            addCriterion("TASK_TYPE not like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIn(List<String> values) {
            addCriterion("TASK_TYPE in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotIn(List<String> values) {
            addCriterion("TASK_TYPE not in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeBetween(String value1, String value2) {
            addCriterion("TASK_TYPE between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotBetween(String value1, String value2) {
            addCriterion("TASK_TYPE not between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andStepCountIsNull() {
            addCriterion("STEP_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andStepCountIsNotNull() {
            addCriterion("STEP_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andStepCountEqualTo(String value) {
            addCriterion("STEP_COUNT =", value, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountNotEqualTo(String value) {
            addCriterion("STEP_COUNT <>", value, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountGreaterThan(String value) {
            addCriterion("STEP_COUNT >", value, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountGreaterThanOrEqualTo(String value) {
            addCriterion("STEP_COUNT >=", value, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountLessThan(String value) {
            addCriterion("STEP_COUNT <", value, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountLessThanOrEqualTo(String value) {
            addCriterion("STEP_COUNT <=", value, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountLike(String value) {
            addCriterion("STEP_COUNT like", value, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountNotLike(String value) {
            addCriterion("STEP_COUNT not like", value, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountIn(List<String> values) {
            addCriterion("STEP_COUNT in", values, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountNotIn(List<String> values) {
            addCriterion("STEP_COUNT not in", values, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountBetween(String value1, String value2) {
            addCriterion("STEP_COUNT between", value1, value2, "stepCount");
            return (Criteria) this;
        }

        public Criteria andStepCountNotBetween(String value1, String value2) {
            addCriterion("STEP_COUNT not between", value1, value2, "stepCount");
            return (Criteria) this;
        }

        public Criteria andKeyStepIsNull() {
            addCriterion("KEY_STEP is null");
            return (Criteria) this;
        }

        public Criteria andKeyStepIsNotNull() {
            addCriterion("KEY_STEP is not null");
            return (Criteria) this;
        }

        public Criteria andKeyStepEqualTo(String value) {
            addCriterion("KEY_STEP =", value, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepNotEqualTo(String value) {
            addCriterion("KEY_STEP <>", value, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepGreaterThan(String value) {
            addCriterion("KEY_STEP >", value, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepGreaterThanOrEqualTo(String value) {
            addCriterion("KEY_STEP >=", value, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepLessThan(String value) {
            addCriterion("KEY_STEP <", value, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepLessThanOrEqualTo(String value) {
            addCriterion("KEY_STEP <=", value, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepLike(String value) {
            addCriterion("KEY_STEP like", value, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepNotLike(String value) {
            addCriterion("KEY_STEP not like", value, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepIn(List<String> values) {
            addCriterion("KEY_STEP in", values, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepNotIn(List<String> values) {
            addCriterion("KEY_STEP not in", values, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepBetween(String value1, String value2) {
            addCriterion("KEY_STEP between", value1, value2, "keyStep");
            return (Criteria) this;
        }

        public Criteria andKeyStepNotBetween(String value1, String value2) {
            addCriterion("KEY_STEP not between", value1, value2, "keyStep");
            return (Criteria) this;
        }

        public Criteria andPictureCountIsNull() {
            addCriterion("PICTURE_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andPictureCountIsNotNull() {
            addCriterion("PICTURE_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andPictureCountEqualTo(String value) {
            addCriterion("PICTURE_COUNT =", value, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountNotEqualTo(String value) {
            addCriterion("PICTURE_COUNT <>", value, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountGreaterThan(String value) {
            addCriterion("PICTURE_COUNT >", value, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountGreaterThanOrEqualTo(String value) {
            addCriterion("PICTURE_COUNT >=", value, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountLessThan(String value) {
            addCriterion("PICTURE_COUNT <", value, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountLessThanOrEqualTo(String value) {
            addCriterion("PICTURE_COUNT <=", value, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountLike(String value) {
            addCriterion("PICTURE_COUNT like", value, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountNotLike(String value) {
            addCriterion("PICTURE_COUNT not like", value, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountIn(List<String> values) {
            addCriterion("PICTURE_COUNT in", values, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountNotIn(List<String> values) {
            addCriterion("PICTURE_COUNT not in", values, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountBetween(String value1, String value2) {
            addCriterion("PICTURE_COUNT between", value1, value2, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andPictureCountNotBetween(String value1, String value2) {
            addCriterion("PICTURE_COUNT not between", value1, value2, "pictureCount");
            return (Criteria) this;
        }

        public Criteria andDataCountIsNull() {
            addCriterion("DATA_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andDataCountIsNotNull() {
            addCriterion("DATA_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andDataCountEqualTo(String value) {
            addCriterion("DATA_COUNT =", value, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountNotEqualTo(String value) {
            addCriterion("DATA_COUNT <>", value, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountGreaterThan(String value) {
            addCriterion("DATA_COUNT >", value, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_COUNT >=", value, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountLessThan(String value) {
            addCriterion("DATA_COUNT <", value, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountLessThanOrEqualTo(String value) {
            addCriterion("DATA_COUNT <=", value, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountLike(String value) {
            addCriterion("DATA_COUNT like", value, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountNotLike(String value) {
            addCriterion("DATA_COUNT not like", value, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountIn(List<String> values) {
            addCriterion("DATA_COUNT in", values, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountNotIn(List<String> values) {
            addCriterion("DATA_COUNT not in", values, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountBetween(String value1, String value2) {
            addCriterion("DATA_COUNT between", value1, value2, "dataCount");
            return (Criteria) this;
        }

        public Criteria andDataCountNotBetween(String value1, String value2) {
            addCriterion("DATA_COUNT not between", value1, value2, "dataCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountIsNull() {
            addCriterion("RFID_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andRfidCountIsNotNull() {
            addCriterion("RFID_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andRfidCountEqualTo(String value) {
            addCriterion("RFID_COUNT =", value, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountNotEqualTo(String value) {
            addCriterion("RFID_COUNT <>", value, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountGreaterThan(String value) {
            addCriterion("RFID_COUNT >", value, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountGreaterThanOrEqualTo(String value) {
            addCriterion("RFID_COUNT >=", value, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountLessThan(String value) {
            addCriterion("RFID_COUNT <", value, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountLessThanOrEqualTo(String value) {
            addCriterion("RFID_COUNT <=", value, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountLike(String value) {
            addCriterion("RFID_COUNT like", value, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountNotLike(String value) {
            addCriterion("RFID_COUNT not like", value, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountIn(List<String> values) {
            addCriterion("RFID_COUNT in", values, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountNotIn(List<String> values) {
            addCriterion("RFID_COUNT not in", values, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountBetween(String value1, String value2) {
            addCriterion("RFID_COUNT between", value1, value2, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andRfidCountNotBetween(String value1, String value2) {
            addCriterion("RFID_COUNT not between", value1, value2, "rfidCount");
            return (Criteria) this;
        }

        public Criteria andDescCountIsNull() {
            addCriterion("DESC_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andDescCountIsNotNull() {
            addCriterion("DESC_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andDescCountEqualTo(String value) {
            addCriterion("DESC_COUNT =", value, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountNotEqualTo(String value) {
            addCriterion("DESC_COUNT <>", value, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountGreaterThan(String value) {
            addCriterion("DESC_COUNT >", value, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountGreaterThanOrEqualTo(String value) {
            addCriterion("DESC_COUNT >=", value, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountLessThan(String value) {
            addCriterion("DESC_COUNT <", value, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountLessThanOrEqualTo(String value) {
            addCriterion("DESC_COUNT <=", value, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountLike(String value) {
            addCriterion("DESC_COUNT like", value, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountNotLike(String value) {
            addCriterion("DESC_COUNT not like", value, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountIn(List<String> values) {
            addCriterion("DESC_COUNT in", values, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountNotIn(List<String> values) {
            addCriterion("DESC_COUNT not in", values, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountBetween(String value1, String value2) {
            addCriterion("DESC_COUNT between", value1, value2, "descCount");
            return (Criteria) this;
        }

        public Criteria andDescCountNotBetween(String value1, String value2) {
            addCriterion("DESC_COUNT not between", value1, value2, "descCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountIsNull() {
            addCriterion("PROBLEM_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andProblemCountIsNotNull() {
            addCriterion("PROBLEM_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andProblemCountEqualTo(String value) {
            addCriterion("PROBLEM_COUNT =", value, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountNotEqualTo(String value) {
            addCriterion("PROBLEM_COUNT <>", value, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountGreaterThan(String value) {
            addCriterion("PROBLEM_COUNT >", value, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountGreaterThanOrEqualTo(String value) {
            addCriterion("PROBLEM_COUNT >=", value, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountLessThan(String value) {
            addCriterion("PROBLEM_COUNT <", value, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountLessThanOrEqualTo(String value) {
            addCriterion("PROBLEM_COUNT <=", value, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountLike(String value) {
            addCriterion("PROBLEM_COUNT like", value, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountNotLike(String value) {
            addCriterion("PROBLEM_COUNT not like", value, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountIn(List<String> values) {
            addCriterion("PROBLEM_COUNT in", values, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountNotIn(List<String> values) {
            addCriterion("PROBLEM_COUNT not in", values, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountBetween(String value1, String value2) {
            addCriterion("PROBLEM_COUNT between", value1, value2, "problemCount");
            return (Criteria) this;
        }

        public Criteria andProblemCountNotBetween(String value1, String value2) {
            addCriterion("PROBLEM_COUNT not between", value1, value2, "problemCount");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIsNull() {
            addCriterion("STANDBY_ONE is null");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIsNotNull() {
            addCriterion("STANDBY_ONE is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyOneEqualTo(String value) {
            addCriterion("STANDBY_ONE =", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotEqualTo(String value) {
            addCriterion("STANDBY_ONE <>", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneGreaterThan(String value) {
            addCriterion("STANDBY_ONE >", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_ONE >=", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLessThan(String value) {
            addCriterion("STANDBY_ONE <", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_ONE <=", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLike(String value) {
            addCriterion("STANDBY_ONE like", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotLike(String value) {
            addCriterion("STANDBY_ONE not like", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIn(List<String> values) {
            addCriterion("STANDBY_ONE in", values, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotIn(List<String> values) {
            addCriterion("STANDBY_ONE not in", values, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneBetween(String value1, String value2) {
            addCriterion("STANDBY_ONE between", value1, value2, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotBetween(String value1, String value2) {
            addCriterion("STANDBY_ONE not between", value1, value2, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIsNull() {
            addCriterion("STANDBY_TWO is null");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIsNotNull() {
            addCriterion("STANDBY_TWO is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoEqualTo(String value) {
            addCriterion("STANDBY_TWO =", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotEqualTo(String value) {
            addCriterion("STANDBY_TWO <>", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoGreaterThan(String value) {
            addCriterion("STANDBY_TWO >", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_TWO >=", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLessThan(String value) {
            addCriterion("STANDBY_TWO <", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_TWO <=", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLike(String value) {
            addCriterion("STANDBY_TWO like", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotLike(String value) {
            addCriterion("STANDBY_TWO not like", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIn(List<String> values) {
            addCriterion("STANDBY_TWO in", values, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotIn(List<String> values) {
            addCriterion("STANDBY_TWO not in", values, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoBetween(String value1, String value2) {
            addCriterion("STANDBY_TWO between", value1, value2, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotBetween(String value1, String value2) {
            addCriterion("STANDBY_TWO not between", value1, value2, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIsNull() {
            addCriterion("STANDBY_THREE is null");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIsNotNull() {
            addCriterion("STANDBY_THREE is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeEqualTo(String value) {
            addCriterion("STANDBY_THREE =", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotEqualTo(String value) {
            addCriterion("STANDBY_THREE <>", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeGreaterThan(String value) {
            addCriterion("STANDBY_THREE >", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_THREE >=", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLessThan(String value) {
            addCriterion("STANDBY_THREE <", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_THREE <=", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLike(String value) {
            addCriterion("STANDBY_THREE like", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotLike(String value) {
            addCriterion("STANDBY_THREE not like", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIn(List<String> values) {
            addCriterion("STANDBY_THREE in", values, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotIn(List<String> values) {
            addCriterion("STANDBY_THREE not in", values, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeBetween(String value1, String value2) {
            addCriterion("STANDBY_THREE between", value1, value2, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotBetween(String value1, String value2) {
            addCriterion("STANDBY_THREE not between", value1, value2, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andAverageTimeIsNull() {
            addCriterion("AVERAGE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andAverageTimeIsNotNull() {
            addCriterion("AVERAGE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andAverageTimeEqualTo(String value) {
            addCriterion("AVERAGE_TIME =", value, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeNotEqualTo(String value) {
            addCriterion("AVERAGE_TIME <>", value, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeGreaterThan(String value) {
            addCriterion("AVERAGE_TIME >", value, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeGreaterThanOrEqualTo(String value) {
            addCriterion("AVERAGE_TIME >=", value, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeLessThan(String value) {
            addCriterion("AVERAGE_TIME <", value, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeLessThanOrEqualTo(String value) {
            addCriterion("AVERAGE_TIME <=", value, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeLike(String value) {
            addCriterion("AVERAGE_TIME like", value, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeNotLike(String value) {
            addCriterion("AVERAGE_TIME not like", value, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeIn(List<String> values) {
            addCriterion("AVERAGE_TIME in", values, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeNotIn(List<String> values) {
            addCriterion("AVERAGE_TIME not in", values, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeBetween(String value1, String value2) {
            addCriterion("AVERAGE_TIME between", value1, value2, "averageTime");
            return (Criteria) this;
        }

        public Criteria andAverageTimeNotBetween(String value1, String value2) {
            addCriterion("AVERAGE_TIME not between", value1, value2, "averageTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeIsNull() {
            addCriterion("EXCUTE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeIsNotNull() {
            addCriterion("EXCUTE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeEqualTo(String value) {
            addCriterion("EXCUTE_TIME =", value, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeNotEqualTo(String value) {
            addCriterion("EXCUTE_TIME <>", value, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeGreaterThan(String value) {
            addCriterion("EXCUTE_TIME >", value, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeGreaterThanOrEqualTo(String value) {
            addCriterion("EXCUTE_TIME >=", value, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeLessThan(String value) {
            addCriterion("EXCUTE_TIME <", value, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeLessThanOrEqualTo(String value) {
            addCriterion("EXCUTE_TIME <=", value, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeLike(String value) {
            addCriterion("EXCUTE_TIME like", value, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeNotLike(String value) {
            addCriterion("EXCUTE_TIME not like", value, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeIn(List<String> values) {
            addCriterion("EXCUTE_TIME in", values, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeNotIn(List<String> values) {
            addCriterion("EXCUTE_TIME not in", values, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeBetween(String value1, String value2) {
            addCriterion("EXCUTE_TIME between", value1, value2, "excuteTime");
            return (Criteria) this;
        }

        public Criteria andExcuteTimeNotBetween(String value1, String value2) {
            addCriterion("EXCUTE_TIME not between", value1, value2, "excuteTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}