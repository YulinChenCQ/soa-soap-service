package com.soa.bigdataAnalyze.entity;

import java.util.Date;

public class BiTaskRecord {
    private String taskId;

    private Date recordDay;

    private String welStation;

    private String welStationId;

    private String taskType;

    private String stepCount;

    private String keyStep;

    private String pictureCount;

    private String dataCount;

    private String rfidCount;

    private String descCount;

    private String problemCount;

    private String standbyOne;

    private String standbyTwo;

    private String standbyThree;

    private String averageTime;

    private String excuteTime;

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId == null ? null : taskId.trim();
    }

    public Date getRecordDay() {
        return recordDay;
    }

    public void setRecordDay(Date recordDay) {
        this.recordDay = recordDay;
    }

    public String getWelStation() {
        return welStation;
    }

    public void setWelStation(String welStation) {
        this.welStation = welStation == null ? null : welStation.trim();
    }

    public String getWelStationId() {
        return welStationId;
    }

    public void setWelStationId(String welStationId) {
        this.welStationId = welStationId == null ? null : welStationId.trim();
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }

    public String getStepCount() {
        return stepCount;
    }

    public void setStepCount(String stepCount) {
        this.stepCount = stepCount == null ? null : stepCount.trim();
    }

    public String getKeyStep() {
        return keyStep;
    }

    public void setKeyStep(String keyStep) {
        this.keyStep = keyStep == null ? null : keyStep.trim();
    }

    public String getPictureCount() {
        return pictureCount;
    }

    public void setPictureCount(String pictureCount) {
        this.pictureCount = pictureCount == null ? null : pictureCount.trim();
    }

    public String getDataCount() {
        return dataCount;
    }

    public void setDataCount(String dataCount) {
        this.dataCount = dataCount == null ? null : dataCount.trim();
    }

    public String getRfidCount() {
        return rfidCount;
    }

    public void setRfidCount(String rfidCount) {
        this.rfidCount = rfidCount == null ? null : rfidCount.trim();
    }

    public String getDescCount() {
        return descCount;
    }

    public void setDescCount(String descCount) {
        this.descCount = descCount == null ? null : descCount.trim();
    }

    public String getProblemCount() {
        return problemCount;
    }

    public void setProblemCount(String problemCount) {
        this.problemCount = problemCount == null ? null : problemCount.trim();
    }

    public String getStandbyOne() {
        return standbyOne;
    }

    public void setStandbyOne(String standbyOne) {
        this.standbyOne = standbyOne == null ? null : standbyOne.trim();
    }

    public String getStandbyTwo() {
        return standbyTwo;
    }

    public void setStandbyTwo(String standbyTwo) {
        this.standbyTwo = standbyTwo == null ? null : standbyTwo.trim();
    }

    public String getStandbyThree() {
        return standbyThree;
    }

    public void setStandbyThree(String standbyThree) {
        this.standbyThree = standbyThree == null ? null : standbyThree.trim();
    }

    public String getAverageTime() {
        return averageTime;
    }

    public void setAverageTime(String averageTime) {
        this.averageTime = averageTime == null ? null : averageTime.trim();
    }

    public String getExcuteTime() {
        return excuteTime;
    }

    public void setExcuteTime(String excuteTime) {
        this.excuteTime = excuteTime == null ? null : excuteTime.trim();
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BiTaskRecord [taskId=" + taskId + ", recordDay=" + recordDay + ", welStation=" + welStation
				+ ", welStationId=" + welStationId + ", taskType=" + taskType + ", stepCount=" + stepCount
				+ ", keyStep=" + keyStep + ", pictureCount=" + pictureCount + ", dataCount=" + dataCount
				+ ", rfidCount=" + rfidCount + ", descCount=" + descCount + ", problemCount=" + problemCount
				+ ", standbyOne=" + standbyOne + ", standbyTwo=" + standbyTwo + ", standbyThree=" + standbyThree
				+ ", averageTime=" + averageTime + ", excuteTime=" + excuteTime + "]";
	}
}