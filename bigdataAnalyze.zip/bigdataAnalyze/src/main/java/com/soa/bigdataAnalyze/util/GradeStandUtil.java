
/**
 * <һ�仰��������>
 * <p>
 * @author ������
 * @version [�汾��, 2018��9��11��]
 * @see [�����/����]
 * @since [��Ʒ/ģ��汾]
 */
package com.soa.bigdataAnalyze.util;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.soa.bigdataAnalyze.entity.BiGradeStand;
import com.soa.bigdataAnalyze.mapper.BiGradeStandMapper;

@Component
public class GradeStandUtil {
	
	
	@Autowired
	private  BiGradeStandMapper gradeStandMapper;
	
	private static Map<String,Map<String,BiGradeStand>> gradeStandConfig;

	private static GradeStandUtil gradStandUtil;
	
	@PostConstruct
	public void init(){
		gradStandUtil = this;
		gradStandUtil.gradeStandMapper = this.gradeStandMapper;
	}

	
	public static Map<String,Map<String,BiGradeStand>> getGradeStandConfig(){
		
		if(gradeStandConfig == null || gradeStandConfig.isEmpty()) {
			/**
			 * ����Ȩ�أ���׼ֵ��Ϣ��
			 */
			gradeStandConfig = new HashMap<String,Map<String,BiGradeStand>>();
			
			List<BiGradeStand> gradeStands = gradStandUtil.gradeStandMapper.findAll();
			//System.out.println("gradeStands:" + gradeStands);
			
			for(BiGradeStand gradeStand : gradeStands) {
				
				String taskType = gradeStand.getTaskType();
				
				Map<String,BiGradeStand> values = gradeStandConfig.get(taskType);
				
				if(values == null || values.isEmpty()) {
					Map<String,BiGradeStand> newValues = new HashMap<String,BiGradeStand>();
					newValues.put(gradeStand.getDimNameEn(), gradeStand);
					gradeStandConfig.put(taskType, newValues);
				} else {
					values.put(gradeStand.getDimNameEn(), gradeStand);
				}
				
			}
		}
		
		return gradeStandConfig;
	}
	
	/**
	 * ���¼���Ȩ�ء���׼ֵ��Ϣ
	 */
	public static void reloadGradeStand() {
		
		gradeStandConfig = null;
		
		gradeStandConfig = getGradeStandConfig();
		
	}
}
