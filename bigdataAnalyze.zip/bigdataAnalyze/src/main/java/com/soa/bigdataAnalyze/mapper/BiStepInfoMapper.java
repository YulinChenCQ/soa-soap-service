package com.soa.bigdataAnalyze.mapper;

import com.soa.bigdataAnalyze.entity.BiStepInfo;
import com.soa.bigdataAnalyze.entity.BiStepInfoExample;
import com.soa.bigdataAnalyze.entity.QueryCondition;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface BiStepInfoMapper {
    long countByExample(BiStepInfoExample example);

    int deleteByExample(BiStepInfoExample example);

    int insert(BiStepInfo record);

    int insertSelective(BiStepInfo record);

    List<BiStepInfo> selectByExample(BiStepInfoExample example);

    int updateByExampleSelective(@Param("record") BiStepInfo record, @Param("example") BiStepInfoExample example);

    int updateByExample(@Param("record") BiStepInfo record, @Param("example") BiStepInfoExample example);
    
    /**
     * ����taskId��ѯ������صĲ�����Ϣ
     */
    List<BiStepInfo> findStepInfosByTaskIds(@Param("taskIds")List<String> taskIds);
    
    
    /**
     * ��ѯÿ�������ƽ����ʱ
     */
    
    List<Map<String,String>> averageTimeInfo(List<String> taskIds);
    
    
    /**
     * ��ѯ���в�����Ϣ
     */
    List<BiStepInfo> findAllStepInfo();
    
    List<BiStepInfo> findById(@Param("taskId")String taskId);
    
    
}