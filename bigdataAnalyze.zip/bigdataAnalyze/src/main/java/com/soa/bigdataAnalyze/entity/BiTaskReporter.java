package com.soa.bigdataAnalyze.entity;

import java.util.Date;

public class BiTaskReporter {
    private String id;

    private String taskName;

    private String taskDesc;

    private String taskType;

    private Date startTime;

    private Date endTime;

    private String welName;

    private String welId;

    private String taskState;

    private String taskStore;

    private String standbyOne;

    private String standbyTwo;

    private String standbyThree;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName == null ? null : taskName.trim();
    }

    public String getTaskDesc() {
        return taskDesc;
    }

    public void setTaskDesc(String taskDesc) {
        this.taskDesc = taskDesc == null ? null : taskDesc.trim();
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getWelName() {
        return welName;
    }

    public void setWelName(String welName) {
        this.welName = welName == null ? null : welName.trim();
    }

    public String getWelId() {
        return welId;
    }

    public void setWelId(String welId) {
        this.welId = welId == null ? null : welId.trim();
    }

    public String getTaskState() {
        return taskState;
    }

    public void setTaskState(String taskState) {
        this.taskState = taskState == null ? null : taskState.trim();
    }

    public String getTaskStore() {
        return taskStore;
    }

    public void setTaskStore(String taskStore) {
        this.taskStore = taskStore == null ? null : taskStore.trim();
    }

    public String getStandbyOne() {
        return standbyOne;
    }

    public void setStandbyOne(String standbyOne) {
        this.standbyOne = standbyOne == null ? null : standbyOne.trim();
    }

    public String getStandbyTwo() {
        return standbyTwo;
    }

    public void setStandbyTwo(String standbyTwo) {
        this.standbyTwo = standbyTwo == null ? null : standbyTwo.trim();
    }

    public String getStandbyThree() {
        return standbyThree;
    }

    public void setStandbyThree(String standbyThree) {
        this.standbyThree = standbyThree == null ? null : standbyThree.trim();
    }
}