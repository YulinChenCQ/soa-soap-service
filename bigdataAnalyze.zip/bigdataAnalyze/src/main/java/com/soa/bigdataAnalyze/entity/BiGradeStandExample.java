package com.soa.bigdataAnalyze.entity;

import java.util.ArrayList;
import java.util.List;

public class BiGradeStandExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public BiGradeStandExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNull() {
            addCriterion("TASK_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNotNull() {
            addCriterion("TASK_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeEqualTo(String value) {
            addCriterion("TASK_TYPE =", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotEqualTo(String value) {
            addCriterion("TASK_TYPE <>", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThan(String value) {
            addCriterion("TASK_TYPE >", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThanOrEqualTo(String value) {
            addCriterion("TASK_TYPE >=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThan(String value) {
            addCriterion("TASK_TYPE <", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThanOrEqualTo(String value) {
            addCriterion("TASK_TYPE <=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLike(String value) {
            addCriterion("TASK_TYPE like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotLike(String value) {
            addCriterion("TASK_TYPE not like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIn(List<String> values) {
            addCriterion("TASK_TYPE in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotIn(List<String> values) {
            addCriterion("TASK_TYPE not in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeBetween(String value1, String value2) {
            addCriterion("TASK_TYPE between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotBetween(String value1, String value2) {
            addCriterion("TASK_TYPE not between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andWelStationIsNull() {
            addCriterion("WEL_STATION is null");
            return (Criteria) this;
        }

        public Criteria andWelStationIsNotNull() {
            addCriterion("WEL_STATION is not null");
            return (Criteria) this;
        }

        public Criteria andWelStationEqualTo(String value) {
            addCriterion("WEL_STATION =", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationNotEqualTo(String value) {
            addCriterion("WEL_STATION <>", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationGreaterThan(String value) {
            addCriterion("WEL_STATION >", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationGreaterThanOrEqualTo(String value) {
            addCriterion("WEL_STATION >=", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationLessThan(String value) {
            addCriterion("WEL_STATION <", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationLessThanOrEqualTo(String value) {
            addCriterion("WEL_STATION <=", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationLike(String value) {
            addCriterion("WEL_STATION like", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationNotLike(String value) {
            addCriterion("WEL_STATION not like", value, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationIn(List<String> values) {
            addCriterion("WEL_STATION in", values, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationNotIn(List<String> values) {
            addCriterion("WEL_STATION not in", values, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationBetween(String value1, String value2) {
            addCriterion("WEL_STATION between", value1, value2, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationNotBetween(String value1, String value2) {
            addCriterion("WEL_STATION not between", value1, value2, "welStation");
            return (Criteria) this;
        }

        public Criteria andWelStationIdIsNull() {
            addCriterion("WEL_STATION_ID is null");
            return (Criteria) this;
        }

        public Criteria andWelStationIdIsNotNull() {
            addCriterion("WEL_STATION_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWelStationIdEqualTo(String value) {
            addCriterion("WEL_STATION_ID =", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdNotEqualTo(String value) {
            addCriterion("WEL_STATION_ID <>", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdGreaterThan(String value) {
            addCriterion("WEL_STATION_ID >", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdGreaterThanOrEqualTo(String value) {
            addCriterion("WEL_STATION_ID >=", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdLessThan(String value) {
            addCriterion("WEL_STATION_ID <", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdLessThanOrEqualTo(String value) {
            addCriterion("WEL_STATION_ID <=", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdLike(String value) {
            addCriterion("WEL_STATION_ID like", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdNotLike(String value) {
            addCriterion("WEL_STATION_ID not like", value, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdIn(List<String> values) {
            addCriterion("WEL_STATION_ID in", values, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdNotIn(List<String> values) {
            addCriterion("WEL_STATION_ID not in", values, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdBetween(String value1, String value2) {
            addCriterion("WEL_STATION_ID between", value1, value2, "welStationId");
            return (Criteria) this;
        }

        public Criteria andWelStationIdNotBetween(String value1, String value2) {
            addCriterion("WEL_STATION_ID not between", value1, value2, "welStationId");
            return (Criteria) this;
        }

        public Criteria andDimNameIsNull() {
            addCriterion("DIM_NAME is null");
            return (Criteria) this;
        }

        public Criteria andDimNameIsNotNull() {
            addCriterion("DIM_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andDimNameEqualTo(String value) {
            addCriterion("DIM_NAME =", value, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameNotEqualTo(String value) {
            addCriterion("DIM_NAME <>", value, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameGreaterThan(String value) {
            addCriterion("DIM_NAME >", value, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameGreaterThanOrEqualTo(String value) {
            addCriterion("DIM_NAME >=", value, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameLessThan(String value) {
            addCriterion("DIM_NAME <", value, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameLessThanOrEqualTo(String value) {
            addCriterion("DIM_NAME <=", value, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameLike(String value) {
            addCriterion("DIM_NAME like", value, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameNotLike(String value) {
            addCriterion("DIM_NAME not like", value, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameIn(List<String> values) {
            addCriterion("DIM_NAME in", values, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameNotIn(List<String> values) {
            addCriterion("DIM_NAME not in", values, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameBetween(String value1, String value2) {
            addCriterion("DIM_NAME between", value1, value2, "dimName");
            return (Criteria) this;
        }

        public Criteria andDimNameNotBetween(String value1, String value2) {
            addCriterion("DIM_NAME not between", value1, value2, "dimName");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientIsNull() {
            addCriterion("WEIGHT_COEFFICIENT is null");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientIsNotNull() {
            addCriterion("WEIGHT_COEFFICIENT is not null");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientEqualTo(String value) {
            addCriterion("WEIGHT_COEFFICIENT =", value, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientNotEqualTo(String value) {
            addCriterion("WEIGHT_COEFFICIENT <>", value, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientGreaterThan(String value) {
            addCriterion("WEIGHT_COEFFICIENT >", value, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientGreaterThanOrEqualTo(String value) {
            addCriterion("WEIGHT_COEFFICIENT >=", value, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientLessThan(String value) {
            addCriterion("WEIGHT_COEFFICIENT <", value, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientLessThanOrEqualTo(String value) {
            addCriterion("WEIGHT_COEFFICIENT <=", value, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientLike(String value) {
            addCriterion("WEIGHT_COEFFICIENT like", value, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientNotLike(String value) {
            addCriterion("WEIGHT_COEFFICIENT not like", value, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientIn(List<String> values) {
            addCriterion("WEIGHT_COEFFICIENT in", values, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientNotIn(List<String> values) {
            addCriterion("WEIGHT_COEFFICIENT not in", values, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientBetween(String value1, String value2) {
            addCriterion("WEIGHT_COEFFICIENT between", value1, value2, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andWeightCoefficientNotBetween(String value1, String value2) {
            addCriterion("WEIGHT_COEFFICIENT not between", value1, value2, "weightCoefficient");
            return (Criteria) this;
        }

        public Criteria andStandValueIsNull() {
            addCriterion("STAND_VALUE is null");
            return (Criteria) this;
        }

        public Criteria andStandValueIsNotNull() {
            addCriterion("STAND_VALUE is not null");
            return (Criteria) this;
        }

        public Criteria andStandValueEqualTo(String value) {
            addCriterion("STAND_VALUE =", value, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueNotEqualTo(String value) {
            addCriterion("STAND_VALUE <>", value, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueGreaterThan(String value) {
            addCriterion("STAND_VALUE >", value, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueGreaterThanOrEqualTo(String value) {
            addCriterion("STAND_VALUE >=", value, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueLessThan(String value) {
            addCriterion("STAND_VALUE <", value, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueLessThanOrEqualTo(String value) {
            addCriterion("STAND_VALUE <=", value, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueLike(String value) {
            addCriterion("STAND_VALUE like", value, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueNotLike(String value) {
            addCriterion("STAND_VALUE not like", value, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueIn(List<String> values) {
            addCriterion("STAND_VALUE in", values, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueNotIn(List<String> values) {
            addCriterion("STAND_VALUE not in", values, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueBetween(String value1, String value2) {
            addCriterion("STAND_VALUE between", value1, value2, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandValueNotBetween(String value1, String value2) {
            addCriterion("STAND_VALUE not between", value1, value2, "standValue");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIsNull() {
            addCriterion("STANDBY_ONE is null");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIsNotNull() {
            addCriterion("STANDBY_ONE is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyOneEqualTo(String value) {
            addCriterion("STANDBY_ONE =", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotEqualTo(String value) {
            addCriterion("STANDBY_ONE <>", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneGreaterThan(String value) {
            addCriterion("STANDBY_ONE >", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_ONE >=", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLessThan(String value) {
            addCriterion("STANDBY_ONE <", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_ONE <=", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLike(String value) {
            addCriterion("STANDBY_ONE like", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotLike(String value) {
            addCriterion("STANDBY_ONE not like", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIn(List<String> values) {
            addCriterion("STANDBY_ONE in", values, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotIn(List<String> values) {
            addCriterion("STANDBY_ONE not in", values, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneBetween(String value1, String value2) {
            addCriterion("STANDBY_ONE between", value1, value2, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotBetween(String value1, String value2) {
            addCriterion("STANDBY_ONE not between", value1, value2, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIsNull() {
            addCriterion("STANDBY_TWO is null");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIsNotNull() {
            addCriterion("STANDBY_TWO is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoEqualTo(String value) {
            addCriterion("STANDBY_TWO =", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotEqualTo(String value) {
            addCriterion("STANDBY_TWO <>", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoGreaterThan(String value) {
            addCriterion("STANDBY_TWO >", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_TWO >=", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLessThan(String value) {
            addCriterion("STANDBY_TWO <", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_TWO <=", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLike(String value) {
            addCriterion("STANDBY_TWO like", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotLike(String value) {
            addCriterion("STANDBY_TWO not like", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIn(List<String> values) {
            addCriterion("STANDBY_TWO in", values, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotIn(List<String> values) {
            addCriterion("STANDBY_TWO not in", values, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoBetween(String value1, String value2) {
            addCriterion("STANDBY_TWO between", value1, value2, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotBetween(String value1, String value2) {
            addCriterion("STANDBY_TWO not between", value1, value2, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIsNull() {
            addCriterion("STANDBY_THREE is null");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIsNotNull() {
            addCriterion("STANDBY_THREE is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeEqualTo(String value) {
            addCriterion("STANDBY_THREE =", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotEqualTo(String value) {
            addCriterion("STANDBY_THREE <>", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeGreaterThan(String value) {
            addCriterion("STANDBY_THREE >", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_THREE >=", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLessThan(String value) {
            addCriterion("STANDBY_THREE <", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_THREE <=", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLike(String value) {
            addCriterion("STANDBY_THREE like", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotLike(String value) {
            addCriterion("STANDBY_THREE not like", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIn(List<String> values) {
            addCriterion("STANDBY_THREE in", values, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotIn(List<String> values) {
            addCriterion("STANDBY_THREE not in", values, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeBetween(String value1, String value2) {
            addCriterion("STANDBY_THREE between", value1, value2, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotBetween(String value1, String value2) {
            addCriterion("STANDBY_THREE not between", value1, value2, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andDimNameEnIsNull() {
            addCriterion("DIM_NAME_EN is null");
            return (Criteria) this;
        }

        public Criteria andDimNameEnIsNotNull() {
            addCriterion("DIM_NAME_EN is not null");
            return (Criteria) this;
        }

        public Criteria andDimNameEnEqualTo(String value) {
            addCriterion("DIM_NAME_EN =", value, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnNotEqualTo(String value) {
            addCriterion("DIM_NAME_EN <>", value, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnGreaterThan(String value) {
            addCriterion("DIM_NAME_EN >", value, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnGreaterThanOrEqualTo(String value) {
            addCriterion("DIM_NAME_EN >=", value, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnLessThan(String value) {
            addCriterion("DIM_NAME_EN <", value, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnLessThanOrEqualTo(String value) {
            addCriterion("DIM_NAME_EN <=", value, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnLike(String value) {
            addCriterion("DIM_NAME_EN like", value, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnNotLike(String value) {
            addCriterion("DIM_NAME_EN not like", value, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnIn(List<String> values) {
            addCriterion("DIM_NAME_EN in", values, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnNotIn(List<String> values) {
            addCriterion("DIM_NAME_EN not in", values, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnBetween(String value1, String value2) {
            addCriterion("DIM_NAME_EN between", value1, value2, "dimNameEn");
            return (Criteria) this;
        }

        public Criteria andDimNameEnNotBetween(String value1, String value2) {
            addCriterion("DIM_NAME_EN not between", value1, value2, "dimNameEn");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}