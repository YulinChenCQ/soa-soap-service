
/**
 * <һ�仰��������>
 * <p>
 * @author ������
 * @version [�汾��, 2018��9��18��]
 * @see [�����/����]
 * @since [��Ʒ/ģ��汾]
 */
package com.soa.bigdataAnalyze.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.json.JSONException;
import org.json.JSONObject;

import com.soa.bigdataAnalyze.entity.BiStepInfo;

public class DataFactoryUtil {

	public static List<BiStepInfo> getStepInfosByTaskIds(List<String> taskIds, String taskType) {
		List<BiStepInfo> stepInfos = new ArrayList<BiStepInfo>();

		/*
		 * int num = 3;
		 * 
		 * switch (Integer.parseInt(taskType)) { case 1: num = 3; break; case 3: num =
		 * 3; break; case 4: num = 5; break; case 6: num = 2; break;
		 * 
		 * default: break; }
		 * 
		 * num = 60;
		 */

		int num = 0;
		for (String taskId : taskIds) {

			num++;
			for (int i = 1; i <= 150; i++) {
				BiStepInfo stepInfo = new BiStepInfo();
				stepInfo.setStepName(i + "");
				stepInfo.setTaskId(taskId);
				stepInfos.add(stepInfo);
				if (i < 30) {

					if (num % 15 == 0) {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 59 + 1) + ""), 2) + "");
					} else {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 20 + 20) + ""), 2) + "");
					}
				} else if (30 <= i && i < 60) {
					if (num % 15 == 0) {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 59 + 1) + ""), 2) + "");
					} else {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 30 + 30) + ""), 2) + "");
					}
				} else if (60 <= i && i < 90) {
					if (num % 15 == 0) {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 59 + 1) + ""), 2) + "");
					} else {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 40 + 10) + ""), 2) + "");
					}
				} else if (90 <= i && i < 120) {
					if (num % 15 == 0) {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 59 + 1) + ""), 2) + "");
					} else {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 30 + 20) + ""), 2) + "");
					}
				} else if (120 <= i && i < 150) {
					if (num % 15 == 0) {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 59 + 1) + ""), 2) + "");
					} else {
						stepInfo.setExecutionTime(
								MathUtil.getRound(Double.parseDouble((Math.random() * 25 + 10) + ""), 2) + "");
					}
				}

			}
		}

		return stepInfos;

	}

	/**
	 * ��������������͵�ƽ���÷�
	 * 
	 * @return
	 */
	public static JSONObject createScoreOfTaskTypeData() {
		JSONObject reJo = new JSONObject();
		List<String> dataList = new ArrayList<String>();
		for (int i = 0; i < 5; i++) {
			dataList.add(String.format("%.2f", (Math.random() * 30 + 71)) + "");
		}
		try {
			reJo.put("valueData", dataList);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	public static void main(String[] args) {
		JSONObject reJo = createScoreOfTaskTypeData();
		System.out.println(reJo);
	}

}
