
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年9月7日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.json.JsonArray;
import javax.script.ScriptException;

import org.apache.ibatis.annotations.Param;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soa.bigdataAnalyze.entity.BiStepInfo;
import com.soa.bigdataAnalyze.entity.BiTaskRecord;
import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.entity.TaskRecord;
import com.soa.bigdataAnalyze.mapper.BiStepInfoMapper;
import com.soa.bigdataAnalyze.mapper.BiTaskRecordMapper;
import com.soa.bigdataAnalyze.util.DataFactoryUtil;
import com.soa.bigdataAnalyze.util.DataHandleUtil;
import com.soa.bigdataAnalyze.util.MathUtil;
import com.soa.bigdataAnalyze.util.TaskType;
import com.soa.bigdataAnalyze.util.TimeUtil;

@Service
public class TaskService {

	
	@Autowired
	private BiTaskRecordMapper taskRecordMapper ;
	
	@Autowired
	private BiStepInfoMapper stepInfoMapper;
	/**
	 * @param condition 查询条件
	 * @param flag 是否需要判断是否查询步骤信息标志
	 * @return
	 */
	public JSONObject getSingleWelTaskInfo(QueryCondition condition,boolean flag) {
		
		
		
		/**
		 * 根据条件查询所有的任务记录
		 */
		List<BiTaskRecord> taskRecords = taskRecordMapper.findTaskRecordByDateAndTypeAndWel(condition);
		System.out.println("taskRecords: "+taskRecords);
		/**
		 * 找出所有的任务id，并根据任务id查询出所有的相关的步骤记录
		 */
		List<String> taskIds = new ArrayList<String>();
		for(BiTaskRecord taskRecord : taskRecords) {
			taskIds.add(taskRecord.getTaskId());
		}
		
		//System.out.println(taskIds);
		
		
		/**
		 * 构造taskRecord
		 */
		List<TaskRecord> records = new ArrayList<TaskRecord>();
		
		List<String> taskNameData = DataHandleUtil.getTaskNameData(condition.getTaskType());//任务图的维度数据
		
		List<List<String>> taskValueData = new ArrayList<List<String>>();//任务图的纵坐标数据
		
		for(BiTaskRecord taskRecord : taskRecords) {
			TaskRecord record = new TaskRecord();
			record.setRecordDay(TimeUtil.format(taskRecord.getRecordDay()));
			record.setDay(TimeUtil.getDay(taskRecord.getRecordDay()));
			record.setWelStation(taskRecord.getWelStation());
			
			record.setStepCount(taskRecord.getStepCount());
			record.setKeyStep(taskRecord.getKeyStep());
			record.setPictureCount(taskRecord.getPictureCount());
			record.setDataCount(taskRecord.getDataCount());
			record.setRfidCount(taskRecord.getRfidCount());
			record.setDescCount(taskRecord.getDescCount());
			record.setProblemCount(taskRecord.getProblemCount());
			record.setAverageTime(taskRecord.getAverageTime());
			
			try {
				record.setResult(Double.parseDouble(DataHandleUtil.CalculateGrage(record, condition.getTaskType())));
			} catch (ScriptException e) {
				e.printStackTrace();
			}
			
			//System.out.println("record.toString():"+record.toString());
			records.add(record);
			
			
			/**
			 * 构造echart数据(任务图)
			 */
			
			taskValueData.add(DataHandleUtil.getValueData(condition.getTaskType(), record));
		}
		
		
		
		JSONObject recordJo = new JSONObject();//数据列表json
		JSONObject taskChartJson = new JSONObject();//任务分析图数据json
		
		
		try {
			JSONArray recordJa = new JSONArray(records.toString());
			recordJo.put("code", "0");
			recordJo.put("msg", "");
			recordJo.put("count",recordJa.length() );
			//System.out.println("records.toString():"+records.toString());
			recordJo.put("data",recordJa );
			
			taskChartJson.put("taskNameData", taskNameData);
			taskChartJson.put("taskValueData", taskValueData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		JSONObject stepChartJson =  new JSONObject();;
		if(flag) {
			/**
			 * 步骤数据:
			 * 巡回检查、属地监督、中心井站动态分析任务、普通井站动态分析任务需要展示步骤图
			 */
			if( "2,5".contains(condition.getTaskType())) {
				//维护保养和临时任务不需要分析步骤数据
				
			} else {
				long time1 = System.currentTimeMillis();
				System.out.println(">>>>>>>>>>>>>>>开始查询步骤信息");
				/*List<BiStepInfo> stepInfos =  stepInfoMapper.findStepInfosByTaskIds(taskIds);*/
				
				List<BiStepInfo> stepInfos = DataFactoryUtil.getStepInfosByTaskIds(taskIds, condition.getTaskType());
				/*List<BiStepInfo> stepInfos  = new ArrayList<BiStepInfo>();
				for(String taskId : taskIds) {
					List<BiStepInfo> stepInfo = stepInfoMapper.findById(taskId);
					stepInfos.addAll(stepInfo);
				}*/
				
				
				System.out.println(">>>>>>>>>>>>>>>查询步骤信息结束");
				long time2 = System.currentTimeMillis();
				System.out.println("查询任务步骤花费时间：" + ((time2-time1)/1000)+"s");
				
				long time3 = System.currentTimeMillis();
				stepChartJson = DataHandleUtil.getStepChartData(stepInfos);
				long time4 = System.currentTimeMillis();
				System.out.println("处理任务步骤花费时间：" + ((time4-time3)/1000)+"s");
			}
		}
		
		
		/**
		 * 构造返回给浏览器的数据
		 */
		
		
		JSONObject returnJo = new JSONObject();
		try {
			returnJo.put("taskRecords", recordJo);
			returnJo.put("taskChart", taskChartJson);
			returnJo.put("stepChart", stepChartJson);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		
		return returnJo;
	}
	/**
	 * @param condition
	 * @param flag 是否加载柱状图信息
	 * @return
	 */
	public JSONObject getMultipleWelTaskInfo(QueryCondition condition,boolean flag) {
		
		/**
		 * 根据条件查询所有的任务记录
		 */
		List<BiTaskRecord> taskRecords = taskRecordMapper.findTaskRecordByDateAndType(condition);
		//System.out.println("taskRecords: "+taskRecords);
		
		/**
		 * 构造taskRecord
		 */
		List<TaskRecord> records = new ArrayList<TaskRecord>();
		
		List<String> taskNameData = DataHandleUtil.getTaskNameData(condition.getTaskType());//任务图的维度数据
		
		
		
		
		
		List<String> welNameList = new ArrayList<String>();//井站名称
		List<Double> finishTimeList = new ArrayList<Double>();//完成时间
		
		JSONObject taskValueData = new JSONObject();//任务图的纵坐标数据
		
		
		
		Map<String,List<Double>> barDatamap = new HashMap<String, List<Double>>();
		for(BiTaskRecord taskRecord : taskRecords) {
			TaskRecord record = new TaskRecord();
			record.setRecordDay(TimeUtil.format(taskRecord.getRecordDay()));
			record.setDay(TimeUtil.getDay(taskRecord.getRecordDay()));
			record.setWelStation(taskRecord.getWelStation());
			
			record.setStepCount(taskRecord.getStepCount());
			record.setKeyStep(taskRecord.getKeyStep());
			record.setPictureCount(taskRecord.getPictureCount());
			record.setDataCount(taskRecord.getDataCount());
			record.setRfidCount(taskRecord.getRfidCount());
			record.setDescCount(taskRecord.getDescCount());
			record.setProblemCount(taskRecord.getProblemCount());
			record.setAverageTime(taskRecord.getAverageTime());
			
			try {
				record.setResult(Double.parseDouble(DataHandleUtil.CalculateGrage(record, condition.getTaskType())));
			} catch (ScriptException e) {
				e.printStackTrace();
			}
			records.add(record);
			
			if(flag) {
				/**
				 * 构造柱状图的数据
				 * 巡检任务、属地监督、中心井站动态分析、普通井站动态分析、等任务需要展示柱状图
				 */
				if(!"2,5".contains(condition.getTaskType())) {
					
					List<Double> excuteTimeList = barDatamap.get(taskRecord.getWelStation());
					if(excuteTimeList == null || excuteTimeList.isEmpty()) {
						excuteTimeList = new ArrayList<Double>();
					}
					excuteTimeList.add(Double.parseDouble(taskRecord.getExcuteTime()));
					barDatamap.put(taskRecord.getWelStation(),excuteTimeList);
				}
			}
			
			
			
			/**
			 * 构造echart数据(任务图)
			 */
			List<String> valueData = DataHandleUtil.getValueData(condition.getTaskType(), record);
			
			String welName = taskRecord.getWelStation();
			JSONArray taskRecordList = null;
			try {
				taskRecordList =  (JSONArray) taskValueData.get(welName);
				/**
				 * 存在
				 */
				taskRecordList.put(valueData);
			} catch (JSONException e) {
				/**
				 * 第一次获取时，为空，会抛这个异常 ，是正常的
				 * 当抛出此异常时,说明对象中不含有该井站的数据
				 */
				taskRecordList = new JSONArray();
				taskRecordList.put(valueData);
			}
			try {
				taskValueData.put(welName, taskRecordList);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		
		/*welNameList.add(taskRecord.getWelStation());
		finishTimeList.add(taskRecord.getExcuteTime());*/
		
	    Set<String> keys = barDatamap.keySet();
	    
	    for(String key : keys) {
	    	List<Double> excuteTimeList = barDatamap.get(key);
	    	
	    	Double totalExcuteTime = Double.parseDouble("0");
	    	for(Double excuteTime : excuteTimeList) {
	    		totalExcuteTime += excuteTime;
	    	}
	    	welNameList.add(key);
	    	finishTimeList.add(MathUtil.getRound(totalExcuteTime/excuteTimeList.size(), 2));
	    	
	    }

		
		JSONObject barChartJson = new JSONObject();
		JSONObject recordJo = new JSONObject();
		JSONObject taskChartJson = new JSONObject();
		try {
			JSONArray recordJa = new JSONArray(records.toString());
			recordJo.put("code", "0");
			recordJo.put("msg", "");
			recordJo.put("count",recordJa.length());
			recordJo.put("data", recordJa);
			
			taskChartJson.put("taskNameData", taskNameData);
			taskChartJson.put("taskValueData", taskValueData);
			
			barChartJson.put("welName", welNameList);
			barChartJson.put("finishTime", finishTimeList);
			
		} catch (JSONException e) {
			e.printStackTrace();
		}

		
		
		
		/**
		 * 构造返回给浏览器的数据
		 */
		
		
		JSONObject returnJo = new JSONObject();
		try {
			returnJo.put("taskRecords", recordJo);
			returnJo.put("taskChart", taskChartJson);
			returnJo.put("barChart", barChartJson);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return returnJo;
		
	}
	
	
	
	
	

}
