
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年9月7日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.entity;

import java.util.Date;

import org.json.JSONException;
import org.json.JSONObject;

public class TaskRecord {
	
	
	private String recordDay;//记录时间
	
	private String day;//记录时间的取日
	
    private String welStation;//所属井站

    private String stepCount;//步骤数量

    private String keyStep;//关键操作步骤数量

    private String pictureCount;//拍摄图片数量

    private String dataCount;//录入数据个数

    private String rfidCount;//扫描标签数量

    private String descCount;//文字描述数量

    private String problemCount;//上报问题数量
    
    private String averageTime;//任务每个步骤完成的平均时间
    
    private Double result;//评分结果

    
	/**
	 * @return the result
	 */
	public Double getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(Double result) {
		this.result = result;
	}

	/**
	 * @return the recordDay
	 */
	public String getRecordDay() {
		return recordDay;
	}

	/**
	 * @return the day
	 */
	public String getDay() {
		return day;
	}

	/**
	 * @return the welStation
	 */
	public String getWelStation() {
		return welStation;
	}

	/**
	 * @return the stepCount
	 */
	public String getStepCount() {
		return stepCount;
	}

	/**
	 * @return the keyStep
	 */
	public String getKeyStep() {
		return keyStep;
	}

	/**
	 * @return the pictureCount
	 */
	public String getPictureCount() {
		return pictureCount;
	}

	/**
	 * @return the dataCount
	 */
	public String getDataCount() {
		return dataCount;
	}

	/**
	 * @return the rfidCount
	 */
	public String getRfidCount() {
		return rfidCount;
	}

	/**
	 * @return the descCount
	 */
	public String getDescCount() {
		return descCount;
	}

	/**
	 * @return the problemCount
	 */
	public String getProblemCount() {
		return problemCount;
	}

	/**
	 * @return the averageTime
	 */
	public String getAverageTime() {
		return averageTime;
	}

	/**
	 * @param recordDay the recordDay to set
	 */
	public void setRecordDay(String recordDay) {
		this.recordDay = recordDay;
	}

	/**
	 * @param day the day to set
	 */
	public void setDay(String day) {
		this.day = day;
	}

	/**
	 * @param welStation the welStation to set
	 */
	public void setWelStation(String welStation) {
		this.welStation = welStation;
	}

	/**
	 * @param stepCount the stepCount to set
	 */
	public void setStepCount(String stepCount) {
		this.stepCount = stepCount;
	}

	/**
	 * @param keyStep the keyStep to set
	 */
	public void setKeyStep(String keyStep) {
		this.keyStep = keyStep;
	}

	/**
	 * @param pictureCount the pictureCount to set
	 */
	public void setPictureCount(String pictureCount) {
		this.pictureCount = pictureCount;
	}

	/**
	 * @param dataCount the dataCount to set
	 */
	public void setDataCount(String dataCount) {
		this.dataCount = dataCount;
	}

	/**
	 * @param rfidCount the rfidCount to set
	 */
	public void setRfidCount(String rfidCount) {
		this.rfidCount = rfidCount;
	}

	/**
	 * @param descCount the descCount to set
	 */
	public void setDescCount(String descCount) {
		this.descCount = descCount;
	}

	/**
	 * @param problemCount the problemCount to set
	 */
	public void setProblemCount(String problemCount) {
		this.problemCount = problemCount;
	}

	/**
	 * @param averageTime the averageTime to set
	 */
	public void setAverageTime(String averageTime) {
		this.averageTime = averageTime;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		
		
/*		private Date recordDay;//记录时间
		
		private String day;//记录时间的取日
		
	    private String welStation;//所属井站

	    private String stepCount;//步骤数量

	    private String keyStep;//关键操作步骤数量

	    private String pictureCount;//拍摄图片数量

	    private String dataCount;//录入数据个数

	    private String rfidCount;//扫描标签数量

	    private String descCount;//文字描述数量

	    private String problemCount;//上报问题数量
	    
	    private String averageTime;//任务每个步骤完成的平均时间
	    
	    private String result;//评分结果
	    
	    
*/		JSONObject jo = new JSONObject();
		try {
			jo.put("recordDay", this.recordDay);
			jo.put("welStation", this.welStation);
			jo.put("stepCount", this.stepCount);
			jo.put("keyStep", this.keyStep);
			jo.put("pictureCount", this.pictureCount);
			jo.put("dataCount", this.dataCount);
			jo.put("rfidCount", this.rfidCount);
			jo.put("descCount", this.descCount);
			jo.put("problemCount", this.problemCount);
			jo.put("averageTime", this.averageTime);
			jo.put("result", this.result);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return jo.toString();
	}
    
    
    
    

}
