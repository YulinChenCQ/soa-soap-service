
/**
 * <一句话功能描述>
 * <p>综合任务大数据分析数据接口
 * @author 陈宇林
 * @version [版本号, 2018年9月25日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.service.SyntheticalTaskService;

@RestController
@RequestMapping("/syntheticalTask")
public class SyntheticalTaskController {

	@Autowired
	private SyntheticalTaskService syntheticalTaskService;

	/**
	 * 获取指定井站id的各种任务类型的数量分布
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param welId
	 *            井站id
	 * @return json格式，例如：[ {value : 10,name : '巡回检查'} , {value : 5,name : '维护保养'} ,
	 *         {value : 15,name : '动态分析'} , {value : 25,name : '临时任务'} , {value :
	 *         20,name : '属地监督'}];
	 */
	@RequestMapping(value = "/getTaskCountOfAllType", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getTaskCountOfAllType(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate, @RequestParam("welId") String welId) {

		//System.out.println(beginDate + "," + endDate + "," + welId);

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welId);

		return syntheticalTaskService.getCountOfAllTaskType(condition).toString();
	}

	/**
	 * 获取指定井站id的各种任务状态的数量分布
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param welId
	 *            井站id
	 * @return json格式 例如：[{"name":"已完成","value":150},{"name":"超期完成","value":3},
	 *         {"name":"超期未完成","value":2},{"name":"即将超期","value":2},{"name":"未完成","value":2}]
	 */
	@RequestMapping(value = "/getTaskCountOfState", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getTaskCountOfState(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate, @RequestParam("welId") String welId) {
		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welId);
		return syntheticalTaskService.getTaskCountOfState(condition).toString();
	}

	/**
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param welId
	 *            井站id
	 * @return json格式，例如：
	 *         {"temporary":[{"name":"已完成","value":91},{"name":"即将超期","value":1}],
	 *         "tending":[{"name":"已完成","value":91},{"name":"未完成","value":3},{"name":"即将超期","value":3}],
	 *         "dynamicAnalysis":[{"name":"已完成","value":91},{"name":"超期完成","value":4},{"name":"超期未完成","value":3},{"name":"未完成","value":1}],
	 *         "inspection":[{"name":"已完成","value":91},{"name":"超期完成","value":1},{"name":"超期未完成","value":1},{"name":"未完成","value":2},{"name":"即将超期","value":2}],
	 *         "territorialSupervision":[{"name":"已完成","value":91},{"name":"超期完成","value":3},{"name":"即将超期","value":1},{"name":"未完成","value":2}]}
	 *         其中： inspection：巡检任务数据 tending：维护保养数据 dynamicAnalysis：动态分析数据
	 *         territorialSupervision：属地监督数据 temporary：临时任务数据 数据为对应任务的各个状态的任务数量
	 * 
	 */
	@RequestMapping(value = "/getTaskCountOfTaskStateByTaskType", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getTaskCountOfTaskStateByTaskType(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate, @RequestParam("welId") String welId) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welId);

		return syntheticalTaskService.getTaskCountOfTaskStateByTaskType(condition).toString();
	}

	/**
	 * 获取指定井站id的任务完成率排名
	 * 
	 * @param welId
	 *            井站id
	 * @param statisticsType
	 *            统计类型：week ->每周 month->每季度 quarter->每季度 halfYear->每半 年 year->每年
	 * @return json格式，如： { "legendData": [ "2019年第2周", "2020年第2周", "2019年第1周",
	 *         "2020年第1周", "2018年第1周", "2020年第4周", "2020年第3周", "2018年第3周",
	 *         "2018年第2周", "2019年第4周", "2018年第4周", "2019年第3周" ], "valueData": [ {
	 *         "name": "2019年第2周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2020年第2周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2019年第1周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2020年第1周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2018年第1周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2020年第4周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2020年第3周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2018年第3周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2018年第2周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2019年第4周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2018年第4周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] }, {
	 *         "name": "2019年第3周", "value": [ 0.96, 0.96, 0.96, 0.96, 0.96 ] } ] }
	 */
	@RequestMapping(value = "/getTaskFinnishRateRank", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getTaskFinnishRateRank(@RequestParam("welId") String welId,
			@RequestParam("statisticsType") String statisticsType) {
		QueryCondition condition = new QueryCondition(null, null, null, welId);
		condition.setStatisticsType(statisticsType);
		return syntheticalTaskService.getTaskFinnishRateRank(condition).toString();
	}

	/**
	 * 获取每种任务的平均得分
	 * 
	 * @param beginDate开始时间
	 * @param endDate
	 *            结束时间
	 * @param welId
	 *            井站id
	 * @return json格式，例如：
	 *         {"nameData":["巡回检查","维护保养","动态分析","临时任务","属地监督"],"valueData":["70.92","72.72","71.92","70.75","70.44"]}
	 */
	@RequestMapping(value = "/getScoreOfTaskType", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getScoreOfTaskType(@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate, @RequestParam("welId") String welId) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, null, welId);

		return syntheticalTaskService.getScoreOfTaskType(condition).toString();
	}

}
