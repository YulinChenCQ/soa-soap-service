package com.soa.bigdataAnalyze.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class BiWellStationExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public BiWellStationExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andBwsIdIsNull() {
            addCriterion("BWS_ID is null");
            return (Criteria) this;
        }

        public Criteria andBwsIdIsNotNull() {
            addCriterion("BWS_ID is not null");
            return (Criteria) this;
        }

        public Criteria andBwsIdEqualTo(String value) {
            addCriterion("BWS_ID =", value, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdNotEqualTo(String value) {
            addCriterion("BWS_ID <>", value, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdGreaterThan(String value) {
            addCriterion("BWS_ID >", value, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdGreaterThanOrEqualTo(String value) {
            addCriterion("BWS_ID >=", value, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdLessThan(String value) {
            addCriterion("BWS_ID <", value, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdLessThanOrEqualTo(String value) {
            addCriterion("BWS_ID <=", value, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdLike(String value) {
            addCriterion("BWS_ID like", value, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdNotLike(String value) {
            addCriterion("BWS_ID not like", value, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdIn(List<String> values) {
            addCriterion("BWS_ID in", values, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdNotIn(List<String> values) {
            addCriterion("BWS_ID not in", values, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdBetween(String value1, String value2) {
            addCriterion("BWS_ID between", value1, value2, "bwsId");
            return (Criteria) this;
        }

        public Criteria andBwsIdNotBetween(String value1, String value2) {
            addCriterion("BWS_ID not between", value1, value2, "bwsId");
            return (Criteria) this;
        }

        public Criteria andWellNumberIsNull() {
            addCriterion("WELL_NUMBER is null");
            return (Criteria) this;
        }

        public Criteria andWellNumberIsNotNull() {
            addCriterion("WELL_NUMBER is not null");
            return (Criteria) this;
        }

        public Criteria andWellNumberEqualTo(String value) {
            addCriterion("WELL_NUMBER =", value, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberNotEqualTo(String value) {
            addCriterion("WELL_NUMBER <>", value, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberGreaterThan(String value) {
            addCriterion("WELL_NUMBER >", value, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberGreaterThanOrEqualTo(String value) {
            addCriterion("WELL_NUMBER >=", value, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberLessThan(String value) {
            addCriterion("WELL_NUMBER <", value, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberLessThanOrEqualTo(String value) {
            addCriterion("WELL_NUMBER <=", value, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberLike(String value) {
            addCriterion("WELL_NUMBER like", value, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberNotLike(String value) {
            addCriterion("WELL_NUMBER not like", value, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberIn(List<String> values) {
            addCriterion("WELL_NUMBER in", values, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberNotIn(List<String> values) {
            addCriterion("WELL_NUMBER not in", values, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberBetween(String value1, String value2) {
            addCriterion("WELL_NUMBER between", value1, value2, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellNumberNotBetween(String value1, String value2) {
            addCriterion("WELL_NUMBER not between", value1, value2, "wellNumber");
            return (Criteria) this;
        }

        public Criteria andWellStationNameIsNull() {
            addCriterion("WELL_STATION_NAME is null");
            return (Criteria) this;
        }

        public Criteria andWellStationNameIsNotNull() {
            addCriterion("WELL_STATION_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andWellStationNameEqualTo(String value) {
            addCriterion("WELL_STATION_NAME =", value, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameNotEqualTo(String value) {
            addCriterion("WELL_STATION_NAME <>", value, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameGreaterThan(String value) {
            addCriterion("WELL_STATION_NAME >", value, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameGreaterThanOrEqualTo(String value) {
            addCriterion("WELL_STATION_NAME >=", value, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameLessThan(String value) {
            addCriterion("WELL_STATION_NAME <", value, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameLessThanOrEqualTo(String value) {
            addCriterion("WELL_STATION_NAME <=", value, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameLike(String value) {
            addCriterion("WELL_STATION_NAME like", value, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameNotLike(String value) {
            addCriterion("WELL_STATION_NAME not like", value, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameIn(List<String> values) {
            addCriterion("WELL_STATION_NAME in", values, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameNotIn(List<String> values) {
            addCriterion("WELL_STATION_NAME not in", values, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameBetween(String value1, String value2) {
            addCriterion("WELL_STATION_NAME between", value1, value2, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andWellStationNameNotBetween(String value1, String value2) {
            addCriterion("WELL_STATION_NAME not between", value1, value2, "wellStationName");
            return (Criteria) this;
        }

        public Criteria andBggsIdIsNull() {
            addCriterion("BGGS_ID is null");
            return (Criteria) this;
        }

        public Criteria andBggsIdIsNotNull() {
            addCriterion("BGGS_ID is not null");
            return (Criteria) this;
        }

        public Criteria andBggsIdEqualTo(String value) {
            addCriterion("BGGS_ID =", value, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdNotEqualTo(String value) {
            addCriterion("BGGS_ID <>", value, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdGreaterThan(String value) {
            addCriterion("BGGS_ID >", value, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdGreaterThanOrEqualTo(String value) {
            addCriterion("BGGS_ID >=", value, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdLessThan(String value) {
            addCriterion("BGGS_ID <", value, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdLessThanOrEqualTo(String value) {
            addCriterion("BGGS_ID <=", value, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdLike(String value) {
            addCriterion("BGGS_ID like", value, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdNotLike(String value) {
            addCriterion("BGGS_ID not like", value, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdIn(List<String> values) {
            addCriterion("BGGS_ID in", values, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdNotIn(List<String> values) {
            addCriterion("BGGS_ID not in", values, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdBetween(String value1, String value2) {
            addCriterion("BGGS_ID between", value1, value2, "bggsId");
            return (Criteria) this;
        }

        public Criteria andBggsIdNotBetween(String value1, String value2) {
            addCriterion("BGGS_ID not between", value1, value2, "bggsId");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameIsNull() {
            addCriterion("GAS_GATHER_STATION_NAME is null");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameIsNotNull() {
            addCriterion("GAS_GATHER_STATION_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameEqualTo(String value) {
            addCriterion("GAS_GATHER_STATION_NAME =", value, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameNotEqualTo(String value) {
            addCriterion("GAS_GATHER_STATION_NAME <>", value, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameGreaterThan(String value) {
            addCriterion("GAS_GATHER_STATION_NAME >", value, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameGreaterThanOrEqualTo(String value) {
            addCriterion("GAS_GATHER_STATION_NAME >=", value, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameLessThan(String value) {
            addCriterion("GAS_GATHER_STATION_NAME <", value, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameLessThanOrEqualTo(String value) {
            addCriterion("GAS_GATHER_STATION_NAME <=", value, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameLike(String value) {
            addCriterion("GAS_GATHER_STATION_NAME like", value, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameNotLike(String value) {
            addCriterion("GAS_GATHER_STATION_NAME not like", value, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameIn(List<String> values) {
            addCriterion("GAS_GATHER_STATION_NAME in", values, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameNotIn(List<String> values) {
            addCriterion("GAS_GATHER_STATION_NAME not in", values, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameBetween(String value1, String value2) {
            addCriterion("GAS_GATHER_STATION_NAME between", value1, value2, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andGasGatherStationNameNotBetween(String value1, String value2) {
            addCriterion("GAS_GATHER_STATION_NAME not between", value1, value2, "gasGatherStationName");
            return (Criteria) this;
        }

        public Criteria andStationTypeIsNull() {
            addCriterion("STATION_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andStationTypeIsNotNull() {
            addCriterion("STATION_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andStationTypeEqualTo(String value) {
            addCriterion("STATION_TYPE =", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeNotEqualTo(String value) {
            addCriterion("STATION_TYPE <>", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeGreaterThan(String value) {
            addCriterion("STATION_TYPE >", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeGreaterThanOrEqualTo(String value) {
            addCriterion("STATION_TYPE >=", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeLessThan(String value) {
            addCriterion("STATION_TYPE <", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeLessThanOrEqualTo(String value) {
            addCriterion("STATION_TYPE <=", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeLike(String value) {
            addCriterion("STATION_TYPE like", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeNotLike(String value) {
            addCriterion("STATION_TYPE not like", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeIn(List<String> values) {
            addCriterion("STATION_TYPE in", values, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeNotIn(List<String> values) {
            addCriterion("STATION_TYPE not in", values, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeBetween(String value1, String value2) {
            addCriterion("STATION_TYPE between", value1, value2, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeNotBetween(String value1, String value2) {
            addCriterion("STATION_TYPE not between", value1, value2, "stationType");
            return (Criteria) this;
        }

        public Criteria andDescriptionIsNull() {
            addCriterion("DESCRIPTION is null");
            return (Criteria) this;
        }

        public Criteria andDescriptionIsNotNull() {
            addCriterion("DESCRIPTION is not null");
            return (Criteria) this;
        }

        public Criteria andDescriptionEqualTo(String value) {
            addCriterion("DESCRIPTION =", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionNotEqualTo(String value) {
            addCriterion("DESCRIPTION <>", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionGreaterThan(String value) {
            addCriterion("DESCRIPTION >", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionGreaterThanOrEqualTo(String value) {
            addCriterion("DESCRIPTION >=", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionLessThan(String value) {
            addCriterion("DESCRIPTION <", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionLessThanOrEqualTo(String value) {
            addCriterion("DESCRIPTION <=", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionLike(String value) {
            addCriterion("DESCRIPTION like", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionNotLike(String value) {
            addCriterion("DESCRIPTION not like", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionIn(List<String> values) {
            addCriterion("DESCRIPTION in", values, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionNotIn(List<String> values) {
            addCriterion("DESCRIPTION not in", values, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionBetween(String value1, String value2) {
            addCriterion("DESCRIPTION between", value1, value2, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionNotBetween(String value1, String value2) {
            addCriterion("DESCRIPTION not between", value1, value2, "description");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterionForJDBCDate("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterionForJDBCDate("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterionForJDBCDate("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterionForJDBCDate("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andRemarkoneIsNull() {
            addCriterion("REMARKONE is null");
            return (Criteria) this;
        }

        public Criteria andRemarkoneIsNotNull() {
            addCriterion("REMARKONE is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkoneEqualTo(String value) {
            addCriterion("REMARKONE =", value, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneNotEqualTo(String value) {
            addCriterion("REMARKONE <>", value, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneGreaterThan(String value) {
            addCriterion("REMARKONE >", value, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneGreaterThanOrEqualTo(String value) {
            addCriterion("REMARKONE >=", value, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneLessThan(String value) {
            addCriterion("REMARKONE <", value, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneLessThanOrEqualTo(String value) {
            addCriterion("REMARKONE <=", value, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneLike(String value) {
            addCriterion("REMARKONE like", value, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneNotLike(String value) {
            addCriterion("REMARKONE not like", value, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneIn(List<String> values) {
            addCriterion("REMARKONE in", values, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneNotIn(List<String> values) {
            addCriterion("REMARKONE not in", values, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneBetween(String value1, String value2) {
            addCriterion("REMARKONE between", value1, value2, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarkoneNotBetween(String value1, String value2) {
            addCriterion("REMARKONE not between", value1, value2, "remarkone");
            return (Criteria) this;
        }

        public Criteria andRemarktwoIsNull() {
            addCriterion("REMARKTWO is null");
            return (Criteria) this;
        }

        public Criteria andRemarktwoIsNotNull() {
            addCriterion("REMARKTWO is not null");
            return (Criteria) this;
        }

        public Criteria andRemarktwoEqualTo(String value) {
            addCriterion("REMARKTWO =", value, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoNotEqualTo(String value) {
            addCriterion("REMARKTWO <>", value, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoGreaterThan(String value) {
            addCriterion("REMARKTWO >", value, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoGreaterThanOrEqualTo(String value) {
            addCriterion("REMARKTWO >=", value, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoLessThan(String value) {
            addCriterion("REMARKTWO <", value, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoLessThanOrEqualTo(String value) {
            addCriterion("REMARKTWO <=", value, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoLike(String value) {
            addCriterion("REMARKTWO like", value, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoNotLike(String value) {
            addCriterion("REMARKTWO not like", value, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoIn(List<String> values) {
            addCriterion("REMARKTWO in", values, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoNotIn(List<String> values) {
            addCriterion("REMARKTWO not in", values, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoBetween(String value1, String value2) {
            addCriterion("REMARKTWO between", value1, value2, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarktwoNotBetween(String value1, String value2) {
            addCriterion("REMARKTWO not between", value1, value2, "remarktwo");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeIsNull() {
            addCriterion("REMARKTHREE is null");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeIsNotNull() {
            addCriterion("REMARKTHREE is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeEqualTo(String value) {
            addCriterion("REMARKTHREE =", value, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeNotEqualTo(String value) {
            addCriterion("REMARKTHREE <>", value, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeGreaterThan(String value) {
            addCriterion("REMARKTHREE >", value, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeGreaterThanOrEqualTo(String value) {
            addCriterion("REMARKTHREE >=", value, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeLessThan(String value) {
            addCriterion("REMARKTHREE <", value, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeLessThanOrEqualTo(String value) {
            addCriterion("REMARKTHREE <=", value, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeLike(String value) {
            addCriterion("REMARKTHREE like", value, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeNotLike(String value) {
            addCriterion("REMARKTHREE not like", value, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeIn(List<String> values) {
            addCriterion("REMARKTHREE in", values, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeNotIn(List<String> values) {
            addCriterion("REMARKTHREE not in", values, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeBetween(String value1, String value2) {
            addCriterion("REMARKTHREE between", value1, value2, "remarkthree");
            return (Criteria) this;
        }

        public Criteria andRemarkthreeNotBetween(String value1, String value2) {
            addCriterion("REMARKTHREE not between", value1, value2, "remarkthree");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}