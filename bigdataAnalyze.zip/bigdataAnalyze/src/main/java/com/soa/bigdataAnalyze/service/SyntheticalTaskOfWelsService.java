
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年9月30日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.mapper.BiTaskReporterMapper;
import com.soa.bigdataAnalyze.util.MathUtil;

@Service
public class SyntheticalTaskOfWelsService {

	@Autowired
	private BiTaskReporterMapper taskReporterMapper;

	/**
	 * 获取所有井站每种任务的数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountOfWelByType(QueryCondition condition) {

		long time1 = System.currentTimeMillis();
		List<Map<String, String>> results = taskReporterMapper.findCountOfWelsByType(condition);
		long time2 = System.currentTimeMillis();
		// System.out.println("查询耗时：" + ((time2 - time1) / 1000) + "s");

		Map<String, Map<String, String>> dataMaps = new HashMap<String, Map<String, String>>();
		for (Map<String, String> result : results) {
			String welName = result.get("WEL_NAME");// 井站名称
			Map<String, String> dataMap = dataMaps.get(welName);
			if (dataMap == null || dataMap.isEmpty()) {
				dataMap = new HashMap<String, String>();
			}
			dataMap.put(result.get("TASK_TYPE"), String.valueOf(result.get("NUM")));
			dataMaps.put(welName, dataMap);
		}

		/*
		 * inspection：巡检任务数据 tending：维护保养数据 dynamicAnalysis：动态分析数据
		 * territorialSupervision：属地监督数据 temporary：临时任务数据 数据为对应任务的各个状态的任务数量
		 */

		// 井站名称
		List<String> welList = new ArrayList<String>();

		// 巡检任务数量
		List<Integer> inspectionList = new ArrayList<Integer>();

		// 维护保养任务数量
		List<Integer> tendingList = new ArrayList<Integer>();

		// 动态分析任务数量
		List<Integer> dynamicAnalysisList = new ArrayList<Integer>();

		// 属地监督任务数量
		List<Integer> territorialSupervisionList = new ArrayList<Integer>();

		// 临时任务数量
		List<Integer> temporaryList = new ArrayList<Integer>();

		Set<String> keys = dataMaps.keySet();
		for (String key : keys) {
			Map<String, String> dataMap = dataMaps.get(key);
			welList.add(key);
			inspectionList.add(dataMap.get("1") == null ? 0 : Integer.parseInt(dataMap.get("1")));
			tendingList.add(dataMap.get("2") == null ? 0 : Integer.parseInt(dataMap.get("2")));
			dynamicAnalysisList.add(dataMap.get("3") == null ? 0 : Integer.parseInt(dataMap.get("3")));
			territorialSupervisionList.add(dataMap.get("4") == null ? 0 : Integer.parseInt(dataMap.get("4")));
			temporaryList.add(dataMap.get("5") == null ? 0 : Integer.parseInt(dataMap.get("5")));
		}

		JSONObject reJo = new JSONObject();

		try {
			reJo.put("welName", welList);
			reJo.put("inspection", inspectionList);
			reJo.put("tending", tendingList);
			reJo.put("dynamicAnalysis", dynamicAnalysisList);
			reJo.put("territorialSupervision", territorialSupervisionList);
			reJo.put("temporary", temporaryList);

		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * @param condition
	 * @return
	 */
	public JSONObject getFinishRateOfWelsByType(QueryCondition condition) {

		JSONArray reJa = new JSONArray();

		List<Map<String, String>> results = taskReporterMapper.findAllWelFinishRateByType(condition);

		Map<String, Map<String, String>> dataMaps = new HashMap<String, Map<String, String>>();
		for (Map<String, String> result : results) {
			String welName = result.get("WEL_NAME");// 井站名称
			Map<String, String> dataMap = dataMaps.get(welName);
			if (dataMap == null || dataMap.isEmpty()) {
				dataMap = new HashMap<String, String>();
			}
			dataMap.put(result.get("TASK_TYPE"), String.valueOf(result.get("FINISHRATE")));
			dataMaps.put(welName, dataMap);
		}

		List<String> legendData = new ArrayList<String>();
		Set<String> keys = dataMaps.keySet();
		for (String key : keys) {
			legendData.add(key);
			Map<String, String> dataMap = dataMaps.get(key);
			List<Double> dataList = new ArrayList<Double>();
			dataList.add(Double.parseDouble(dataMap.get("1") == null ? "100" : dataMap.get("1")) * 100);// 巡检任务完成率
			dataList.add(Double.parseDouble(dataMap.get("2") == null ? "100" : dataMap.get("2")) * 100);// 维护保养任务完成率
			dataList.add(Double.parseDouble(dataMap.get("3") == null ? "100" : dataMap.get("3")) * 100);// 动态分析任务完成率
			dataList.add(Double.parseDouble(dataMap.get("4") == null ? "100" : dataMap.get("4")) * 100);// 属地监督任务完成率
			dataList.add(Double.parseDouble(dataMap.get("5") == null ? "100" : dataMap.get("5")) * 100);// 临时任务完成率

			JSONObject jo = new JSONObject();
			try {
				jo.put("name", key);
				jo.put("value", dataList);
				reJa.put(jo);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		JSONObject reJo = new JSONObject();
		try {
			reJo.put("legendData", legendData);
			reJo.put("seriesData", reJa);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * @param condition
	 * @return
	 */
	public JSONObject getTaskScoreOfWels(QueryCondition condition) {

		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = taskReporterMapper.findTaskScoreOfWels(condition);
		Map<String, Map<String, String>> dataMaps = new HashMap<String, Map<String, String>>();
		for (Map<String, String> result : results) {
			String welName = result.get("WEL_NAME");// 井站名称
			Map<String, String> dataMap = dataMaps.get(welName);
			if (dataMap == null || dataMap.isEmpty()) {
				dataMap = new HashMap<String, String>();
			}
			dataMap.put(result.get("TASK_TYPE"), String.valueOf(result.get("TASK_SCORE")));
			dataMaps.put(welName, dataMap);
		}

		Set<String> keys = dataMaps.keySet();
		List<String> legendData = new ArrayList<String>();

		JSONArray dataJa = new JSONArray();
		JSONObject lineStyle = null;
		JSONObject itemStyle = null;
		/**
		 * itemStyle: { normal: {color: ''}}
		 */
		try {
			lineStyle = new JSONObject("{normal: { width: 1,opacity: 0.5}}");
			itemStyle = new JSONObject("{ normal: {}}");
			JSONObject normal = itemStyle.getJSONObject("normal");
			normal.put("color", MathUtil.randomHexStr(63));
			System.out.println(itemStyle.toString());
		} catch (JSONException e1) {
			e1.printStackTrace();
		}
		for (String key : keys) {
			Map<String, String> dataMap = dataMaps.get(key);
			List<Double> dataList = new ArrayList<Double>();
			dataList.add(Double.parseDouble(dataMap.get("1") == null ? "100" : dataMap.get("1")));// 巡检任务平均得分
			dataList.add(Double.parseDouble(dataMap.get("2") == null ? "100" : dataMap.get("2")));// 维护保养任务平均得分
			dataList.add(Double.parseDouble(dataMap.get("3") == null ? "100" : dataMap.get("3")));// 动态分析任务平均得分
			dataList.add(Double.parseDouble(dataMap.get("4") == null ? "100" : dataMap.get("4")));// 属地监督任务平均得分
			dataList.add(Double.parseDouble(dataMap.get("5") == null ? "100" : dataMap.get("5")));// 临时任务平均得分

			legendData.add(key);// 井站名称

			List<List<Double>> seriesData = new ArrayList<List<Double>>();
			seriesData.add(dataList);
			JSONObject jo = new JSONObject();
			try {
				jo.put("name", key);
				jo.put("data", seriesData);
				jo.put("type", "radar");
				jo.put("lineStyle", lineStyle);
				jo.put("itemStyle", itemStyle);
				dataJa.put(jo);
			} catch (JSONException e) {
				e.printStackTrace();
			}

		}

		try {
			reJo.put("legendData", legendData);
			reJo.put("data", dataJa);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * 获取所有井站综合任务得分
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getTaskScore(QueryCondition condition) {

		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = taskReporterMapper.findTaskScore(condition);

		List<String> xData = new ArrayList<String>();// 井站名称数据
		List<Double> yData = new ArrayList<Double>();

		for (Map<String, String> result : results) {
			xData.add(result.get("WEL_NAME"));
			yData.add(Double.parseDouble(String.valueOf(result.get("TASK_SCORE"))));
		}

		try {
			reJo.put("xData", xData);
			reJo.put("yData", yData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * 
	 * 获取所有井站每个月份的数据
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getTaskScoreByMonth(QueryCondition condition) {
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = taskReporterMapper.findTaskScoreOfMonth(condition);

		Map<String, Map<String, String>> dataMaps = new HashMap<String, Map<String, String>>();
		for (Map<String, String> result : results) {
			String welName = result.get("WEL_NAME");// 井站名称
			Map<String, String> dataMap = dataMaps.get(welName);
			if (dataMap == null || dataMap.isEmpty()) {
				dataMap = new HashMap<String, String>();
			}
			dataMap.put(result.get("START_TIME"), String.valueOf(result.get("TASK_SCORE")));
			dataMaps.put(welName, dataMap);
		}

		Set<String> keys = dataMaps.keySet();
		JSONArray dataJa = new JSONArray();
		List<String> legendData = new ArrayList<String>();
		for (String key : keys) {
			Map<String, String> dataMap = dataMaps.get(key);
			List<Double> dataList = new ArrayList<Double>();
			dataList.add(Double.parseDouble(dataMap.get("01") == null ? "0" : dataMap.get("01")));
			dataList.add(Double.parseDouble(dataMap.get("02") == null ? "0" : dataMap.get("02")));
			dataList.add(Double.parseDouble(dataMap.get("03") == null ? "0" : dataMap.get("03")));
			dataList.add(Double.parseDouble(dataMap.get("04") == null ? "0" : dataMap.get("04")));
			dataList.add(Double.parseDouble(dataMap.get("05") == null ? "0" : dataMap.get("05")));
			dataList.add(Double.parseDouble(dataMap.get("06") == null ? "0" : dataMap.get("06")));
			dataList.add(Double.parseDouble(dataMap.get("07") == null ? "0" : dataMap.get("07")));
			dataList.add(Double.parseDouble(dataMap.get("08") == null ? "0" : dataMap.get("08")));
			dataList.add(Double.parseDouble(dataMap.get("09") == null ? "0" : dataMap.get("09")));
			dataList.add(Double.parseDouble(dataMap.get("10") == null ? "0" : dataMap.get("10")));
			dataList.add(Double.parseDouble(dataMap.get("11") == null ? "0" : dataMap.get("11")));
			dataList.add(Double.parseDouble(dataMap.get("12") == null ? "0" : dataMap.get("12")));

			
			List<List<Double>> data = new ArrayList<List<Double>>();
			legendData.add(key);

			data.add(dataList);
			JSONObject jo = new JSONObject();
			try {
				jo.put("name", key);
				jo.put("data", data);
				jo.put("type", "radar");
				dataJa.put(jo);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		try {
			reJo.put("data", dataJa);
			reJo.put("legendData", legendData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

}
