
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年9月25日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.json.Json;
import javax.json.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.mapper.BiTaskReporterMapper;
import com.soa.bigdataAnalyze.util.DataFactoryUtil;
import com.soa.bigdataAnalyze.util.DataHandleUtil;
import com.soa.bigdataAnalyze.util.MathUtil;

@Service
public class SyntheticalTaskService {

	@Autowired
	private BiTaskReporterMapper taskReporterMapper;

	/**
	 * 获取各类任务的数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONArray getCountOfAllTaskType(QueryCondition condition) {

		List<Map<String, String>> results = taskReporterMapper.getCountOfTaskTypeByDateAndWelId(condition);
		//System.out.println("results" + results);
		// [{NUM=2, TASKTYPE=巡回检查}, {NUM=3, TASKTYPE=动态分析}, {NUM=2, TASKTYPE=属地监督},
		// {NUM=2, TASKTYPE=维护保养}, {NUM=2, TASKTYPE=临时任务}]

		JSONArray reJa = DataHandleUtil.formatPieChartsData(results, "TASKTYPE", "NUM");
		return reJa;
	}

	/**
	 * 获取各种状态任务数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONArray getTaskCountOfState(QueryCondition condition) {

		List<Map<String, String>> results = taskReporterMapper.getCountOfTaskStateByDateAndWelId(condition);
		JSONArray reJa = DataHandleUtil.formatPieChartsData(results, "TASKSTATE", "NUM");
		return reJa;
	}

	/**
	 * 
	 * 获取每个任务类型的任务的各个任务状态的任务数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getTaskCountOfTaskStateByTaskType(QueryCondition condition) {
		JSONObject rejo = new JSONObject();

		try {
			// 获取巡检任务的各个状态的任务数量
			condition.setTaskType("1");
			rejo.put("inspection", taskCountOfTaskStateByTaskType(condition));
			// 获取维护保养任务的各个状态的任务数量
			condition.setTaskType("2");
			rejo.put("tending", taskCountOfTaskStateByTaskType(condition));
			// 动态分析任务的各个状态任务数量
			condition.setTaskType("3");
			rejo.put("dynamicAnalysis", taskCountOfTaskStateByTaskType(condition));
			// 属地监督任务的各个状态任务数量
			condition.setTaskType("4");
			rejo.put("territorialSupervision", taskCountOfTaskStateByTaskType(condition));
			// 临时任务的各个状态的任务数量
			condition.setTaskType("5");
			rejo.put("temporary", taskCountOfTaskStateByTaskType(condition));

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return rejo;
	}

	public JSONArray taskCountOfTaskStateByTaskType(QueryCondition condition) {
		List<Map<String, String>> results = taskReporterMapper.getCountOfTaskStateByDateAndWelIdAndTaskType(condition);
		JSONArray reJa = DataHandleUtil.formatPieChartsData(results, "TASKSTATE", "NUM");
		return reJa;
	}

	/**
	 * 获取每种任务的平均得分
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getScoreOfTaskType(QueryCondition condition) {

		/**
		 * 暂时提供两种方法，一种从数据库获取数据，一种为构造数据
		 */
		JSONObject reJo = new JSONObject();

		// reJo = DataFactoryUtil.createScoreOfTaskTypeData();
		List<Map<String, String>> results = taskReporterMapper.getScoreOfTaskType(condition);
		//System.out.println(results);

		List<String> valueList = new ArrayList<String>();
		List<String> nameList = new ArrayList<String>();
		for (Map<String, String> result : results) {
			valueList.add(result.get("SCORE"));
			nameList.add(result.get("TASKTYPE"));
		}

		try {
			reJo.put("valueData", valueList);
			reJo.put("nameData", nameList);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * 获取任务排名
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getTaskFinnishRateRank(QueryCondition condition) {

		JSONObject reJo = new JSONObject();
		
		

		/*String statisticsType = condition.getStatisticsType();

		List<Map<String, String>> results = new ArrayList<Map<String, String>>();

		if ("week".equals(statisticsType)) {
			// 按周统计
			results = taskReporterMapper.getFinishRateByWeek(condition);

		} else if ("month".equals(statisticsType)) {
			// 按月统计
			results = taskReporterMapper.getFinishRateByMonth(condition);
		} else if ("quarter".equals(statisticsType)) {
			// 按季度统计
			results = taskReporterMapper.getFinishRateByQuarter(condition);
		} else if ("halfYear".equals(statisticsType)) {
			// 按半年统计
			results = taskReporterMapper.getFinishRateByHalfYear(condition);
		} else if ("year".equals(statisticsType)) {
			// 按年统计
			results = taskReporterMapper.getFinishRateByYear(condition);
		}

		*//**
		 * 格式化数据，为echarts做准备
		 *//*
		*//**
		 * 
		 *//*

		List<String> legendData = new ArrayList<String>();
		Map<String, List<Double>> resultMap = new HashMap<String, List<Double>>();
		for (Map<String, String> result : results) {
			List<Double> resultList = resultMap.get(result.get("STATISTICSTYPE"));
			if (resultList == null || resultList.isEmpty()) {
				resultList = new ArrayList<Double>();
			}
			resultList.add(Double.valueOf(String.valueOf(result.get("FINISHRATE"))));
			resultMap.put(result.get("STATISTICSTYPE"), resultList);
		}

		JSONArray valueData = new JSONArray();
		Set<String> keys = resultMap.keySet();
		for (String key : keys) {
			JSONObject jo = new JSONObject();
			legendData.add(key);
			try {
				jo.put("name", key);
				jo.put("value", resultMap.get(key));
				valueData.put(jo);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		try {
			reJo.put("valueData", valueData);
			reJo.put("legendData", legendData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
*/
		return getTaskFinnishRateRankAr(condition);
	}

	/**
	 * 获取任务排名ar
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getTaskFinnishRateRankAr(QueryCondition condition) {
		
		JSONObject reJo = new JSONObject();
		
		String[] legendDataSource = null;
		String statisticsType = condition.getStatisticsType();
		if ("week".equals(statisticsType)) {
			// 按周统计
			legendDataSource = new String[] { "2019年第51周", "2020年第50周", "2019年第11周", "2019年第35周", "2019年第23周",
					"2018年第50周", "2019年第47周", "2020年第34周", "2020年第46周", "2019年第19周", "2020年第10周", "2019年第07周",
					"2020年第22周", "2018年第46周", "2018年第22周", "2018年第34周", "2020年第18周", "2018年第10周", "2020年第06周",
					"2018年第06周", "2018年第18周", "2019年第50周", "2019年第22周", "2019年第10周", "2019年第46周", "2019年第34周",
					"2019年第06周", "2020年第45周", "2020年第21周", "2019年第18周", "2020年第33周", "2018年第33周", "2018年第45周",
					"2020年第29周", "2018年第21周", "2020年第05周", "2020年第17周", "2018年第17周", "2018年第29周", "2018年第05周",
					"2019年第33周", "2019年第21周", "2019年第45周", "2020年第04周", "2019年第17周", "2019年第05周", "2020年第32周",
					"2019年第29周", "2020年第44周", "2020年第20周", "2018年第24周", "2018年第36周", "2018年第12周", "2018年第40周",
					"2020年第16周", "2018年第52周", "2020年第28周", "2018年第08周", "2018年第48周", "2019年第20周", "2019年第44周",
					"2019年第32周", "2019年第04周", "2020年第03周", "2020年第15周", "2019年第28周", "2019年第16周", "2020年第43周",
					"2020年第31周", "2018年第35周", "2018年第47周", "2018年第11周", "2018年第23周", "2018年第51周", "2020年第27周",
					"2020年第39周", "2018年第19周", "2018年第07周", "2019年第31周", "2019年第43周", "2019年第15周", "2020年第14周",
					"2019年第03周", "2020年第26周", "2019年第39周", "2019年第27周", "2020年第02周", "2020年第30周", "2020年第42周",
					"2018年第02周", "2018年第14周", "2018年第42周", "2020年第38周", "2018年第30周", "2018年第26周", "2018年第38周",
					"2019年第42周", "2019年第30周", "2019年第02周", "2019年第26周", "2020年第25周", "2019年第14周", "2020年第37周",
					"2020年第01周", "2019年第38周", "2020年第13周", "2020年第41周", "2020年第53周", "2018年第13周", "2018年第25周",
					"2020年第09周", "2018年第01周", "2020年第49周", "2018年第41周", "2018年第09周", "2018年第37周", "2018年第49周",
					"2020年第40周", "2019年第41周", "2019年第13周", "2019年第01周", "2019年第37周", "2020年第36周", "2019年第25周",
					"2020年第48周", "2020年第12周", "2019年第49周", "2020年第24周", "2020年第52周", "2019年第09周", "2018年第44周",
					"2018年第20周", "2018年第32周", "2020年第08周", "2018年第28周", "2018年第04周", "2018年第16周", "2019年第40周",
					"2020年第51周", "2019年第52周", "2019年第24周", "2019年第12周", "2019年第48周", "2020年第47周", "2019年第36周",
					"2020年第23周", "2020年第35周", "2019年第08周", "2020年第11周", "2018年第03周", "2018年第31周", "2020年第07周",
					"2018年第43周", "2020年第19周", "2018年第39周", "2018年第15周", "2018年第27周" };
		} else if ("month".equals(statisticsType)) {
			// 按月统计
			legendDataSource = new String[] { "2018-04", "2020-06", "2018-05", "2020-05", "2018-06", "2020-04",
					"2018-07", "2020-03", "2020-02", "2018-01", "2019-12", "2020-01", "2018-02", "2018-03", "2019-11",
					"2019-10", "2020-09", "2020-08", "2020-07", "2018-08", "2018-09", "2019-06", "2019-05", "2019-08",
					"2019-07", "2018-11", "2019-02", "2018-12", "2019-01", "2020-12", "2019-04", "2020-11", "2019-03",
					"2020-10", "2018-10", "2019-09" };
		} else if ("quarter".equals(statisticsType)) {
			// 按季度统计
			legendDataSource = new String[] { "2019年第2季度", "2020年第2季度", "2019年第1季度", "2020年第1季度", "2018年第1季度", "2020年第4季度",
					"2020年第3季度", "2018年第3季度", "2018年第2季度", "2019年第4季度", "2018年第4季度", "2019年第3季度" };
		} else if ("halfYear".equals(statisticsType)) {
			// 按半年统计
			legendDataSource = new String[] { "2019上半年", "2019下半年", "2018上半年", "2018下半年", "2020上半年", "2020下半年" };
		} else if ("year".equals(statisticsType)) {
			// 按年统计
			legendDataSource = new String[] {"2018","2019","2020"};
		}
		
		Arrays.sort(legendDataSource);
		
		List<String> legendData = Arrays.asList(legendDataSource);
		
		JSONArray ja = new JSONArray();
		for(String timeStr : legendData) {
			List<Double> valueData = new ArrayList<Double>();
			valueData.add(MathUtil.getRandomDoubleOfArea(90.0, 100.0));
			valueData.add(MathUtil.getRandomDoubleOfArea(30.0, 100.0));
			valueData.add(MathUtil.getRandomDoubleOfArea(10.0, 70.0));
			valueData.add(MathUtil.getRandomDoubleOfArea(10.0, 50.0));
			valueData.add(MathUtil.getRandomDoubleOfArea(20.0, 65.0));
			JSONObject jo = new JSONObject();
			try {
				jo.put("name", timeStr);
				jo.put("value", valueData);
				ja.put(jo);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		
		
		try {
			reJo.put("valueData", ja);
			reJo.put("legendData", legendData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;

	}

}
