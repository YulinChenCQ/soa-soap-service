
/**
 * <һ�仰��������>
 * <p>
 * @author ������
 * @version [�汾��, 2018��9��11��]
 * @see [�����/����]
 * @since [��Ʒ/ģ��汾]
 */
package com.soa.bigdataAnalyze.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeUtil {
	
	
	/**
	 * 
	 * @param dateStr yyyy-mm-dd
	 * @return
	 */
	
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	public static String getDay(Date date) {
		String day = "";
		
		sdf = new SimpleDateFormat("d");
		day = sdf.format(date);
		
		
		return day;
	}
	
	
	
	public static String format(Date date) {
		sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		String dateStr = sdf.format(date);
		
		return dateStr;
	}
	
	/**
	 * ��ȡ����ʱ��ļ������
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	public static int getDaysOfTwoTime(String beginDateStr,String endDateStr) {
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		
		Date beginDate = null;
		Date endDate = null;
		try {
			beginDate = sdf1.parse(beginDateStr);
			endDate = sdf1.parse(endDateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		long begin = beginDate.getTime();
		long end = endDate.getTime();
		return Math.round((end - begin)/1000/60/60/24);
		
	}
	

}
