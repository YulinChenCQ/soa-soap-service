package com.soa.bigdataAnalyze.mapper;

import com.soa.bigdataAnalyze.entity.BiProblemNodeRecord;
import com.soa.bigdataAnalyze.entity.BiProblemNodeRecordExample;
import com.soa.bigdataAnalyze.entity.QueryCondition;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface BiProblemNodeRecordMapper {
    long countByExample(BiProblemNodeRecordExample example);

    int deleteByExample(BiProblemNodeRecordExample example);

    int deleteByPrimaryKey(String id);

    int insert(BiProblemNodeRecord record);

    int insertSelective(BiProblemNodeRecord record);

    List<BiProblemNodeRecord> selectByExample(BiProblemNodeRecordExample example);

    BiProblemNodeRecord selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") BiProblemNodeRecord record, @Param("example") BiProblemNodeRecordExample example);

    int updateByExample(@Param("record") BiProblemNodeRecord record, @Param("example") BiProblemNodeRecordExample example);

    int updateByPrimaryKeySelective(BiProblemNodeRecord record);

    int updateByPrimaryKey(BiProblemNodeRecord record);
    
    /**
     * 查询问题处理各个节点的处理平均时间
     * @param condition
     * @return
     */
    List<Map<String,String>> findTimeCostOfNode(QueryCondition condition);
     
    
    /**
     * 查询问题处理的各个节点的时间（每一个）
     * @param condition
     * @return
     */
    List<BiProblemNodeRecord> findTimeCostOfEveryProblemNode(QueryCondition condition);
    
    
    /**
     * 查询问题处理每个节点每个员工的平均处理时间
     * @param condition
     * @return
     */
    List<Map<String,String>> findTimeCostOfEveryPeople(QueryCondition condition);
    
}