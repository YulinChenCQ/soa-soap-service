
/**
 * <一句话功能描述>
 * <p> 提供获取一些基本信息（如井站信息）的方法
 * @author 陈宇林
 * @version [版本号, 2018年9月4日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.control;

import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.service.BasicInfoService;

@RestController
@RequestMapping("/basic")
public class BasicInfoController {

	@Autowired
	private BasicInfoService basicInfoService;

	/**
	 * 获取所有井站
	 * 
	 * @return json数据字符串，如： [ { "welId": "e9491ef2f9be41e5a63f66192f120d77",
	 *         "welName": "磨溪008-6井组" }, { "welId":
	 *         "7a88bebf39a84b3a99ada37ade29640e", "welName": "磨溪008-7-H1井" }]
	 */
	@RequestMapping(value = "/getAllWelStationInfos", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getAllWelStationInfos() {
		return basicInfoService.getAllWelStationInfos().toString();
	}

	/**
	 * 获取普通井站信息
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getWelStationInfos", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getWelStationInfos() {
		return basicInfoService.getWelStationInfo().toString();
	}

	/**
	 * 获取中心井站信息
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getCenterWelInfos", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getCenterWelInfos() {
		return basicInfoService.getCenterWelInfo().toString();
	}

	/**
	 * 获取权重、标准值信息
	 * @param taskType
	 *            任务类型 1． 巡检任务 2． 维护保养任务 3． 普通井站动态分析任务 4． 属地监督任务 5． 临时任务 6． 中心井站动态分析
	 * @return
	 */
	@RequestMapping(value = "/getGradeStandInfo", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String getGradeStandInfo(@RequestParam("taskType") String taskType) {

		return basicInfoService.getGradeStandInfo(taskType).toString();
	}

	/**
	 * 
	 *修改权重，标准值信息
	 * @param beginDate
	 * @param endDate
	 * @param welId
	 * @param taskType任务类型:
	 *            1． 巡检任务 2． 维护保养任务 3． 普通井站动态分析任务 4． 属地监督任务 5． 临时任务 6． 中心井站动态分析
	 * @param gradeStandInfo
	 *            json格式,例如 { "dataCountStandValue": "5", "pictureCountWeightValue":
	 *            "0.2", "problemCountStandValue": "2", "averageTimeWeightValue":
	 *            "0.5", "rfidCountWeightValue": "0.1", "descCountWeightValue":
	 *            "0.05", "averageTimeStandValue": "1", "pictureCountStandValue":
	 *            "7", "problemCountWeightValue": "0.1", "descCountStandValue": "5",
	 *            "dataCountWeightValue": "0.05", 1 "rfidCountStandValue": "7" }
	 * @return
	 */
	@RequestMapping(value = "/updateGradeStandInfo", method = RequestMethod.POST, produces = "text/plain;charset=utf-8")
	public String updateGradeStandInfo(@RequestParam("taskType") String taskType,
			@RequestParam("beginDate") String beginDate, @RequestParam("endDate") String endDate, String welId,
			@RequestParam("gradeStandInfo") JSONObject gradeStandInfo) {

		QueryCondition condition = new QueryCondition(beginDate, endDate, taskType, welId);
		return basicInfoService.updateGradeStandInfo(condition, gradeStandInfo).toString();
	}
}
