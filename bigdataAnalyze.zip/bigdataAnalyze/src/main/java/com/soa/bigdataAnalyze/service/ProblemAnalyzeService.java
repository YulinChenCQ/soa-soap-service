
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年9月30日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.service;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.json.JsonObject;

import org.apache.ibatis.executor.ResultExtractor;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soa.bigdataAnalyze.entity.BiProblemNodeRecord;
import com.soa.bigdataAnalyze.entity.QueryCondition;
import com.soa.bigdataAnalyze.mapper.BiProblemNodeRecordMapper;
import com.soa.bigdataAnalyze.util.DataHandleUtil;
import com.soa.bigdataAnalyze.util.TimeUtil;
import com.soa.bigdataAnalyze.util.WelsUtil;

@Service
public class ProblemAnalyzeService {

	@Autowired
	private BiProblemNodeRecordMapper problemNodeRecordMapper;

	/**
	 * 
	 * 获取各个任务类型的问题数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountByType(QueryCondition condition) {
		return getCountByTypeAr(condition);
	}

	/**
	 * 获取各个任务类型的问题数量(AR)
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountByTypeAr(QueryCondition condition) {

		Random random = new Random();

		JSONObject reJo = new JSONObject();
		int days = TimeUtil.getDaysOfTwoTime(condition.getBeginDate(), condition.getEndDate()) + 3;
		int welNum = WelsUtil.getWelsCount(condition.getWelId());

		System.out.println(days);

		List<String> problemTypes = new ArrayList<String>();
		problemTypes.add("物的不安全状态");
		problemTypes.add("人的不安全行为");
		problemTypes.add("管理因素");
		problemTypes.add("环境因素");

		JSONArray ja = new JSONArray();
		for (String problemType : problemTypes) {
			JSONObject jo = new JSONObject();
			try {
				jo.put("name", problemType);
				jo.put("value", random.nextInt(days * welNum));
				ja.put(jo);
			} catch (JSONException e) {
				e.printStackTrace();
			}

		}
		try {
			reJo.put("legendData", problemTypes);
			reJo.put("valueData", ja);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;

	}

	/**
	 * 获取各种问题处状态的任务数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountByState(QueryCondition condition) {
		return getCountByStateAr(condition);
	}

	/**
	 * 获取各种问题处状态的任务数量 （AR）
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountByStateAr(QueryCondition condition) {
		Random random = new Random();

		JSONObject reJo = new JSONObject();
		int days = TimeUtil.getDaysOfTwoTime(condition.getBeginDate(), condition.getEndDate()) + 3;
		int welNum = WelsUtil.getWelsCount(condition.getWelId());

		System.out.println(days);

		List<String> problemTypes = new ArrayList<String>();
		problemTypes.add("未处理");
		problemTypes.add("待执行");
		problemTypes.add("待反馈");
		problemTypes.add("待验证");
		problemTypes.add("已销项");
		problemTypes.add("已销项(井站员工自行处理)");
		problemTypes.add("未处理(已纳入隐患)");
		problemTypes.add("分析处理(已启动任务)");

		JSONArray ja = new JSONArray();
		for (String problemType : problemTypes) {
			JSONObject jo = new JSONObject();
			try {
				jo.put("name", problemType);
				jo.put("value", random.nextInt(days * welNum));
				ja.put(jo);
			} catch (JSONException e) {
				e.printStackTrace();
			}

		}
		try {
			reJo.put("legendData", problemTypes);
			reJo.put("valueData", ja);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * 
	 * 获取各个问题级别的任问题数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountByGrade(QueryCondition condition) {

		return getCountByGradeAr(condition);
	}

	/**
	 * 
	 * 获取各个问题级别的任问题数量(AR)
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountByGradeAr(QueryCondition condition) {
		Random random = new Random();

		JSONObject reJo = new JSONObject();
		int days = TimeUtil.getDaysOfTwoTime(condition.getBeginDate(), condition.getEndDate()) + 3;
		int welNum = WelsUtil.getWelsCount(condition.getWelId());

		List<String> problemTypes = new ArrayList<String>();
		problemTypes.add("轻微");
		problemTypes.add("一般");
		problemTypes.add("严重");
		problemTypes.add("非常严重");

		JSONArray ja = new JSONArray();
		for (String problemType : problemTypes) {
			JSONObject jo = new JSONObject();
			try {
				jo.put("name", problemType);
				jo.put("value", random.nextInt(days * welNum));
				ja.put(jo);
			} catch (JSONException e) {
				e.printStackTrace();
			}

		}
		try {
			reJo.put("legendData", problemTypes);
			reJo.put("valueData", ja);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * 根据条件获取各种问题来源的问题数量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountBySource(QueryCondition condition) {
		return getCountBySourceAr(condition);
	}

	/**
	 * 根据条件获取各种问题来源的问题数量（AR）
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getCountBySourceAr(QueryCondition condition) {
		Random random = new Random();

		JSONObject reJo = new JSONObject();
		int days = TimeUtil.getDaysOfTwoTime(condition.getBeginDate(), condition.getEndDate()) + 3;
		int welNum = WelsUtil.getWelsCount(condition.getWelId());

		List<String> problemTypes = new ArrayList<String>();
		problemTypes.add("井站上报");
		problemTypes.add("整改通知");
		problemTypes.add("安全检查");

		JSONArray ja = new JSONArray();
		for (String problemType : problemTypes) {
			JSONObject jo = new JSONObject();
			try {
				jo.put("name", problemType);
				jo.put("value", random.nextInt(days * welNum));
				ja.put(jo);
			} catch (JSONException e) {
				e.printStackTrace();
			}

		}
		try {
			reJo.put("legendData", problemTypes);
			reJo.put("valueData", ja);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;

	}

	/**
	 * 获取各个井站上报问题的质量
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getProblemQuality(QueryCondition condition) {
		return getProblemQualityAr(condition);
	}

	/**
	 * 获取各个井站上报问题的质量(AR)
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getProblemQualityAr(QueryCondition condition) {

		String[] welArr = { "磨溪22井", "磨溪109井", "磨溪009-4-X1井", "高石001-X4井", "高石001-X7井", "磨溪101井", "磨溪201井",
				"磨溪008-12-X1井", "磨溪009-3-X1井", "磨溪12井", "磨溪008-11-X1井", "磨溪18井", "磨溪008-20-X1井", "磨溪17井", "磨溪105井",
				"磨溪009-4-X2井", "高石001-X1井", "高石001-X5井", "西区复线末站", "东区集气站", "西区集气站", "磨溪118井", "磨溪13井", "磨溪008-20-H2井",
				"磨溪009-X1井", "磨溪009-X2井", "磨溪009-X5井", "高石001-X8井", "白鹤桥联合站", "磨溪008-7-H1井", "磨溪022-X3井", "磨溪119井",
				"磨溪008-H21井", "22井区试采集气站", "磨溪008-17-X1井", "磨溪8井组", "磨溪008-H3井", "磨溪008-X2井", "磨溪008-11-X2井", "磨溪10井",
				"磨溪009-X6井", "西北区集气站", "磨溪008-H8井", "磨溪008-18-X1井", "磨溪008-H1井", "磨溪108井", "磨溪202井", "磨溪205井",
				"磨溪009-8-X1井", "磨溪008-H19井", "磨溪009-3-X3井", "北6集气站", "磨溪008-7-X2井", "磨溪008-X16井", "高石3井", "磨溪16-C1井",
				"磨溪11井", "磨溪204井", "西眉清管站", "磨溪009-3-X2井", "磨溪002-X1井", "高石2井", "磨溪009-2-H2井", "高石12井", "高石001-X6井",
				"磨溪9井", "磨溪008-15-H1井", "西区复线首站", "磨溪008-6井组" };
		List<String> wels = Arrays.asList(welArr);

		List<String> legendData = new ArrayList<String>();
		JSONObject lineStyle = null;
		try {
			lineStyle = new JSONObject("{normal:{width: 1,opacity: 0.5}}");
		} catch (JSONException e1) {
			e1.printStackTrace();
		}

		JSONArray seriesDatas = new JSONArray();
		List<JSONObject> tableDatas = new ArrayList<JSONObject>();

		for (String wel : wels) {

			JSONObject tableData = new JSONObject();
			JSONObject seriesData = new JSONObject();
			legendData.add(wel);
			List<Double> data = new ArrayList<Double>();
			// 上报问题数量占比
			Double countRate = Double.parseDouble(String.format("%.2f", Math.random() * 80));
			// 上报问题自行处理的数量占比
			Double countOfDelByselfRate = Double.parseDouble(String.format("%.2f", Math.random() * 80 + 20));
			// 上报问题时关联了设备的问题数量占比
			Double countOfReDeviceRate = Double.parseDouble(String.format("%.2f", Math.random() * 70 + 30));
			// 上报问题拍摄照片的数量占比
			Double countOfPictureRate = Double.parseDouble(String.format("%.2f", Math.random() * 40 + 10));
			// 上报问题时录入语音的数量占比
			Double countOfVoiceRate = Double.parseDouble(String.format("%.2f", Math.random() * 50 + 20));
			// 上报问题时每个问题平均录入文字的字符数
			Double numOfDesc = Double.parseDouble(Math.round(Math.random() * 100) + "");
			// 问题上报的质量得分分数
			Double problemGrade = DataHandleUtil.CalculateProblemGrage(countRate / 100, countOfDelByselfRate / 100,
					countOfReDeviceRate / 100, countOfPictureRate / 100, countOfVoiceRate / 100, numOfDesc);

			List<List<Double>> dataList = new ArrayList<List<Double>>();

			data.add(countRate);
			data.add(countOfDelByselfRate);
			data.add(countOfReDeviceRate);
			data.add(countOfPictureRate);
			data.add(countOfVoiceRate);
			data.add(numOfDesc);
			data.add(problemGrade);
			dataList.add(data);

			/**
			 * 表格数据添加
			 */
			try {
				tableData.put("welStation", wel);
				tableData.put("countRate", countRate + "%");
				tableData.put("countOfDelByselfRate", countOfDelByselfRate + "%");
				tableData.put("countOfReDeviceRate", countOfReDeviceRate + "%");
				tableData.put("countOfPictureRate", countOfPictureRate + "%");
				tableData.put("countOfVoiceRate", countOfVoiceRate + "%");
				tableData.put("numOfDesc", numOfDesc);
				tableData.put("problemGrade", problemGrade);
				tableDatas.add(tableData);
			} catch (JSONException e1) {
				e1.printStackTrace();
			}

			try {
				seriesData.put("name", wel);
				seriesData.put("data", dataList);
				seriesData.put("type", "parallel");
				seriesData.put("lineStyle", lineStyle);
				seriesDatas.put(seriesData);
			} catch (JSONException e) {
				e.printStackTrace();
			}

		}

		JSONObject reJo = new JSONObject();

		try {
			reJo.put("legendData", legendData);
			reJo.put("seriesData", seriesDatas);
			reJo.put("tableDatas", tableDatas);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return reJo;
	}

	/**
	 * 
	 * 获取各个节点的平均处理时间
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getTimeCostOfProblemNode(QueryCondition condition) {

		JSONObject reJo = new JSONObject();
		List<Map<String, String>> results = problemNodeRecordMapper.findTimeCostOfNode(condition);

		List<String> nameData = new ArrayList<String>();
		List<Double> valueData = new ArrayList<Double>();

		for (Map<String, String> result : results) {
			nameData.add(result.get("NODE_NAME"));
			valueData.add(Double.parseDouble(String.valueOf(result.get("AVG_TIME_SPENT"))));
		}

		try {
			reJo.put("nameData", nameData);
			reJo.put("valueData", valueData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

	/**
	 * 获取每一个任务处理的每个节点花费的时间
	 * 
	 * @param condition
	 * @return
	 */
	public Object getTimeCostOfEveryProblemNode(QueryCondition condition) {

		JSONObject reJo = new JSONObject();

		long begin = System.currentTimeMillis();
		List<BiProblemNodeRecord> results = problemNodeRecordMapper.findTimeCostOfEveryProblemNode(condition);
		long end =  System.currentTimeMillis();
		
		System.out.println((end - begin)/1000 + "s");
		System.out.println("results:  " + results);
		Map<String, Map<String, BigDecimal>> resultsMap = new HashMap<String, Map<String, BigDecimal>>();

		for (BiProblemNodeRecord result : results) {
			Map<String, BigDecimal> resultMap = resultsMap.get(result.getBprId());
			if (resultMap == null || resultMap.isEmpty()) {
				resultMap = new HashMap<String, BigDecimal>();
			}
			resultMap.put(result.getNodeCode(), result.getTimeSpent());
			resultsMap.put(result.getBprId(), resultMap);
		}

		Set<String> keys = resultsMap.keySet();

		List<List<BigDecimal>> datas = new ArrayList<List<BigDecimal>>();
		for (String key : keys) {
			List<BigDecimal> data = new ArrayList<BigDecimal>();
			Map<String, BigDecimal> resultMap = resultsMap.get(key);
			data.add(resultMap.get("2"));
			data.add(resultMap.get("2"));
			data.add(resultMap.get("3"));
			data.add(resultMap.get("4"));
			data.add(resultMap.get("5"));
			data.add(resultMap.get("6"));
			data.add(resultMap.get("7"));
			data.add(resultMap.get("8"));

			datas.add(data);
		}

		try {
			reJo.put("data", datas);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		long end2 = System.currentTimeMillis();
		System.out.println((end2 - end)/1000 + "s");
		return reJo;
	}

	/**
	 * 获取每个员工的处理效率
	 * 
	 * @param condition
	 * @return
	 */
	public JSONObject getPeopleEfficiencyOfProblem(QueryCondition condition) {

		System.out.println("执行getPeopleEfficiencyOfProblem方法中！！！");
		JSONObject reJo = new JSONObject();

		List<Map<String, String>> results = problemNodeRecordMapper.findTimeCostOfEveryPeople(condition);

		List<String> nodeName = new ArrayList<String>();
		nodeName.add("调度室");
		nodeName.add("QHSE办公室");
		nodeName.add("部门负责人");
		nodeName.add("专业技术岗（分级任务-调用子流程）");
		nodeName.add("任务接收人（执行现场整改）");
		nodeName.add("专业技术岗（验证问题是否已按要求整改）");
		nodeName.add("问题上报人（闭环销项）");

		List<String> peopleName = new ArrayList<String>();
		Map<String, Double> valueMap = new HashMap<String, Double>();
		for (Map<String, String> result : results) {
			peopleName.add(result.get("EXECUTOR"));
			valueMap.put(result.get("NODE_CODE") + result.get("EXECUTOR"),
					Double.valueOf(result.get("AVG_TIME_SPENT")));
		}
		// System.out.println(valueMap);
		List<List<Double>> valueData = new ArrayList<List<Double>>();
		for (int i = 0; i < peopleName.size(); i++) {
			List<Double> coordinate = new ArrayList<Double>();// 坐标 三个点，x,y,z 其中x代表人员，y代表问题处理节点，z代表该人员在该节点的处理时间
			coordinate.add(Double.valueOf(i + ""));// x

			int j = 2;
			Double zValue = null;
			while (zValue == null && j != 9) {
				zValue = valueMap.get((j) + peopleName.get(i));
				j++;
			}
			// System.out.println("j: "+j);

			coordinate.add(Double.valueOf((j - 3) + ""));// y
			coordinate.add(zValue);// z
			if (zValue != null) {
				valueData.add(coordinate);
			}

		}
		// System.out.println(valueData);

		try {
			reJo.put("seriesData", valueData);
			reJo.put("xAxis3DData", peopleName);
			reJo.put("yAxis3DData", nodeName);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reJo;
	}

}
