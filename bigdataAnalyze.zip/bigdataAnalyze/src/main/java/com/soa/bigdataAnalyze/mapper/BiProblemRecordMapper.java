package com.soa.bigdataAnalyze.mapper;

import com.soa.bigdataAnalyze.entity.BiProblemRecord;
import com.soa.bigdataAnalyze.entity.BiProblemRecordExample;
import com.soa.bigdataAnalyze.entity.QueryCondition;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface BiProblemRecordMapper {
    long countByExample(BiProblemRecordExample example);

    int deleteByExample(BiProblemRecordExample example);

    int deleteByPrimaryKey(String id);

    int insert(BiProblemRecord record);

    int insertSelective(BiProblemRecord record);

    List<BiProblemRecord> selectByExample(BiProblemRecordExample example);

    BiProblemRecord selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") BiProblemRecord record, @Param("example") BiProblemRecordExample example);

    int updateByExample(@Param("record") BiProblemRecord record, @Param("example") BiProblemRecordExample example);

    int updateByPrimaryKeySelective(BiProblemRecord record);

    int updateByPrimaryKey(BiProblemRecord record);
    
    
   
}