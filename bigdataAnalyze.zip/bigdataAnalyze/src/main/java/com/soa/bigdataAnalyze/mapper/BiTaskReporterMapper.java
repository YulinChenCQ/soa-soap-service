package com.soa.bigdataAnalyze.mapper;

import com.soa.bigdataAnalyze.entity.BiTaskReporter;
import com.soa.bigdataAnalyze.entity.BiTaskReporterExample;
import com.soa.bigdataAnalyze.entity.QueryCondition;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface BiTaskReporterMapper {
    long countByExample(BiTaskReporterExample example);

    int deleteByExample(BiTaskReporterExample example);

    int deleteByPrimaryKey(String id);

    int insert(BiTaskReporter record);

    int insertSelective(BiTaskReporter record);

    List<BiTaskReporter> selectByExample(BiTaskReporterExample example);

    BiTaskReporter selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") BiTaskReporter record, @Param("example") BiTaskReporterExample example);

    int updateByExample(@Param("record") BiTaskReporter record, @Param("example") BiTaskReporterExample example);

    int updateByPrimaryKeySelective(BiTaskReporter record);

    int updateByPrimaryKey(BiTaskReporter record);
    
    /**
     * 根据日期和井站Id获取对应的各个任务类型的任务数量
     * @param condition
     * @return 
     */
    List<Map<String,String>> getCountOfTaskTypeByDateAndWelId(QueryCondition condition);
    
    /**
     * 根据日期和井站Id获取对应的各个状态类型的任务数量
     * @param condition
     * @return
     */
    List<Map<String,String>> getCountOfTaskStateByDateAndWelId(QueryCondition condition);
    
    
    /**
     * 根据日期和井站Id及任务类型获取对应的各个状态类型的任务数量
     * @param condition
     * @return
     */
    List<Map<String,String>> getCountOfTaskStateByDateAndWelIdAndTaskType(QueryCondition condition);
    
    
    /**
     * 查询各个任务的平均得分
     * @param condition
     * @return
     */
    List<Map<String,String>> getScoreOfTaskType(QueryCondition condition);
    
    /**
     * 按周统计，查询各个任务的完成率
     * @param condition
     * @return
     */
    List<Map<String,String>> getFinishRateByWeek(QueryCondition condition);
    
    /**
     * 按月统计，查询各个任务的完成率
     * @param condition
     * @return
     */
    List<Map<String,String>> getFinishRateByMonth(QueryCondition condition);
    
    /**
     * 按季度统计，查询各个任务的完成率
     * @param condition
     * @return
     */
    List<Map<String,String>> getFinishRateByQuarter(QueryCondition condition);
    
    
    /**
     * 按半年统计，查询各个任务的完成率
     * @param condition
     * @return
     */
    List<Map<String,String>> getFinishRateByHalfYear(QueryCondition condition);
    
    /**
     * 按年统计，查询各个任务的完成率
     * @param condition
     * @return
     */
    List<Map<String,String>> getFinishRateByYear(QueryCondition condition);
    
    
    /**
     * 根据日期查询记录
     * @param condition
     * @return
     */
    List<BiTaskReporter> findByDate(QueryCondition condition);
    
    
    /**
     * 查询各个井站的每种任务的数量
     * @param condition
     * @return
     */
    List<Map<String,String>> findCountOfWelsByType(QueryCondition condition);
    
    
    
    /**
     * 查询所有井站的每种任务的完成率
     * @param condition
     * @return
     */
    List<Map<String,String>> findAllWelFinishRateByType(QueryCondition condition);
    
    /**
     * 查询所有井站每种任务的分数
     * @param condition
     * @return
     */
    List<Map<String,String>> findTaskScoreOfWels(QueryCondition condition);
    
    /**
     * 查询所有井站综合分数
     * @param condition
     * @return
     */
    List<Map<String,String>> findTaskScore(QueryCondition condition);
  
    /**
     * 查询所有井站每个月份的综合分数
     * @param condition
     * @return
     */
   List<Map<String,String>> findTaskScoreOfMonth(QueryCondition condition); 
    
}