package com.soa.bigdataAnalyze.entity;

public class BiEquipmentRecord {
    private String id;

    private String equId;

    private Long operationNum;

    private Long exceptionNum;

    private Long tendingNum;

    private Long maintainNum;

    private Long verifyNum;

    private String ifVerify;

    private String standbyOne;

    private String standbyTwo;

    private String standbyThree;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getEquId() {
        return equId;
    }

    public void setEquId(String equId) {
        this.equId = equId == null ? null : equId.trim();
    }

    public Long getOperationNum() {
        return operationNum;
    }

    public void setOperationNum(Long operationNum) {
        this.operationNum = operationNum;
    }

    public Long getExceptionNum() {
        return exceptionNum;
    }

    public void setExceptionNum(Long exceptionNum) {
        this.exceptionNum = exceptionNum;
    }

    public Long getTendingNum() {
        return tendingNum;
    }

    public void setTendingNum(Long tendingNum) {
        this.tendingNum = tendingNum;
    }

    public Long getMaintainNum() {
        return maintainNum;
    }

    public void setMaintainNum(Long maintainNum) {
        this.maintainNum = maintainNum;
    }

    public Long getVerifyNum() {
        return verifyNum;
    }

    public void setVerifyNum(Long verifyNum) {
        this.verifyNum = verifyNum;
    }

    public String getIfVerify() {
        return ifVerify;
    }

    public void setIfVerify(String ifVerify) {
        this.ifVerify = ifVerify == null ? null : ifVerify.trim();
    }

    public String getStandbyOne() {
        return standbyOne;
    }

    public void setStandbyOne(String standbyOne) {
        this.standbyOne = standbyOne == null ? null : standbyOne.trim();
    }

    public String getStandbyTwo() {
        return standbyTwo;
    }

    public void setStandbyTwo(String standbyTwo) {
        this.standbyTwo = standbyTwo == null ? null : standbyTwo.trim();
    }

    public String getStandbyThree() {
        return standbyThree;
    }

    public void setStandbyThree(String standbyThree) {
        this.standbyThree = standbyThree == null ? null : standbyThree.trim();
    }
}