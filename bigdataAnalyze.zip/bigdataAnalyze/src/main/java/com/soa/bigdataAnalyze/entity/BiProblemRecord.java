package com.soa.bigdataAnalyze.entity;

import java.util.Date;

public class BiProblemRecord {
    private String id;

    private Date recordDay;

    private String problemNumber;

    private String problemDesc;

    private String problemState;

    private String problemType;

    private String problemLevel;

    private String problemSource;

    private String ifDevice;

    private String ifPicture;

    private String ifVoice;

    private String descCount;

    private String standbyOne;

    private String standbyTwo;

    private String standbyThree;

    private String welName;

    private String welId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Date getRecordDay() {
        return recordDay;
    }

    public void setRecordDay(Date recordDay) {
        this.recordDay = recordDay;
    }

    public String getProblemNumber() {
        return problemNumber;
    }

    public void setProblemNumber(String problemNumber) {
        this.problemNumber = problemNumber == null ? null : problemNumber.trim();
    }

    public String getProblemDesc() {
        return problemDesc;
    }

    public void setProblemDesc(String problemDesc) {
        this.problemDesc = problemDesc == null ? null : problemDesc.trim();
    }

    public String getProblemState() {
        return problemState;
    }

    public void setProblemState(String problemState) {
        this.problemState = problemState == null ? null : problemState.trim();
    }

    public String getProblemType() {
        return problemType;
    }

    public void setProblemType(String problemType) {
        this.problemType = problemType == null ? null : problemType.trim();
    }

    public String getProblemLevel() {
        return problemLevel;
    }

    public void setProblemLevel(String problemLevel) {
        this.problemLevel = problemLevel == null ? null : problemLevel.trim();
    }

    public String getProblemSource() {
        return problemSource;
    }

    public void setProblemSource(String problemSource) {
        this.problemSource = problemSource == null ? null : problemSource.trim();
    }

    public String getIfDevice() {
        return ifDevice;
    }

    public void setIfDevice(String ifDevice) {
        this.ifDevice = ifDevice == null ? null : ifDevice.trim();
    }

    public String getIfPicture() {
        return ifPicture;
    }

    public void setIfPicture(String ifPicture) {
        this.ifPicture = ifPicture == null ? null : ifPicture.trim();
    }

    public String getIfVoice() {
        return ifVoice;
    }

    public void setIfVoice(String ifVoice) {
        this.ifVoice = ifVoice == null ? null : ifVoice.trim();
    }

    public String getDescCount() {
        return descCount;
    }

    public void setDescCount(String descCount) {
        this.descCount = descCount == null ? null : descCount.trim();
    }

    public String getStandbyOne() {
        return standbyOne;
    }

    public void setStandbyOne(String standbyOne) {
        this.standbyOne = standbyOne == null ? null : standbyOne.trim();
    }

    public String getStandbyTwo() {
        return standbyTwo;
    }

    public void setStandbyTwo(String standbyTwo) {
        this.standbyTwo = standbyTwo == null ? null : standbyTwo.trim();
    }

    public String getStandbyThree() {
        return standbyThree;
    }

    public void setStandbyThree(String standbyThree) {
        this.standbyThree = standbyThree == null ? null : standbyThree.trim();
    }

    public String getWelName() {
        return welName;
    }

    public void setWelName(String welName) {
        this.welName = welName == null ? null : welName.trim();
    }

    public String getWelId() {
        return welId;
    }

    public void setWelId(String welId) {
        this.welId = welId == null ? null : welId.trim();
    }
}