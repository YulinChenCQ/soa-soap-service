package com.soa.bigdataAnalyze.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class BiTaskReporterExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public BiTaskReporterExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTaskNameIsNull() {
            addCriterion("TASK_NAME is null");
            return (Criteria) this;
        }

        public Criteria andTaskNameIsNotNull() {
            addCriterion("TASK_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andTaskNameEqualTo(String value) {
            addCriterion("TASK_NAME =", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameNotEqualTo(String value) {
            addCriterion("TASK_NAME <>", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameGreaterThan(String value) {
            addCriterion("TASK_NAME >", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameGreaterThanOrEqualTo(String value) {
            addCriterion("TASK_NAME >=", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameLessThan(String value) {
            addCriterion("TASK_NAME <", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameLessThanOrEqualTo(String value) {
            addCriterion("TASK_NAME <=", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameLike(String value) {
            addCriterion("TASK_NAME like", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameNotLike(String value) {
            addCriterion("TASK_NAME not like", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameIn(List<String> values) {
            addCriterion("TASK_NAME in", values, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameNotIn(List<String> values) {
            addCriterion("TASK_NAME not in", values, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameBetween(String value1, String value2) {
            addCriterion("TASK_NAME between", value1, value2, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameNotBetween(String value1, String value2) {
            addCriterion("TASK_NAME not between", value1, value2, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskDescIsNull() {
            addCriterion("TASK_DESC is null");
            return (Criteria) this;
        }

        public Criteria andTaskDescIsNotNull() {
            addCriterion("TASK_DESC is not null");
            return (Criteria) this;
        }

        public Criteria andTaskDescEqualTo(String value) {
            addCriterion("TASK_DESC =", value, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescNotEqualTo(String value) {
            addCriterion("TASK_DESC <>", value, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescGreaterThan(String value) {
            addCriterion("TASK_DESC >", value, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescGreaterThanOrEqualTo(String value) {
            addCriterion("TASK_DESC >=", value, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescLessThan(String value) {
            addCriterion("TASK_DESC <", value, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescLessThanOrEqualTo(String value) {
            addCriterion("TASK_DESC <=", value, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescLike(String value) {
            addCriterion("TASK_DESC like", value, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescNotLike(String value) {
            addCriterion("TASK_DESC not like", value, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescIn(List<String> values) {
            addCriterion("TASK_DESC in", values, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescNotIn(List<String> values) {
            addCriterion("TASK_DESC not in", values, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescBetween(String value1, String value2) {
            addCriterion("TASK_DESC between", value1, value2, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskDescNotBetween(String value1, String value2) {
            addCriterion("TASK_DESC not between", value1, value2, "taskDesc");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNull() {
            addCriterion("TASK_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNotNull() {
            addCriterion("TASK_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeEqualTo(String value) {
            addCriterion("TASK_TYPE =", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotEqualTo(String value) {
            addCriterion("TASK_TYPE <>", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThan(String value) {
            addCriterion("TASK_TYPE >", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThanOrEqualTo(String value) {
            addCriterion("TASK_TYPE >=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThan(String value) {
            addCriterion("TASK_TYPE <", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThanOrEqualTo(String value) {
            addCriterion("TASK_TYPE <=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLike(String value) {
            addCriterion("TASK_TYPE like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotLike(String value) {
            addCriterion("TASK_TYPE not like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIn(List<String> values) {
            addCriterion("TASK_TYPE in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotIn(List<String> values) {
            addCriterion("TASK_TYPE not in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeBetween(String value1, String value2) {
            addCriterion("TASK_TYPE between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotBetween(String value1, String value2) {
            addCriterion("TASK_TYPE not between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNull() {
            addCriterion("START_TIME is null");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNotNull() {
            addCriterion("START_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andStartTimeEqualTo(Date value) {
            addCriterionForJDBCDate("START_TIME =", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("START_TIME <>", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThan(Date value) {
            addCriterionForJDBCDate("START_TIME >", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("START_TIME >=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThan(Date value) {
            addCriterionForJDBCDate("START_TIME <", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("START_TIME <=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeIn(List<Date> values) {
            addCriterionForJDBCDate("START_TIME in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("START_TIME not in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("START_TIME between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("START_TIME not between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNull() {
            addCriterion("END_TIME is null");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNotNull() {
            addCriterion("END_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andEndTimeEqualTo(Date value) {
            addCriterionForJDBCDate("END_TIME =", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("END_TIME <>", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThan(Date value) {
            addCriterionForJDBCDate("END_TIME >", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("END_TIME >=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThan(Date value) {
            addCriterionForJDBCDate("END_TIME <", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("END_TIME <=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeIn(List<Date> values) {
            addCriterionForJDBCDate("END_TIME in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("END_TIME not in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("END_TIME between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("END_TIME not between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andWelNameIsNull() {
            addCriterion("WEL_NAME is null");
            return (Criteria) this;
        }

        public Criteria andWelNameIsNotNull() {
            addCriterion("WEL_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andWelNameEqualTo(String value) {
            addCriterion("WEL_NAME =", value, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameNotEqualTo(String value) {
            addCriterion("WEL_NAME <>", value, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameGreaterThan(String value) {
            addCriterion("WEL_NAME >", value, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameGreaterThanOrEqualTo(String value) {
            addCriterion("WEL_NAME >=", value, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameLessThan(String value) {
            addCriterion("WEL_NAME <", value, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameLessThanOrEqualTo(String value) {
            addCriterion("WEL_NAME <=", value, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameLike(String value) {
            addCriterion("WEL_NAME like", value, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameNotLike(String value) {
            addCriterion("WEL_NAME not like", value, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameIn(List<String> values) {
            addCriterion("WEL_NAME in", values, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameNotIn(List<String> values) {
            addCriterion("WEL_NAME not in", values, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameBetween(String value1, String value2) {
            addCriterion("WEL_NAME between", value1, value2, "welName");
            return (Criteria) this;
        }

        public Criteria andWelNameNotBetween(String value1, String value2) {
            addCriterion("WEL_NAME not between", value1, value2, "welName");
            return (Criteria) this;
        }

        public Criteria andWelIdIsNull() {
            addCriterion("WEL_ID is null");
            return (Criteria) this;
        }

        public Criteria andWelIdIsNotNull() {
            addCriterion("WEL_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWelIdEqualTo(String value) {
            addCriterion("WEL_ID =", value, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdNotEqualTo(String value) {
            addCriterion("WEL_ID <>", value, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdGreaterThan(String value) {
            addCriterion("WEL_ID >", value, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdGreaterThanOrEqualTo(String value) {
            addCriterion("WEL_ID >=", value, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdLessThan(String value) {
            addCriterion("WEL_ID <", value, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdLessThanOrEqualTo(String value) {
            addCriterion("WEL_ID <=", value, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdLike(String value) {
            addCriterion("WEL_ID like", value, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdNotLike(String value) {
            addCriterion("WEL_ID not like", value, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdIn(List<String> values) {
            addCriterion("WEL_ID in", values, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdNotIn(List<String> values) {
            addCriterion("WEL_ID not in", values, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdBetween(String value1, String value2) {
            addCriterion("WEL_ID between", value1, value2, "welId");
            return (Criteria) this;
        }

        public Criteria andWelIdNotBetween(String value1, String value2) {
            addCriterion("WEL_ID not between", value1, value2, "welId");
            return (Criteria) this;
        }

        public Criteria andTaskStateIsNull() {
            addCriterion("TASK_STATE is null");
            return (Criteria) this;
        }

        public Criteria andTaskStateIsNotNull() {
            addCriterion("TASK_STATE is not null");
            return (Criteria) this;
        }

        public Criteria andTaskStateEqualTo(String value) {
            addCriterion("TASK_STATE =", value, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateNotEqualTo(String value) {
            addCriterion("TASK_STATE <>", value, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateGreaterThan(String value) {
            addCriterion("TASK_STATE >", value, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateGreaterThanOrEqualTo(String value) {
            addCriterion("TASK_STATE >=", value, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateLessThan(String value) {
            addCriterion("TASK_STATE <", value, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateLessThanOrEqualTo(String value) {
            addCriterion("TASK_STATE <=", value, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateLike(String value) {
            addCriterion("TASK_STATE like", value, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateNotLike(String value) {
            addCriterion("TASK_STATE not like", value, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateIn(List<String> values) {
            addCriterion("TASK_STATE in", values, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateNotIn(List<String> values) {
            addCriterion("TASK_STATE not in", values, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateBetween(String value1, String value2) {
            addCriterion("TASK_STATE between", value1, value2, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStateNotBetween(String value1, String value2) {
            addCriterion("TASK_STATE not between", value1, value2, "taskState");
            return (Criteria) this;
        }

        public Criteria andTaskStoreIsNull() {
            addCriterion("TASK_STORE is null");
            return (Criteria) this;
        }

        public Criteria andTaskStoreIsNotNull() {
            addCriterion("TASK_STORE is not null");
            return (Criteria) this;
        }

        public Criteria andTaskStoreEqualTo(String value) {
            addCriterion("TASK_STORE =", value, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreNotEqualTo(String value) {
            addCriterion("TASK_STORE <>", value, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreGreaterThan(String value) {
            addCriterion("TASK_STORE >", value, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreGreaterThanOrEqualTo(String value) {
            addCriterion("TASK_STORE >=", value, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreLessThan(String value) {
            addCriterion("TASK_STORE <", value, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreLessThanOrEqualTo(String value) {
            addCriterion("TASK_STORE <=", value, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreLike(String value) {
            addCriterion("TASK_STORE like", value, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreNotLike(String value) {
            addCriterion("TASK_STORE not like", value, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreIn(List<String> values) {
            addCriterion("TASK_STORE in", values, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreNotIn(List<String> values) {
            addCriterion("TASK_STORE not in", values, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreBetween(String value1, String value2) {
            addCriterion("TASK_STORE between", value1, value2, "taskStore");
            return (Criteria) this;
        }

        public Criteria andTaskStoreNotBetween(String value1, String value2) {
            addCriterion("TASK_STORE not between", value1, value2, "taskStore");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIsNull() {
            addCriterion("STANDBY_ONE is null");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIsNotNull() {
            addCriterion("STANDBY_ONE is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyOneEqualTo(String value) {
            addCriterion("STANDBY_ONE =", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotEqualTo(String value) {
            addCriterion("STANDBY_ONE <>", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneGreaterThan(String value) {
            addCriterion("STANDBY_ONE >", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_ONE >=", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLessThan(String value) {
            addCriterion("STANDBY_ONE <", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_ONE <=", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneLike(String value) {
            addCriterion("STANDBY_ONE like", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotLike(String value) {
            addCriterion("STANDBY_ONE not like", value, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneIn(List<String> values) {
            addCriterion("STANDBY_ONE in", values, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotIn(List<String> values) {
            addCriterion("STANDBY_ONE not in", values, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneBetween(String value1, String value2) {
            addCriterion("STANDBY_ONE between", value1, value2, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyOneNotBetween(String value1, String value2) {
            addCriterion("STANDBY_ONE not between", value1, value2, "standbyOne");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIsNull() {
            addCriterion("STANDBY_TWO is null");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIsNotNull() {
            addCriterion("STANDBY_TWO is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoEqualTo(String value) {
            addCriterion("STANDBY_TWO =", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotEqualTo(String value) {
            addCriterion("STANDBY_TWO <>", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoGreaterThan(String value) {
            addCriterion("STANDBY_TWO >", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_TWO >=", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLessThan(String value) {
            addCriterion("STANDBY_TWO <", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_TWO <=", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoLike(String value) {
            addCriterion("STANDBY_TWO like", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotLike(String value) {
            addCriterion("STANDBY_TWO not like", value, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoIn(List<String> values) {
            addCriterion("STANDBY_TWO in", values, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotIn(List<String> values) {
            addCriterion("STANDBY_TWO not in", values, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoBetween(String value1, String value2) {
            addCriterion("STANDBY_TWO between", value1, value2, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyTwoNotBetween(String value1, String value2) {
            addCriterion("STANDBY_TWO not between", value1, value2, "standbyTwo");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIsNull() {
            addCriterion("STANDBY_THREE is null");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIsNotNull() {
            addCriterion("STANDBY_THREE is not null");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeEqualTo(String value) {
            addCriterion("STANDBY_THREE =", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotEqualTo(String value) {
            addCriterion("STANDBY_THREE <>", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeGreaterThan(String value) {
            addCriterion("STANDBY_THREE >", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeGreaterThanOrEqualTo(String value) {
            addCriterion("STANDBY_THREE >=", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLessThan(String value) {
            addCriterion("STANDBY_THREE <", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLessThanOrEqualTo(String value) {
            addCriterion("STANDBY_THREE <=", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeLike(String value) {
            addCriterion("STANDBY_THREE like", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotLike(String value) {
            addCriterion("STANDBY_THREE not like", value, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeIn(List<String> values) {
            addCriterion("STANDBY_THREE in", values, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotIn(List<String> values) {
            addCriterion("STANDBY_THREE not in", values, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeBetween(String value1, String value2) {
            addCriterion("STANDBY_THREE between", value1, value2, "standbyThree");
            return (Criteria) this;
        }

        public Criteria andStandbyThreeNotBetween(String value1, String value2) {
            addCriterion("STANDBY_THREE not between", value1, value2, "standbyThree");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}