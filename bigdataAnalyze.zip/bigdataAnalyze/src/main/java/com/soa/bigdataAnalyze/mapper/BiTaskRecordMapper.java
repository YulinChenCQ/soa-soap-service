package com.soa.bigdataAnalyze.mapper;

import com.soa.bigdataAnalyze.entity.BiTaskRecord;
import com.soa.bigdataAnalyze.entity.BiTaskRecordExample;
import com.soa.bigdataAnalyze.entity.QueryCondition;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface BiTaskRecordMapper {
    long countByExample(BiTaskRecordExample example);

    int deleteByExample(BiTaskRecordExample example);

    int deleteByPrimaryKey(String taskId);

    int insert(BiTaskRecord record);

    int insertSelective(BiTaskRecord record);

    List<BiTaskRecord> selectByExample(BiTaskRecordExample example);

    BiTaskRecord selectByPrimaryKey(String taskId);

    int updateByExampleSelective(@Param("record") BiTaskRecord record, @Param("example") BiTaskRecordExample example);

    int updateByExample(@Param("record") BiTaskRecord record, @Param("example") BiTaskRecordExample example);

    int updateByPrimaryKeySelective(BiTaskRecord record);

    int updateByPrimaryKey(BiTaskRecord record);
    
    
    List<BiTaskRecord> findTaskRecordByDateAndTypeAndWel(@Param("condition")QueryCondition condition);
    
    List<BiTaskRecord> findTaskRecordByDateAndType(@Param("condition")QueryCondition condition);
    
}