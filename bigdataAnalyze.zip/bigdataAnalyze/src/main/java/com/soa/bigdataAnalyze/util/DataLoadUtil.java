
/**
 * <һ�仰��������>
 * <p>
 * @author ������
 * @version [�汾��, 2018��9��16��]
 * @see [�����/����]
 * @since [��Ʒ/ģ��汾]
 */
package com.soa.bigdataAnalyze.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.soa.bigdataAnalyze.driver.RedisDriver;
import com.soa.bigdataAnalyze.entity.BiStepInfo;
import com.soa.bigdataAnalyze.entity.StepExcuteTimeMap;
import com.soa.bigdataAnalyze.mapper.BiStepInfoMapper;

import redis.clients.jedis.Jedis;

@Component
public class DataLoadUtil implements ApplicationListener<ContextRefreshedEvent>{
	
	
	@Autowired
	private BiStepInfoMapper stepInfoMapper;
	
	private static DataLoadUtil dataLoadUtil;
	
	@PostConstruct
	public void init() {
		dataLoadUtil = this;
		dataLoadUtil.stepInfoMapper = this.stepInfoMapper;
	}
	
	/**
	 * �����ݿⲽ��������ݼ��ص�redis������ȥ
	 */
	public static void loadStepData() {
		
		Jedis jedis = RedisDriver.getRedisInstance();
		/**
		 * ��ѯ����
		 */
		long time1 = System.currentTimeMillis();
		System.out.println(">>>>>>>>��ʼ��ѯ��������");
		List<BiStepInfo> stepInfos = dataLoadUtil.stepInfoMapper.findAllStepInfo();
		long time2 = System.currentTimeMillis();
		System.out.println("��ѯ���в��軨��ʱ�䣺"+((time2-time1)/1000)+ "s");
		
		for(BiStepInfo stepInfo : stepInfos) {
			String taskId = stepInfo.getTaskId();
			StepExcuteTimeMap stepExcuteTimeMap = (StepExcuteTimeMap) SerializeUtil.unserialize(jedis.get(taskId.getBytes()));
			
			if(stepExcuteTimeMap == null ) {
				stepExcuteTimeMap = new StepExcuteTimeMap();
				Map<String,String> map = new  HashMap<String,String>();
				map.put(stepInfo.getStepName(), stepInfo.getExecutionTime());
				stepExcuteTimeMap.setStepExcuteTimeMap(map);
			} else if(stepExcuteTimeMap.getStepExcuteTimeMap() == null || stepExcuteTimeMap.getStepExcuteTimeMap().isEmpty()) {
				Map<String,String> map = new  HashMap<String,String>();
				map.put(stepInfo.getStepName(), stepInfo.getExecutionTime());
				stepExcuteTimeMap.setStepExcuteTimeMap(map);
			} else {
				stepExcuteTimeMap.getStepExcuteTimeMap().put(stepInfo.getStepName(), stepInfo.getExecutionTime());
			}
			
			jedis.set(taskId.toString().getBytes(),SerializeUtil.serialize(stepExcuteTimeMap));
		}
	}



	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationListener#onApplicationEvent(org.springframework.context.ApplicationEvent)
	 */
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		if(event.getApplicationContext().getParent() == null)
        {  
            /*loadStepData();*/
			/*Jedis jedis = RedisDriver.getRedisInstance();
			
			System.out.println((StepExcuteTimeMap) SerializeUtil.unserialize(jedis.get("4648BD921E9D4CB982380DE8F677E419".getBytes())));
			*/
			
        }  
		
		
	}
	
}










