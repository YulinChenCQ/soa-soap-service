package com.soa.bigdataAnalyze.entity;

import java.util.Date;

public class BiWellStation {
    private String bwsId;

    private String wellNumber;

    private String wellStationName;

    private String bggsId;

    private String gasGatherStationName;

    private String stationType;

    private String description;

    private Date createTime;

    private String remarkone;

    private String remarktwo;

    private String remarkthree;

    public String getBwsId() {
        return bwsId;
    }

    public void setBwsId(String bwsId) {
        this.bwsId = bwsId == null ? null : bwsId.trim();
    }

    public String getWellNumber() {
        return wellNumber;
    }

    public void setWellNumber(String wellNumber) {
        this.wellNumber = wellNumber == null ? null : wellNumber.trim();
    }

    public String getWellStationName() {
        return wellStationName;
    }

    public void setWellStationName(String wellStationName) {
        this.wellStationName = wellStationName == null ? null : wellStationName.trim();
    }

    public String getBggsId() {
        return bggsId;
    }

    public void setBggsId(String bggsId) {
        this.bggsId = bggsId == null ? null : bggsId.trim();
    }

    public String getGasGatherStationName() {
        return gasGatherStationName;
    }

    public void setGasGatherStationName(String gasGatherStationName) {
        this.gasGatherStationName = gasGatherStationName == null ? null : gasGatherStationName.trim();
    }

    public String getStationType() {
        return stationType;
    }

    public void setStationType(String stationType) {
        this.stationType = stationType == null ? null : stationType.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getRemarkone() {
        return remarkone;
    }

    public void setRemarkone(String remarkone) {
        this.remarkone = remarkone == null ? null : remarkone.trim();
    }

    public String getRemarktwo() {
        return remarktwo;
    }

    public void setRemarktwo(String remarktwo) {
        this.remarktwo = remarktwo == null ? null : remarktwo.trim();
    }

    public String getRemarkthree() {
        return remarkthree;
    }

    public void setRemarkthree(String remarkthree) {
        this.remarkthree = remarkthree == null ? null : remarkthree.trim();
    }
}