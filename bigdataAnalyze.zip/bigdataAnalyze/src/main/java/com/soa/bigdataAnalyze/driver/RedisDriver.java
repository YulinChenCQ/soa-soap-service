
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年9月16日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.driver;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.soa.bigdataAnalyze.util.PropertiesUtil;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.Response;

public class RedisDriver {
	
	
	
	/**
	 * redis操作实例
	 */
	private static Jedis jedis;
	/**
	 * 获取redis实例
	 * @return
	 */
	public static Jedis getRedisInstance() {
		
		if(jedis == null) {
			
			jedis = new Jedis(PropertiesUtil.getProperty("redisServer"));
			
		}
		
		return jedis;
	}
	public static void main(String[] args) {
		
		Jedis myJedis = RedisDriver.getRedisInstance();
		System.out.println("服务正在运行：" + myJedis.toString());
		
		
		Jedis redis = new Jedis("192.168.1.18");
		
		redis.set("100".getBytes(), "nihao".getBytes());
		 //redis.set("100".getBytes(), "nihao".getBytes());
		
		

	}

}
