package com.soa.bigdataAnalyze.entity;

public class BiGradeStand {
    private String id;

    private String taskType;

    private String welStation;

    private String welStationId;

    private String dimName;

    private String weightCoefficient;

    private String standValue;

    private String standbyOne;

    private String standbyTwo;

    private String standbyThree;

    private String dimNameEn;
    
    
    
    

    /**
	 * 
	 */
	public BiGradeStand() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	/**
	 * @param taskType
	 * @param dimName
	 * @param weightCoefficient
	 * @param standValue
	 * @param dimNameEn
	 */
	public BiGradeStand(String taskType, String dimName, String weightCoefficient, String standValue,
			String dimNameEn) {
		super();
		this.taskType = taskType;
		this.dimName = dimName;
		this.weightCoefficient = weightCoefficient;
		this.standValue = standValue;
		this.dimNameEn = dimNameEn;
	}



	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }

    public String getWelStation() {
        return welStation;
    }

    public void setWelStation(String welStation) {
        this.welStation = welStation == null ? null : welStation.trim();
    }

    public String getWelStationId() {
        return welStationId;
    }

    public void setWelStationId(String welStationId) {
        this.welStationId = welStationId == null ? null : welStationId.trim();
    }

    public String getDimName() {
        return dimName;
    }

    public void setDimName(String dimName) {
        this.dimName = dimName == null ? null : dimName.trim();
    }

    public String getWeightCoefficient() {
        return weightCoefficient;
    }

    public void setWeightCoefficient(String weightCoefficient) {
        this.weightCoefficient = weightCoefficient == null ? null : weightCoefficient.trim();
    }

    public String getStandValue() {
        return standValue;
    }

    public void setStandValue(String standValue) {
        this.standValue = standValue == null ? null : standValue.trim();
    }

    public String getStandbyOne() {
        return standbyOne;
    }

    public void setStandbyOne(String standbyOne) {
        this.standbyOne = standbyOne == null ? null : standbyOne.trim();
    }

    public String getStandbyTwo() {
        return standbyTwo;
    }

    public void setStandbyTwo(String standbyTwo) {
        this.standbyTwo = standbyTwo == null ? null : standbyTwo.trim();
    }

    public String getStandbyThree() {
        return standbyThree;
    }

    public void setStandbyThree(String standbyThree) {
        this.standbyThree = standbyThree == null ? null : standbyThree.trim();
    }

    public String getDimNameEn() {
        return dimNameEn;
    }

    public void setDimNameEn(String dimNameEn) {
        this.dimNameEn = dimNameEn == null ? null : dimNameEn.trim();
    }
}