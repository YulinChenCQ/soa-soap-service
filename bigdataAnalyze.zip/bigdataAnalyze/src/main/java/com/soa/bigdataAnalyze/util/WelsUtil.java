
/**
 * <一句话功能描述>
 * <p>
 * @author 陈宇林
 * @version [版本号, 2018年10月8日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
package com.soa.bigdataAnalyze.util;


public class WelsUtil {
	
	
	/**
	 * 获取井站数量
	 * @param wels 井站的id，逗号隔开
	 * @return
	 */
	public static int getWelsCount(String wels) {
		
		int num = wels.split(",").length;
		return num;
	}

}
