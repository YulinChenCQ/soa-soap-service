package com.soa.bigdataAnalyze.mapper;

import com.soa.bigdataAnalyze.entity.BiWellStation;
import com.soa.bigdataAnalyze.entity.BiWellStationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface BiWellStationMapper {
	
	
    long countByExample(BiWellStationExample example);

    int deleteByExample(BiWellStationExample example);

    int deleteByPrimaryKey(String bwsId);

    int insert(BiWellStation record);

    int insertSelective(BiWellStation record);

    List<BiWellStation> selectByExample(BiWellStationExample example);

    BiWellStation selectByPrimaryKey(String bwsId);

    int updateByExampleSelective(@Param("record") BiWellStation record, @Param("example") BiWellStationExample example);

    int updateByExample(@Param("record") BiWellStation record, @Param("example") BiWellStationExample example);

    int updateByPrimaryKeySelective(BiWellStation record);

    int updateByPrimaryKey(BiWellStation record);

	/**
	 * 获取所有井站
	 * @return
	 */
	List<BiWellStation> findAll();
	
	/**
	 * 获取中井站
	 * @return
	 */
	List<BiWellStation> findCenterWel();
	
	/**
	 * 获取普通井站
	 * @return
	 */
	List<BiWellStation> findCommonWel();
}